"use client"

import { useState } from "react"
import { usePaginatedQuery, useQuery, useMutation, useConvexAuth } from "convex/react"
import { api } from "@devlider001/washlab-backend/api"
import { Id, Doc } from "@devlider001/washlab-backend/dataModel"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { OrderTable } from "./OrderTable"
import { OrderDetailsDialog } from "./OrderDetailsDialog"
import { OrderStatusDialog } from "./OrderStatusDialog"
import {
  Search,
  Filter,
  Loader2,
} from "lucide-react"
import { toast } from "sonner"

const ORDERS_LIMIT = 20

type OrderStatus =
  | "pending_dropoff"
  | "checked_in"
  | "sorting"
  | "washing"
  | "drying"
  | "folding"
  | "ready"
  | "completed"
  | "cancelled"
  // Legacy statuses for backward compatibility
  | "pending"
  | "in_progress"
  | "ready_for_pickup"
  | "delivered"

interface Branch {
  _id: Id<"branches">
  name: string
  code: string
}

const AdminOrders = () => {
  const { isAuthenticated } = useConvexAuth()
  const [selectedBranchId, setSelectedBranchId] = useState<string>("all")
  const [selectedStatus, setSelectedStatus] = useState<string>("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedOrder, setSelectedOrder] = useState<Doc<"orders"> | null>(null)
  const [orderToUpdate, setOrderToUpdate] = useState<Doc<"orders"> | null>(null)
  const [orderToDelete, setOrderToDelete] = useState<Doc<"orders"> | null>(null)
  const [showDetailsDialog, setShowDetailsDialog] = useState(false)
  const [showStatusDialog, setShowStatusDialog] = useState(false)

  // Get branches for filter
  const {
    results: branchesPages,
  } = usePaginatedQuery(
    api.admin.getBranches,
    isAuthenticated ? {} : "skip",
    { initialNumItems: 100 }
  )
  const branchesList = branchesPages?.flat() || []

  // Get orders with pagination
  const {
    results: ordersPages,
    status: paginationStatus,
    loadMore,
  } = usePaginatedQuery(
    api.admin.getOrders,
    isAuthenticated
      ? {
          branchId:
            selectedBranchId && selectedBranchId !== "all"
              ? (selectedBranchId as Id<"branches">)
              : undefined,
          status:
            selectedStatus && selectedStatus !== "all"
              ? (selectedStatus as OrderStatus)
              : undefined,
        }
      : "skip",
    { initialNumItems: ORDERS_LIMIT }
  )

  // Get order details when selected
  const orderDetails = useQuery(
    api.admin.getOrderDetails,
    selectedOrder && isAuthenticated ? { orderId: selectedOrder._id } : "skip"
  )

  // Mutations
  const updateOrderStatus = useMutation(api.admin.updateOrderStatus)
  const deleteOrder = useMutation(api.admin.deleteOrder)

  const orders = ordersPages?.flat() || []
  const hasMore = paginationStatus === "CanLoadMore"
  const isLoading =
    paginationStatus === "LoadingFirstPage" || paginationStatus === "LoadingMore"

  // Filter orders by search query (client-side)
  const filteredOrders = orders.filter((order) => {
    if (!searchQuery.trim()) return true
    const query = searchQuery.toLowerCase()
    return (
      order.orderNumber.toLowerCase().includes(query) ||
      order.customerPhoneNumber.toLowerCase().includes(query)
    )
  })

  const handleViewDetails = (order: Doc<"orders">) => {
    setSelectedOrder(order)
    setShowDetailsDialog(true)
  }

  const handleUpdateStatus = (order: Doc<"orders">) => {
    setOrderToUpdate(order)
    setShowStatusDialog(true)
  }

  const handleDelete = (order: Doc<"orders">) => {
    setOrderToDelete(order)
  }

  const handleConfirmDelete = async () => {
    if (!orderToDelete) return

    try {
      await deleteOrder({ orderId: orderToDelete._id })
      toast.success("Order deleted successfully")
      setOrderToDelete(null)
    } catch (error: unknown) {
      const errorMessage =
        error instanceof Error ? error.message : "Failed to delete order"
      toast.error(errorMessage)
    }
  }

  const handleStatusUpdate = async (
    orderId: string,
    newStatus: string,
    notes?: string
  ) => {
    try {
      await updateOrderStatus({
        orderId: orderId as Id<"orders">,
        newStatus: newStatus as OrderStatus,
        notes,
      })
      toast.success("Order status updated successfully")
      setShowStatusDialog(false)
      setOrderToUpdate(null)
    } catch (error: unknown) {
      const errorMessage =
        error instanceof Error ? error.message : "Failed to update order status"
      toast.error(errorMessage)
    }
  }

  // Stats - Calculate counts for all statuses
  const stats = {
    total: orders.length,
    pending: orders.filter((o) => o.status === "pending").length,
    inProgress: orders.filter((o) => o.status === "in_progress").length,
    readyForPickup: orders.filter((o) => o.status === "ready_for_pickup").length,
    delivered: orders.filter((o) => o.status === "delivered").length,
    completed: orders.filter((o) => o.status === "completed").length,
    cancelled: orders.filter((o) => o.status === "cancelled").length,
  }

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">Orders</h1>
          <p className="text-sm sm:text-base text-muted-foreground mt-1">
            Manage and track all orders
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-6">
        {/* Total Orders - Full width on small screens, spans 2 columns on larger */}
        <Card className="sm:col-span-2 lg:col-span-1 xl:col-span-2 border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-primary/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
              Total Orders
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-4xl font-bold text-primary">{stats.total}</div>
              <div className="text-sm text-muted-foreground">orders</div>
            </div>
          </CardContent>
        </Card>

        {/* Pending */}
        <Card className="border-l-4 border-l-orange-500 hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              Pending
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-3xl font-bold text-orange-600">{stats.pending}</div>
            </div>
          </CardContent>
        </Card>

        {/* In Progress */}
        <Card className="border-l-4 border-l-blue-500 hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              In Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-3xl font-bold text-blue-600">{stats.inProgress}</div>
            </div>
          </CardContent>
        </Card>

        {/* Ready for Pickup */}
        <Card className="border-l-4 border-l-purple-500 hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              Ready for Pickup
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-3xl font-bold text-purple-600">{stats.readyForPickup}</div>
            </div>
          </CardContent>
        </Card>

        {/* Delivered */}
        <Card className="border-l-4 border-l-cyan-500 hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              Delivered
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-3xl font-bold text-cyan-600">{stats.delivered}</div>
            </div>
          </CardContent>
        </Card>

        {/* Completed */}
        <Card className="border-l-4 border-l-green-500 hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              Completed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-3xl font-bold text-green-600">{stats.completed}</div>
            </div>
          </CardContent>
        </Card>

        {/* Cancelled */}
        <Card className="border-l-4 border-l-red-500 hover:shadow-md transition-shadow">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              Cancelled
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <div className="text-3xl font-bold text-red-600">{stats.cancelled}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Filter className="h-5 w-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Search */}
            <div className="sm:col-span-2 lg:col-span-1">
              <Label htmlFor="search">Search Orders</Label>
              <div className="relative mt-2">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="Order number or phone..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>

            {/* Branch Filter */}
            <div>
              <Label htmlFor="branch">Branch</Label>
              <Select value={selectedBranchId} onValueChange={setSelectedBranchId}>
                <SelectTrigger id="branch" className="mt-2">
                  <SelectValue placeholder="All branches" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Branches</SelectItem>
                  {branchesList.map((branch: Branch) => (
                    <SelectItem key={branch._id} value={branch._id}>
                      {branch.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Status Filter */}
            <div>
              <Label htmlFor="status">Status</Label>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger id="status" className="mt-2">
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="ready_for_pickup">Ready for Pickup</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Orders Table */}
      <OrderTable
        orders={filteredOrders}
        isLoading={isLoading && orders.length === 0}
        onViewDetails={handleViewDetails}
        onUpdateStatus={handleUpdateStatus}
        onDelete={handleDelete}
      />

      {/* Load More */}
      {hasMore && filteredOrders.length > 0 && (
        <div className="flex justify-center mt-6">
          <Button
            variant="outline"
            onClick={() => loadMore(ORDERS_LIMIT)}
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Loading...
              </>
            ) : (
              "Load More Orders"
            )}
          </Button>
        </div>
      )}

      {/* Order Details Dialog */}
      {selectedOrder && (
        <OrderDetailsDialog
          order={selectedOrder}
          customer={orderDetails?.customer || null}
          branch={orderDetails?.branch || null}
          open={showDetailsDialog}
          onOpenChange={setShowDetailsDialog}
        />
      )}

      {/* Order Status Update Dialog */}
      {orderToUpdate && (
        <OrderStatusDialog
          order={orderToUpdate}
          open={showStatusDialog}
          onOpenChange={setShowStatusDialog}
          onUpdate={handleStatusUpdate}
        />
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog
        open={!!orderToDelete}
        onOpenChange={(open) => !open && setOrderToDelete(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Order</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete order{" "}
              <strong>{orderToDelete?.orderNumber}</strong>? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

export default AdminOrders

