import { cn } from '@/lib/utils';
import Image from 'next/image';

interface LogoProps {
  className?: string;
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const Logo = ({ className, showText = true, size = 'md' }: LogoProps) => {
  const dimensions = {
    sm: { width: 200, height: 200 },
    md: { width: 240, height: 240 },
    lg: { width: 320, height: 320 },
  };

  const displayClasses = {
    sm: 'h-10 w-auto',
    md: 'h-12 w-auto',
    lg: 'h-16 w-auto',
  };

  return (
    <div className={cn('flex items-center', className)}>
      <Image 
        src="/assets/washlab-logo.png"
        alt="WashLab - Life made simple" 
        width={dimensions[size].width}
        height={dimensions[size].height}
        className={cn(displayClasses[size], 'object-contain')}
        quality={100}
        priority
      />
    </div>
  );
};