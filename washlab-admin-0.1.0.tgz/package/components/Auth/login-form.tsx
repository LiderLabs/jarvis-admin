"use client"

import * as Clerk from "@clerk/elements/common"
import * as SignIn from "@clerk/elements/sign-in"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { PasswordInput } from "@/components/ui/password-input"
import { cn } from "@/lib/utils"
import { Loader } from "lucide-react"
import { useSearchParams, useRouter } from "next/navigation"
import { useAuth } from "@clerk/nextjs"
import { useConvexAuth } from "convex/react"
import { useEffect, useState } from "react"

export default function LoginForm() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const { isSignedIn, isLoaded: isClerkLoaded } = useAuth()
  const { isAuthenticated: isConvexAuthenticated, isLoading: isConvexLoading } =
    useConvexAuth()
  const redirectUrl = searchParams.get("redirect_url") || "/dashboard"
  const [shouldRedirect, setShouldRedirect] = useState(false)

  // Handle redirect after successful sign-in
  // Wait for both Clerk and Convex auth to be ready (similar to customer app)
  useEffect(() => {
    if (
      isClerkLoaded &&
      isSignedIn &&
      !isConvexLoading &&
      isConvexAuthenticated
    ) {
      // Use Next.js router for navigation (same as customer app)
      // Small delay to ensure auth state is fully established
      const timer = setTimeout(() => {
        setShouldRedirect(true)
        router.push(redirectUrl)
      }, 100)

      return () => clearTimeout(timer)
    }
  }, [
    isClerkLoaded,
    isSignedIn,
    isConvexLoading,
    isConvexAuthenticated,
    router,
    redirectUrl,
  ])

  // Show loading screen when redirecting
  if (shouldRedirect && isClerkLoaded && isSignedIn) {
    return (
      <div className='min-h-screen flex items-center justify-center'>
        <div className='max-w-sm w-full flex flex-col items-center gap-6 p-8'>
          <div className='relative'>
            <div className='h-16 w-16 rounded-full border-4 border-primary/20 border-t-primary animate-spin'></div>
            <div className='absolute inset-0 flex items-center justify-center'>
              <Loader className='h-6 w-6 text-primary animate-spin' />
            </div>
          </div>
          <div className='text-center space-y-2'>
            <h2 className='text-xl font-semibold'>Login Successful!</h2>
            <p className='text-sm text-muted-foreground'>
              Redirecting you to the dashboard...
            </p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className='max-w-sm'>
      <SignIn.Root>
        <Clerk.Loading>
          {(isGlobalLoading) => (
            <>
              <SignIn.Step name='start'>
                <div className={cn("flex flex-col gap-6")}>
                  <div className='flex flex-col items-center gap-2 text-center'>
                    <h1 className='page-heading'>Welcome to WashLab! 👋🏻</h1>
                    <p className='text-balance text-sm text-muted-foreground'>
                      Enter your email below to login to your account
                    </p>
                  </div>
                  <div className='grid gap-6'>
                    <Clerk.Field name='identifier' className='space-y-2'>
                      <Clerk.Label asChild>
                        <Label>Email address</Label>
                      </Clerk.Label>
                      <Clerk.Input
                        type='email'
                        placeholder='user@example.com'
                        required
                        asChild
                      >
                        <Input />
                      </Clerk.Input>
                      <Clerk.FieldError className='block text-sm text-red-500' />
                    </Clerk.Field>

                    <SignIn.Action submit asChild>
                      <Button disabled={isGlobalLoading}>
                        <Clerk.Loading>
                          {(isLoading) => {
                            return isLoading ? (
                              <Loader className='size-4 animate-spin' />
                            ) : (
                              "Continue"
                            )
                          }}
                        </Clerk.Loading>
                      </Button>
                    </SignIn.Action>
                  </div>
                </div>
              </SignIn.Step>

              <SignIn.Step name='choose-strategy'>
                <div className={cn("flex flex-col gap-6")}>
                  <div className='flex flex-col items-center gap-2 text-center'>
                    <h1 className='page-heading'>Use another method</h1>
                    <p className='text-balance text-sm text-muted-foreground'>
                      Facing issues? You can use any of these methods to sign
                      in.
                    </p>
                  </div>
                  <div className='grid gap-6'>
                    <SignIn.SupportedStrategy name='email_code' asChild>
                      <Button
                        type='button'
                        variant='link'
                        disabled={isGlobalLoading}
                      >
                        Email code
                      </Button>
                    </SignIn.SupportedStrategy>
                    <SignIn.SupportedStrategy name='password' asChild>
                      <Button
                        type='button'
                        variant='link'
                        disabled={isGlobalLoading}
                      >
                        Password
                      </Button>
                    </SignIn.SupportedStrategy>
                    <SignIn.Action navigate='previous' asChild>
                      <Button disabled={isGlobalLoading}>
                        <Clerk.Loading>
                          {(isLoading) => {
                            return isLoading ? (
                              <Loader className='size-4 animate-spin' />
                            ) : (
                              "Go back"
                            )
                          }}
                        </Clerk.Loading>
                      </Button>
                    </SignIn.Action>
                  </div>
                </div>
              </SignIn.Step>

              <SignIn.Step name='sso-callback'>
                <Clerk.GlobalError className='block text-sm text-red-500' />
                <div className={cn("flex flex-col gap-6")}>
                  <div className='flex flex-col items-center gap-2 text-center'>
                    <h1 className='page-heading'>Sign in with SSO</h1>
                    <p className='text-balance text-sm text-muted-foreground'>
                      You are being redirected to your SSO provider.
                    </p>
                  </div>
                  <div className='grid gap-6'>
                    <Clerk.Loading>
                      {(isLoading) => {
                        return isLoading ? (
                          <Loader className='size-4 animate-spin' />
                        ) : (
                          "Redirecting..."
                        )
                      }}
                    </Clerk.Loading>
                  </div>
                </div>
                {/* CAPTCHA Widget */}
                <SignIn.Captcha className='empty:hidden' />
              </SignIn.Step>

              <SignIn.Step name='verifications'>
                <Clerk.GlobalError className='block text-sm text-destructive mb-4' />

                <SignIn.Strategy name='password'>
                  <div className={cn("flex flex-col gap-6")}>
                    <div className='flex flex-col items-center gap-2 text-center'>
                      <h1 className='page-heading'>
                        Welcome back <SignIn.SafeIdentifier />
                      </h1>
                    </div>
                    <div className='grid gap-6'>
                      <Clerk.Field name='password' className='space-y-2'>
                        <Clerk.Label asChild>
                          <Label>Password</Label>
                        </Clerk.Label>
                        <Clerk.Input
                          type='password'
                          placeholder='Enter your password'
                          asChild
                        >
                          <PasswordInput />
                        </Clerk.Input>
                        <Clerk.FieldError className='block text-sm text-destructive' />
                      </Clerk.Field>

                      <SignIn.Action submit asChild>
                        <Button disabled={isGlobalLoading}>
                          <Clerk.Loading>
                            {(isLoading) => {
                              return isLoading ? (
                                <Loader className='size-4 animate-spin' />
                              ) : (
                                "Log in"
                              )
                            }}
                          </Clerk.Loading>
                        </Button>
                      </SignIn.Action>
                      <SignIn.Action navigate='choose-strategy' asChild>
                        <Button type='button' size='sm' variant='link'>
                          Use another method
                        </Button>
                      </SignIn.Action>
                    </div>
                  </div>
                </SignIn.Strategy>

                <SignIn.Strategy name='email_code'>
                  <Clerk.GlobalError className='block text-sm text-destructive mb-4' />

                  <div className={cn("flex flex-col gap-6")}>
                    <div className='flex flex-col items-center gap-2 text-center'>
                      <h1 className='page-heading'>Check your email</h1>
                      <p className='text-balance text-sm text-muted-foreground'>
                        Enter the verification code sent to your email
                      </p>
                    </div>
                    <div className='grid gap-6'>
                      <Clerk.Field name='code'>
                        <Clerk.Label className='sr-only'>
                          Email verification code
                        </Clerk.Label>
                        <div className='grid gap-y-2 items-center justify-center'>
                          <div className='flex justify-center text-center'>
                            <Clerk.Input
                              type='otp'
                              autoSubmit
                              className='flex justify-center has-[:disabled]:opacity-50'
                              render={({ value, status }) => {
                                return (
                                  <div
                                    data-status={status}
                                    className={cn(
                                      "relative flex size-10 items-center justify-center border-y border-r border-input text-sm transition-all first:rounded-l-md first:border-l last:rounded-r-md",
                                      {
                                        "z-10 ring-2 ring-ring ring-offset-background":
                                          status === "cursor" ||
                                          status === "selected",
                                      }
                                    )}
                                  >
                                    {value}
                                    {status === "cursor" && (
                                      <div className='pointer-events-none absolute inset-0 flex items-center justify-center'>
                                        <div className='animate-caret-blink h-4 w-px bg-foreground duration-1000' />
                                      </div>
                                    )}
                                  </div>
                                )
                              }}
                            />
                          </div>
                          <Clerk.FieldError className='block text-sm text-destructive text-center' />
                          <SignIn.Action
                            asChild
                            resend
                            className='text-muted-foreground'
                            fallback={({
                              resendableAfter,
                            }: {
                              resendableAfter: number
                            }) => (
                              <Button variant='link' size='sm' disabled>
                                Didn&apos;t receive a code? Resend (
                                <span className='tabular-nums'>
                                  {resendableAfter}
                                </span>
                                )
                              </Button>
                            )}
                          >
                            <Button variant='link' size='sm'>
                              Didn&apos;t receive a code? Resend
                            </Button>
                          </SignIn.Action>
                        </div>
                      </Clerk.Field>
                    </div>
                    <div>
                      <div className='grid w-full gap-y-4'>
                        <SignIn.Action submit asChild>
                          <Button disabled={isGlobalLoading}>
                            <Clerk.Loading>
                              {(isLoading) => {
                                return isLoading ? (
                                  <Loader className='size-4 animate-spin' />
                                ) : (
                                  "Verify"
                                )
                              }}
                            </Clerk.Loading>
                          </Button>
                        </SignIn.Action>
                      </div>
                    </div>
                  </div>
                </SignIn.Strategy>
              </SignIn.Step>
            </>
          )}
        </Clerk.Loading>
      </SignIn.Root>
    </div>
  )
}
