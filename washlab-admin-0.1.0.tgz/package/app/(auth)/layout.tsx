import Image from "next/image"

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <main className='grid h-screen lg:grid-cols-2'>
      <div className='flex flex-col gap-4 pt-6 md:p-10'>
        <div className='flex justify-between items-center'></div>
        <div className='flex flex-1 items-center justify-center'>
          <div className='w-full max-w-xs'>{children}</div>
        </div>
      </div>
      <div className='relative hidden bg-muted lg:block overflow-hidden'>
        <Image
          src='/assets/login-bg.jpg'
          alt='Image'
          fill
          className='absolute inset-0 h-full w-full object-cover'
        />
      </div>
    </main>
  )
}
