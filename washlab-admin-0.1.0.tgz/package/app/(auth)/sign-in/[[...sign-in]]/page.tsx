"use client"

import { useAuth } from "@clerk/nextjs"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { SignIn } from "@clerk/nextjs"
import LoginForm from "@/components/Auth/login-form"

export default function SignInPage() {
  const { isSignedIn, isLoaded } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (isLoaded && isSignedIn) {
      router.push("/dashboard")
    }
  }, [isLoaded, isSignedIn, router])

  return (
    // <LoginForm />
    <div className='flex items-center justify-center'>
      <SignIn
        appearance={{
          elements: { rootBox: "mx-auto", footerAction: { display: "none" } },
        }}
        routing='path'
        path='/sign-in'
      />
    </div>
  )
}
