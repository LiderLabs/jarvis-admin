/**
 * Action Execution Functions
 *
 * Handles attendance-linked action execution with verification.
 * All critical actions must be linked to an active attendance session.
 */
import { MutationCtx } from "./_generated/server";
import { Id } from "./_generated/dataModel";
/**
 * Create action log entry (attendance-linked)
 * This is called after verifying attendance and executing the action
 * Note: This function requires MutationCtx for insert operations
 */
export declare function createActionLog(ctx: MutationCtx, attendanceId: Id<"attendanceLogs">, attendantId: Id<"attendants">, branchId: Id<"branches">, actionType: string, entityType: string, entityId: string | Id<"orders">, deviceId?: string, metadata?: Record<string, any>, actionStatus?: "pending" | "completed" | "failed" | "cancelled"): Promise<Id<"actionLogs">>;
/**
 * Execute action with attendance verification
 * This is the main entry point for critical actions
 */
export declare const executeAction: import("convex/server").RegisteredMutation<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    deviceId?: string | undefined;
    metadata?: string | undefined;
    entityType: string;
    entityId: string;
    actionType: string;
}, Promise<{
    success: boolean;
    actionLogId: Id<"actionLogs">;
    attendanceId: import("convex/values").GenericId<"attendanceLogs">;
    timestamp: number;
}>>;
/**
 * Get actions by attendance session
 */
export declare const getActionsByAttendance: import("convex/server").RegisteredQuery<"public", {
    attendanceId: import("convex/values").GenericId<"attendanceLogs">;
}, Promise<{
    _id: import("convex/values").GenericId<"actionLogs">;
    _creationTime: number;
    amount?: number | undefined;
    completedAt?: number | undefined;
    verificationId?: import("convex/values").GenericId<"biometricVerifications"> | undefined;
    entityType?: string | undefined;
    entityId?: import("convex/values").GenericId<"orders"> | undefined;
    errorMessage?: string | undefined;
    actionData?: string | undefined;
    verificationMethod?: "biometric_face" | "biometric_hand" | "pin" | "password" | undefined;
    createdAt: number;
    branchId: import("convex/values").GenericId<"branches">;
    attendantId: import("convex/values").GenericId<"attendants">;
    attendanceId: import("convex/values").GenericId<"attendanceLogs">;
    actionType: string;
    actionStatus: "completed" | "cancelled" | "pending" | "failed";
}[]>>;
/**
 * Get actions by attendant (with pagination)
 */
export declare const getActionsByAttendant: import("convex/server").RegisteredQuery<"public", {
    attendantId: import("convex/values").GenericId<"attendants">;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<import("convex/server").PaginationResult<{
    _id: import("convex/values").GenericId<"actionLogs">;
    _creationTime: number;
    amount?: number | undefined;
    completedAt?: number | undefined;
    verificationId?: import("convex/values").GenericId<"biometricVerifications"> | undefined;
    entityType?: string | undefined;
    entityId?: import("convex/values").GenericId<"orders"> | undefined;
    errorMessage?: string | undefined;
    actionData?: string | undefined;
    verificationMethod?: "biometric_face" | "biometric_hand" | "pin" | "password" | undefined;
    createdAt: number;
    branchId: import("convex/values").GenericId<"branches">;
    attendantId: import("convex/values").GenericId<"attendants">;
    attendanceId: import("convex/values").GenericId<"attendanceLogs">;
    actionType: string;
    actionStatus: "completed" | "cancelled" | "pending" | "failed";
}>>>;
/**
 * Get actions by branch (with pagination)
 */
export declare const getActionsByBranch: import("convex/server").RegisteredQuery<"public", {
    actionType?: string | undefined;
    startDate?: number | undefined;
    endDate?: number | undefined;
    branchId: import("convex/values").GenericId<"branches">;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<import("convex/server").PaginationResult<{
    _id: import("convex/values").GenericId<"actionLogs">;
    _creationTime: number;
    amount?: number | undefined;
    completedAt?: number | undefined;
    verificationId?: import("convex/values").GenericId<"biometricVerifications"> | undefined;
    entityType?: string | undefined;
    entityId?: import("convex/values").GenericId<"orders"> | undefined;
    errorMessage?: string | undefined;
    actionData?: string | undefined;
    verificationMethod?: "biometric_face" | "biometric_hand" | "pin" | "password" | undefined;
    createdAt: number;
    branchId: import("convex/values").GenericId<"branches">;
    attendantId: import("convex/values").GenericId<"attendants">;
    attendanceId: import("convex/values").GenericId<"attendanceLogs">;
    actionType: string;
    actionStatus: "completed" | "cancelled" | "pending" | "failed";
}>>>;
/**
 * Get actions by entity (e.g., all actions on a specific order)
 * Note: Currently only supports orders as entityType due to schema limitation
 * This query is not optimized for large datasets - consider using pagination or adding an index
 */
export declare const getActionsByEntity: import("convex/server").RegisteredQuery<"public", {
    entityType: string;
    entityId: import("convex/values").GenericId<"orders">;
}, Promise<{
    _id: import("convex/values").GenericId<"actionLogs">;
    _creationTime: number;
    amount?: number | undefined;
    completedAt?: number | undefined;
    verificationId?: import("convex/values").GenericId<"biometricVerifications"> | undefined;
    entityType?: string | undefined;
    entityId?: import("convex/values").GenericId<"orders"> | undefined;
    errorMessage?: string | undefined;
    actionData?: string | undefined;
    verificationMethod?: "biometric_face" | "biometric_hand" | "pin" | "password" | undefined;
    createdAt: number;
    branchId: import("convex/values").GenericId<"branches">;
    attendantId: import("convex/values").GenericId<"attendants">;
    attendanceId: import("convex/values").GenericId<"attendanceLogs">;
    actionType: string;
    actionStatus: "completed" | "cancelled" | "pending" | "failed";
}[]>>;
/**
 * Get action statistics for an attendance session
 */
export declare const getAttendanceActionStats: import("convex/server").RegisteredQuery<"public", {
    attendanceId: import("convex/values").GenericId<"attendanceLogs">;
}, Promise<{
    totalActions: number;
    actionsByType: Record<string, number>;
    firstAction: number | null;
    lastAction: number | null;
    durationMinutes: number | null;
}>>;
//# sourceMappingURL=actions.d.ts.map