/**
 * Branch Functions
 *
 * Handles branch information queries for customers and public access.
 */
/**
 * Get all active branches
 * Public query - can be used by customers and guests
 */
export declare const getActive: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    _id: import("convex/values").GenericId<"branches">;
    name: string;
    code: string;
    address: string;
    city: string;
    country: string;
    phoneNumber: string;
    email: string | undefined;
    pricingPerKg: number;
    deliveryFee: number;
    isActive: boolean;
    createdAt: number;
}[]>>;
//# sourceMappingURL=branches.d.ts.map