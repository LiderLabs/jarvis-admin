import { Id } from "./_generated/dataModel";
/**
 * Customer Functions
 *
 * Handles customer profile management, registration, and lookups.
 * Customers can be guests (walk-in, no account) or registered (with Clerk account).
 */
/**
 * Get customer by phone number
 * Used by POS for walk-in customer lookup
 */
/**
 * Get customer by phone number
 * Used by POS for walk-in customer lookup
 */
export declare const getByPhone: import("convex/server").RegisteredQuery<"public", {
    phoneNumber: string;
}, Promise<{
    _id: import("convex/values").GenericId<"users">;
    _creationTime: number;
    email?: string | undefined;
    clerkUserId?: string | undefined;
    status?: "active" | "blocked" | "suspended" | "restricted" | undefined;
    statusNote?: string | undefined;
    statusChangedBy?: import("convex/values").GenericId<"admins"> | undefined;
    statusChangedAt?: number | undefined;
    lastLoginAt?: number | undefined;
    preferredBranchId?: import("convex/values").GenericId<"branches"> | undefined;
    phoneNumber: string;
    name: string;
    isRegistered: boolean;
    isVerified: boolean;
    createdAt: number;
    isDeleted: boolean;
} | null>>;
/**
 * Check if authenticated user is an admin or attendant
 * Returns true if user is admin/attendant (should be blocked from customer app)
 */
export declare const checkIsAdminOrAttendant: import("convex/server").RegisteredQuery<"public", {}, Promise<boolean>>;
/**
 * Get current customer profile (from authenticated Clerk session)
 * Returns null if customer hasn't completed registration yet
 * Returns null if user is admin/attendant (will be handled by unauthorized page)
 */
export declare const getProfile: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    orderCount: number;
    completedOrderCount: number;
    _id: import("convex/values").GenericId<"users">;
    _creationTime: number;
    email?: string | undefined;
    clerkUserId?: string | undefined;
    status?: "active" | "blocked" | "suspended" | "restricted" | undefined;
    statusNote?: string | undefined;
    statusChangedBy?: import("convex/values").GenericId<"admins"> | undefined;
    statusChangedAt?: number | undefined;
    lastLoginAt?: number | undefined;
    preferredBranchId?: import("convex/values").GenericId<"branches"> | undefined;
    phoneNumber: string;
    name: string;
    isRegistered: boolean;
    isVerified: boolean;
    createdAt: number;
    isDeleted: boolean;
} | null>>;
/**
 * Get customer order history - Paginated
 * Supports usePaginatedQuery for infinite scroll
 * Returns empty results if customer not found
 */
export declare const getOrders: import("convex/server").RegisteredQuery<"public", {
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        _id: import("convex/values").GenericId<"orders">;
        _creationTime: number;
        createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
        customerEmail?: string | undefined;
        estimatedWeight?: number | undefined;
        actualWeight?: number | undefined;
        itemCount?: number | undefined;
        estimatedLoads?: number | undefined;
        whitesSeparate?: boolean | undefined;
        bagCardNumber?: string | undefined;
        notes?: string | undefined;
        deliveryAddress?: string | undefined;
        deliveryPhoneNumber?: string | undefined;
        deliveryHall?: string | undefined;
        deliveryRoom?: string | undefined;
        paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
        paymentId?: import("convex/values").GenericId<"payments"> | undefined;
        assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
        fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
        status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        deliveryFee: number;
        customerId: import("convex/values").GenericId<"users">;
        customerPhoneNumber: string;
        orderNumber: string;
        orderType: "walk_in" | "online";
        serviceType: "wash_only" | "wash_and_dry" | "dry_only";
        isDelivery: boolean;
        basePrice: number;
        totalPrice: number;
        finalPrice: number;
        paymentStatus: "pending" | "paid" | "failed" | "refunded";
        updatedAt: number;
        statusHistory: {
            notes?: string | undefined;
            changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
            changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
            status: string;
            changedAt: number;
        }[];
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Get active orders for customer (not cancelled or completed)
 * Returns orders that are still in progress
 */
export declare const getActiveOrders: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    _id: import("convex/values").GenericId<"orders">;
    _creationTime: number;
    createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
    customerEmail?: string | undefined;
    estimatedWeight?: number | undefined;
    actualWeight?: number | undefined;
    itemCount?: number | undefined;
    estimatedLoads?: number | undefined;
    whitesSeparate?: boolean | undefined;
    bagCardNumber?: string | undefined;
    notes?: string | undefined;
    deliveryAddress?: string | undefined;
    deliveryPhoneNumber?: string | undefined;
    deliveryHall?: string | undefined;
    deliveryRoom?: string | undefined;
    paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
    paymentId?: import("convex/values").GenericId<"payments"> | undefined;
    assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
    fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
    status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    deliveryFee: number;
    customerId: import("convex/values").GenericId<"users">;
    customerPhoneNumber: string;
    orderNumber: string;
    orderType: "walk_in" | "online";
    serviceType: "wash_only" | "wash_and_dry" | "dry_only";
    isDelivery: boolean;
    basePrice: number;
    totalPrice: number;
    finalPrice: number;
    paymentStatus: "pending" | "paid" | "failed" | "refunded";
    updatedAt: number;
    statusHistory: {
        notes?: string | undefined;
        changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
        changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
        status: string;
        changedAt: number;
    }[];
}[]>>;
/**
 * Get customer loyalty points balance
 * Returns zero points if customer not found
 */
export declare const getLoyaltyPoints: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    points: number;
    totalEarned: number;
    totalRedeemed: number;
    lastEarnedAt?: undefined;
    lastRedeemedAt?: undefined;
} | {
    points: number;
    totalEarned: number;
    totalRedeemed: number;
    lastEarnedAt: number | undefined;
    lastRedeemedAt: number | undefined;
}>>;
/**
 * Create guest customer (walk-in, no Clerk account)
 * Used when creating walk-in orders at POS
 */
export declare const createGuest: import("convex/server").RegisteredMutation<"public", {
    phoneNumber: string;
    email: string;
    name: string;
}, Promise<import("convex/values").GenericId<"users">>>;
/**
 * Register customer (link Clerk account to customer profile)
 * Called after customer signs up via Clerk
 */
export declare const register: import("convex/server").RegisteredMutation<"public", {
    email?: string | undefined;
    phoneNumber: string;
    name: string;
}, Promise<Id<"users">>>;
/**
 * Update customer profile
 */
export declare const updateProfile: import("convex/server").RegisteredMutation<"public", {
    phoneNumber?: string | undefined;
    email?: string | undefined;
    name?: string | undefined;
    preferredBranchId?: import("convex/values").GenericId<"branches"> | undefined;
}, Promise<import("convex/values").GenericId<"users">>>;
/**
 * Create test user (DEV ONLY)
 *
 * This mutation allows creating test users in development without requiring
 * Clerk authentication. Useful for testing and development.
 *
 * WARNING: This should only be used in development environments.
 * In production, users should be created via Clerk webhooks or the register mutation.
 */
export declare const createTestUser: import("convex/server").RegisteredMutation<"public", {
    email?: string | undefined;
    clerkUserId?: string | undefined;
    isRegistered?: boolean | undefined;
    isVerified?: boolean | undefined;
    phoneNumber: string;
    name: string;
}, Promise<import("convex/values").GenericId<"users">>>;
/**
 * Search customers by name or phone number
 * Used by POS for customer lookup
 */
export declare const search: import("convex/server").RegisteredQuery<"public", {
    limit?: number | undefined;
    query: string;
}, Promise<{
    orderCount: number;
    completedOrderCount: number;
    totalSpent: number;
    lastOrderDate: number;
    _id: import("convex/values").GenericId<"users">;
    _creationTime: number;
    email?: string | undefined;
    clerkUserId?: string | undefined;
    status?: "active" | "blocked" | "suspended" | "restricted" | undefined;
    statusNote?: string | undefined;
    statusChangedBy?: import("convex/values").GenericId<"admins"> | undefined;
    statusChangedAt?: number | undefined;
    lastLoginAt?: number | undefined;
    preferredBranchId?: import("convex/values").GenericId<"branches"> | undefined;
    phoneNumber: string;
    name: string;
    isRegistered: boolean;
    isVerified: boolean;
    createdAt: number;
    isDeleted: boolean;
}[]>>;
/**
 * Get customer details with full order history
 */
export declare const getDetails: import("convex/server").RegisteredQuery<"public", {
    customerId: import("convex/values").GenericId<"users">;
}, Promise<{
    orderCount: number;
    completedOrderCount: number;
    totalSpent: number;
    averageOrderValue: number;
    loyaltyPoints: number;
    lastOrderDate: number;
    lastOrderNumber: string;
    _id: import("convex/values").GenericId<"users">;
    _creationTime: number;
    email?: string | undefined;
    clerkUserId?: string | undefined;
    status?: "active" | "blocked" | "suspended" | "restricted" | undefined;
    statusNote?: string | undefined;
    statusChangedBy?: import("convex/values").GenericId<"admins"> | undefined;
    statusChangedAt?: number | undefined;
    lastLoginAt?: number | undefined;
    preferredBranchId?: import("convex/values").GenericId<"branches"> | undefined;
    phoneNumber: string;
    name: string;
    isRegistered: boolean;
    isVerified: boolean;
    createdAt: number;
    isDeleted: boolean;
}>>;
//# sourceMappingURL=customers.d.ts.map