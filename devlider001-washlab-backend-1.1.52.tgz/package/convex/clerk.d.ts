/**
 * Internal Clerk Webhook Mutations
 *
 * These mutations are called from the webhook handler to sync Clerk user data
 * with our database. They are internal (not exposed to clients) for security.
 */
/**
 * Sync user created event from Clerk
 */
export declare const syncUserCreated: import("convex/server").RegisteredMutation<"internal", {
    phoneNumber?: string | undefined;
    email?: string | undefined;
    userType?: "admin" | "customer" | "attendant" | undefined;
    name: string;
    clerkUserId: string;
    emailVerified: boolean;
}, Promise<import("convex/values").GenericId<"admins"> | import("convex/values").GenericId<"users"> | import("convex/values").GenericId<"attendants"> | null>>;
/**
 * Sync user updated event from Clerk
 */
export declare const syncUserUpdated: import("convex/server").RegisteredMutation<"internal", {
    phoneNumber?: string | undefined;
    email?: string | undefined;
    userType?: "admin" | "customer" | "attendant" | undefined;
    name: string;
    clerkUserId: string;
    emailVerified: boolean;
}, Promise<{
    type: string;
    id: import("convex/values").GenericId<"admins">;
} | {
    type: string;
    id: import("convex/values").GenericId<"users">;
} | {
    type: string;
    id: import("convex/values").GenericId<"attendants">;
} | null>>;
/**
 * Sync user deleted event from Clerk
 */
export declare const syncUserDeleted: import("convex/server").RegisteredMutation<"internal", {
    clerkUserId: string;
}, Promise<{
    type: string;
    id: import("convex/values").GenericId<"users">;
} | {
    type: string;
    id: import("convex/values").GenericId<"attendants">;
} | {
    type: string;
    id: import("convex/values").GenericId<"admins">;
} | null>>;
//# sourceMappingURL=clerk.d.ts.map