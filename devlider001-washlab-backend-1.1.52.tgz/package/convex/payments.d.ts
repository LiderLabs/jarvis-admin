/**
 * Payment Functions
 *
 * Handles payment creation, confirmation, and refunds.
 */
/**
 * Get payment by order ID
 */
export declare const getByOrder: import("convex/server").RegisteredQuery<"public", {
    orderId: import("convex/values").GenericId<"orders">;
}, Promise<{
    _id: import("convex/values").GenericId<"payments">;
    _creationTime: number;
    gatewayTransactionId?: string | undefined;
    gatewayResponse?: string | undefined;
    completedAt?: number | undefined;
    processedBy?: import("convex/values").GenericId<"attendants"> | undefined;
    verificationId?: import("convex/values").GenericId<"biometricVerifications"> | undefined;
    status: "completed" | "pending" | "failed" | "refunded" | "processing";
    createdAt: number;
    isDeleted: boolean;
    customerId: import("convex/values").GenericId<"users">;
    paymentMethod: "mobile_money" | "card" | "cash";
    orderId: import("convex/values").GenericId<"orders">;
    amount: number;
    currency: string;
} | null>>;
/**
 * Get payment history by customer - Paginated
 * Supports usePaginatedQuery for infinite scroll
 */
export declare const getByCustomer: import("convex/server").RegisteredQuery<"public", {
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        order: {
            _id: import("convex/values").GenericId<"orders">;
            _creationTime: number;
            createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
            customerEmail?: string | undefined;
            estimatedWeight?: number | undefined;
            actualWeight?: number | undefined;
            itemCount?: number | undefined;
            estimatedLoads?: number | undefined;
            whitesSeparate?: boolean | undefined;
            bagCardNumber?: string | undefined;
            notes?: string | undefined;
            deliveryAddress?: string | undefined;
            deliveryPhoneNumber?: string | undefined;
            deliveryHall?: string | undefined;
            deliveryRoom?: string | undefined;
            paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
            paymentId?: import("convex/values").GenericId<"payments"> | undefined;
            assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
            fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
            status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
            createdAt: number;
            isDeleted: boolean;
            branchId: import("convex/values").GenericId<"branches">;
            deliveryFee: number;
            customerId: import("convex/values").GenericId<"users">;
            customerPhoneNumber: string;
            orderNumber: string;
            orderType: "walk_in" | "online";
            serviceType: "wash_only" | "wash_and_dry" | "dry_only";
            isDelivery: boolean;
            basePrice: number;
            totalPrice: number;
            finalPrice: number;
            paymentStatus: "pending" | "paid" | "failed" | "refunded";
            updatedAt: number;
            statusHistory: {
                notes?: string | undefined;
                changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
                changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
                status: string;
                changedAt: number;
            }[];
        } | null;
        _id: import("convex/values").GenericId<"payments">;
        _creationTime: number;
        gatewayTransactionId?: string | undefined;
        gatewayResponse?: string | undefined;
        completedAt?: number | undefined;
        processedBy?: import("convex/values").GenericId<"attendants"> | undefined;
        verificationId?: import("convex/values").GenericId<"biometricVerifications"> | undefined;
        status: "completed" | "pending" | "failed" | "refunded" | "processing";
        createdAt: number;
        isDeleted: boolean;
        customerId: import("convex/values").GenericId<"users">;
        paymentMethod: "mobile_money" | "card" | "cash";
        orderId: import("convex/values").GenericId<"orders">;
        amount: number;
        currency: string;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Create payment record
 * ✅ Idempotent: returns existing payment ID if one already exists for this order
 */
export declare const create: import("convex/server").RegisteredMutation<"public", {
    currency?: string | undefined;
    paymentMethod: "mobile_money" | "card" | "cash";
    orderId: import("convex/values").GenericId<"orders">;
    amount: number;
}, Promise<import("convex/values").GenericId<"payments">>>;
/**
 * Initiate payment (for gateway integration)
 * ✅ Idempotent: if payment is already processing or beyond, returns current
 *    status silently instead of throwing.
 *
 * Fixes "Payment already processed" error that hits online orders when:
 *   - Attendant navigates back from payment page and returns
 *   - createPayment returns existing ID (already in "processing" state)
 *   - initiatePayment would previously throw — now it just returns safely
 */
export declare const initiate: import("convex/server").RegisteredMutation<"public", {
    paymentId: import("convex/values").GenericId<"payments">;
}, Promise<{
    paymentId: import("convex/values").GenericId<"payments">;
    status: string;
}>>;
/**
 * Confirm payment completion
 */
export declare const confirm: import("convex/server").RegisteredMutation<"public", {
    gatewayTransactionId?: string | undefined;
    gatewayResponse?: string | undefined;
    paymentId: import("convex/values").GenericId<"payments">;
}, Promise<import("convex/values").GenericId<"payments">>>;
/**
 * Mark payment as failed
 */
export declare const fail: import("convex/server").RegisteredMutation<"public", {
    reason?: string | undefined;
    paymentId: import("convex/values").GenericId<"payments">;
}, Promise<import("convex/values").GenericId<"payments">>>;
/**
 * Process refund
 */
export declare const refund: import("convex/server").RegisteredMutation<"public", {
    reason?: string | undefined;
    paymentId: import("convex/values").GenericId<"payments">;
}, Promise<import("convex/values").GenericId<"payments">>>;
/**
 * Get transaction history - Paginated
 */
export declare const getTransactionHistory: import("convex/server").RegisteredQuery<"public", {
    status?: "completed" | "pending" | "failed" | "refunded" | "processing" | undefined;
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
    startDate?: number | undefined;
    endDate?: number | undefined;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        order: {
            _id: import("convex/values").GenericId<"orders">;
            _creationTime: number;
            createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
            customerEmail?: string | undefined;
            estimatedWeight?: number | undefined;
            actualWeight?: number | undefined;
            itemCount?: number | undefined;
            estimatedLoads?: number | undefined;
            whitesSeparate?: boolean | undefined;
            bagCardNumber?: string | undefined;
            notes?: string | undefined;
            deliveryAddress?: string | undefined;
            deliveryPhoneNumber?: string | undefined;
            deliveryHall?: string | undefined;
            deliveryRoom?: string | undefined;
            paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
            paymentId?: import("convex/values").GenericId<"payments"> | undefined;
            assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
            fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
            status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
            createdAt: number;
            isDeleted: boolean;
            branchId: import("convex/values").GenericId<"branches">;
            deliveryFee: number;
            customerId: import("convex/values").GenericId<"users">;
            customerPhoneNumber: string;
            orderNumber: string;
            orderType: "walk_in" | "online";
            serviceType: "wash_only" | "wash_and_dry" | "dry_only";
            isDelivery: boolean;
            basePrice: number;
            totalPrice: number;
            finalPrice: number;
            paymentStatus: "pending" | "paid" | "failed" | "refunded";
            updatedAt: number;
            statusHistory: {
                notes?: string | undefined;
                changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
                changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
                status: string;
                changedAt: number;
            }[];
        } | null;
        customer: {
            _id: import("convex/values").GenericId<"users">;
            _creationTime: number;
            email?: string | undefined;
            clerkUserId?: string | undefined;
            status?: "active" | "blocked" | "suspended" | "restricted" | undefined;
            statusNote?: string | undefined;
            statusChangedBy?: import("convex/values").GenericId<"admins"> | undefined;
            statusChangedAt?: number | undefined;
            lastLoginAt?: number | undefined;
            preferredBranchId?: import("convex/values").GenericId<"branches"> | undefined;
            phoneNumber: string;
            name: string;
            isRegistered: boolean;
            isVerified: boolean;
            createdAt: number;
            isDeleted: boolean;
        } | null;
        branch: {
            _id: import("convex/values").GenericId<"branches">;
            _creationTime: number;
            email?: string | undefined;
            terminalId?: string | undefined;
            stationPinHash?: string | undefined;
            requireStationLogin?: boolean | undefined;
            phoneNumber: string;
            name: string;
            createdAt: number;
            isDeleted: boolean;
            isActive: boolean;
            createdBy: import("convex/values").GenericId<"admins">;
            code: string;
            address: string;
            city: string;
            country: string;
            pricingPerKg: number;
            deliveryFee: number;
        } | null;
        _id: import("convex/values").GenericId<"payments">;
        _creationTime: number;
        gatewayTransactionId?: string | undefined;
        gatewayResponse?: string | undefined;
        completedAt?: number | undefined;
        processedBy?: import("convex/values").GenericId<"attendants"> | undefined;
        verificationId?: import("convex/values").GenericId<"biometricVerifications"> | undefined;
        status: "completed" | "pending" | "failed" | "refunded" | "processing";
        createdAt: number;
        isDeleted: boolean;
        customerId: import("convex/values").GenericId<"users">;
        paymentMethod: "mobile_money" | "card" | "cash";
        orderId: import("convex/values").GenericId<"orders">;
        amount: number;
        currency: string;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Get transaction summary statistics
 */
export declare const getTransactionSummary: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    startDate?: number | undefined;
    endDate?: number | undefined;
}, Promise<{
    totalTransactions: number;
    totalAmount: number;
    averageTransaction: number;
    byMethod: Record<string, number>;
    byStatus: Record<string, number>;
}>>;
/**
 * finalizePaymentSafe
 *
 * The single authoritative mutation to complete a payment.
 * Replaces all direct calls to confirm() from the frontend.
 *
 * Guards against:
 *   - Double completion (idempotent — returns alreadyCompleted if already paid)
 *   - Missing or invalid biometric verification
 *   - Missing payment record for the order
 */
export declare const finalizePaymentSafe: import("convex/server").RegisteredMutation<"public", {
    gatewayTransactionId?: string | undefined;
    gatewayResponse?: string | undefined;
    orderId: import("convex/values").GenericId<"orders">;
    verificationId: import("convex/values").GenericId<"biometricVerifications">;
}, Promise<{
    alreadyCompleted: boolean;
    success?: undefined;
} | {
    success: boolean;
    alreadyCompleted?: undefined;
}>>;
//# sourceMappingURL=payments.d.ts.map