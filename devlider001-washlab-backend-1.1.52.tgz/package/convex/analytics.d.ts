import { Id } from "./_generated/dataModel";
/**
 * Analytics Functions
 *
 * Comprehensive analytics and aggregations for dashboard, reports, and insights.
 */
/**
 * Get dashboard overview statistics
 */
export declare const getDashboardStats: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    startDate?: number | undefined;
    endDate?: number | undefined;
}, Promise<{
    totalOrders: number;
    totalRevenue: number;
    completedOrders: number;
    pendingOrders: number;
    walkInOrders: number;
    onlineOrders: number;
    averageOrderValue: number;
    ordersByStatus: Record<string, number>;
    ordersByDay: Record<string, number>;
    revenueByDay: Record<string, number>;
    ordersByServiceType: Record<string, number>;
    ordersByPaymentMethod: Record<string, number>;
    dateRange: {
        start: number;
        end: number;
    };
}>>;
/**
 * Get today's statistics
 */
export declare const getTodayStats: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
}, Promise<{
    totalOrders: number;
    totalRevenue: number;
    completedOrders: number;
    pendingOrders: number;
    walkInOrders: number;
    onlineOrders: number;
}>>;
/**
 * Get top customers by order count
 */
export declare const getTopCustomers: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    startDate?: number | undefined;
    endDate?: number | undefined;
    limit?: number | undefined;
}, Promise<{
    customerId: Id<"users">;
    name: string;
    phoneNumber: string;
    orderCount: number;
    totalRevenue: number;
    averageOrderValue: number;
}[]>>;
/**
 * Get revenue trends (daily/weekly/monthly)
 */
export declare const getRevenueTrends: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    days?: number | undefined;
    period: "daily" | "weekly" | "monthly";
}, Promise<{
    period: string;
    revenue: number;
    orders: number;
}[]>>;
/**
 * Get branch performance comparison
 */
export declare const getBranchPerformance: import("convex/server").RegisteredQuery<"public", {
    startDate?: number | undefined;
    endDate?: number | undefined;
}, Promise<{
    branchId: import("convex/values").GenericId<"branches">;
    branchName: string;
    totalOrders: number;
    totalRevenue: number;
    completedOrders: number;
    averageOrderValue: number;
}[]>>;
//# sourceMappingURL=analytics.d.ts.map