/**
 * Loyalty Functions
 *
 * Handles loyalty points earning, redemption, and balance management.
 * Rules: 1 point per completed order, 10 points = 1 free wash.
 */
/**
 * Get customer loyalty points balance
 */
export declare const getBalance: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    points: number;
    totalEarned: number;
    totalRedeemed: number;
    lastEarnedAt: number | undefined;
    lastRedeemedAt: number | undefined;
}>>;
/**
 * Get loyalty transaction history - Paginated
 * Supports usePaginatedQuery for infinite scroll
 */
export declare const getTransactions: import("convex/server").RegisteredQuery<"public", {
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        _id: import("convex/values").GenericId<"loyaltyTransactions">;
        _creationTime: number;
        createdBy?: import("convex/values").GenericId<"admins"> | undefined;
        orderId?: import("convex/values").GenericId<"orders"> | undefined;
        description?: string | undefined;
        type: "earned" | "redeemed" | "expired" | "adjusted";
        createdAt: number;
        isDeleted: boolean;
        customerId: import("convex/values").GenericId<"users">;
        points: number;
        balanceAfter: number;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Admin: Get all loyalty points balances (paginated)
 */
export declare const getAllLoyaltyPoints: import("convex/server").RegisteredQuery<"public", {
    searchQuery?: string | undefined;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        customer: {
            _id: import("convex/values").GenericId<"users">;
            name: string;
            phoneNumber: string;
            email: string | undefined;
        } | null;
        _id: import("convex/values").GenericId<"loyaltyPoints">;
        _creationTime: number;
        lastEarnedAt?: number | undefined;
        lastRedeemedAt?: number | undefined;
        isDeleted: boolean;
        customerId: import("convex/values").GenericId<"users">;
        points: number;
        totalEarned: number;
        totalRedeemed: number;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Admin: Get all loyalty transactions (paginated)
 */
export declare const getAllTransactions: import("convex/server").RegisteredQuery<"public", {
    type?: "earned" | "redeemed" | "adjusted" | undefined;
    customerId?: import("convex/values").GenericId<"users"> | undefined;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        customer: {
            _id: import("convex/values").GenericId<"users">;
            name: string;
            phoneNumber: string;
            email: string | undefined;
        } | null;
        order: {
            _id: import("convex/values").GenericId<"orders">;
            orderNumber: string;
        } | null;
        adjustedBy: {
            _id: import("convex/values").GenericId<"admins">;
            name: string;
            email: string;
        } | null;
        _id: import("convex/values").GenericId<"loyaltyTransactions">;
        _creationTime: number;
        createdBy?: import("convex/values").GenericId<"admins"> | undefined;
        orderId?: import("convex/values").GenericId<"orders"> | undefined;
        description?: string | undefined;
        type: "earned" | "redeemed" | "expired" | "adjusted";
        createdAt: number;
        isDeleted: boolean;
        customerId: import("convex/values").GenericId<"users">;
        points: number;
        balanceAfter: number;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Admin: Get loyalty points for a specific customer
 */
export declare const getCustomerLoyaltyPoints: import("convex/server").RegisteredQuery<"public", {
    customerId: import("convex/values").GenericId<"users">;
}, Promise<{
    points: number;
    totalEarned: number;
    totalRedeemed: number;
    lastEarnedAt: undefined;
    lastRedeemedAt: undefined;
    customerId: import("convex/values").GenericId<"users">;
    customer?: undefined;
} | {
    points: number;
    totalEarned: number;
    totalRedeemed: number;
    lastEarnedAt: number | undefined;
    lastRedeemedAt: number | undefined;
    customerId: import("convex/values").GenericId<"users">;
    customer: {
        _id: import("convex/values").GenericId<"users">;
        name: string;
        phoneNumber: string;
        email: string | undefined;
    } | null;
}>>;
/**
 * Earn loyalty points (internal - called when order is completed)
 */
export declare const earnPoints: import("convex/server").RegisteredMutation<"internal", {
    customerId: import("convex/values").GenericId<"users">;
    orderId: import("convex/values").GenericId<"orders">;
    points: number;
}, Promise<{
    skipped: boolean;
    reason: string;
    success?: undefined;
    pointsAwarded?: undefined;
} | {
    success: boolean;
    pointsAwarded: number;
    skipped?: undefined;
    reason?: undefined;
}>>;
/**
 * Redeem loyalty points for free wash
 */
export declare const redeemPoints: import("convex/server").RegisteredMutation<"public", {
    orderId: import("convex/values").GenericId<"orders">;
    pointsToRedeem: number;
}, Promise<{
    pointsRedeemed: number;
    newBalance: number;
    discountAmount: number;
    finalPrice: number;
}>>;
/**
 * Adjust loyalty points (admin only)
 */
export declare const adjustPoints: import("convex/server").RegisteredMutation<"public", {
    customerId: import("convex/values").GenericId<"users">;
    points: number;
    description: string;
}, Promise<{
    _id: import("convex/values").GenericId<"loyaltyPoints">;
    _creationTime: number;
    lastEarnedAt?: number | undefined;
    lastRedeemedAt?: number | undefined;
    isDeleted: boolean;
    customerId: import("convex/values").GenericId<"users">;
    points: number;
    totalEarned: number;
    totalRedeemed: number;
}>>;
//# sourceMappingURL=loyalty.d.ts.map