import { Id } from "./_generated/dataModel";
/**
 * Resource Usage Functions
 *
 * Handles daily resource consumption tracking (detergent, tokens, water cycles).
 * Used by attendants to log daily resource usage at branches.
 */
/**
 * Get resource usage by branch
 */
export declare const getByBranch: import("convex/server").RegisteredQuery<"public", {
    startDate?: string | undefined;
    endDate?: string | undefined;
    limit?: number | undefined;
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<{
    _id: import("convex/values").GenericId<"resourceUsageLogs">;
    _creationTime: number;
    notes?: string | undefined;
    waterCycles?: number | undefined;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    attendantId: import("convex/values").GenericId<"attendants">;
    date: string;
    detergentUnits: number;
    tokensUsed: number;
    loggedAt: number;
}[]>>;
/**
 * Get resource usage by date
 */
export declare const getByDate: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    date: string;
}, Promise<{
    _id: import("convex/values").GenericId<"resourceUsageLogs">;
    _creationTime: number;
    notes?: string | undefined;
    waterCycles?: number | undefined;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    attendantId: import("convex/values").GenericId<"attendants">;
    date: string;
    detergentUnits: number;
    tokensUsed: number;
    loggedAt: number;
}[]>>;
/**
 * Get daily resource report for a branch
 */
export declare const getDailyReport: import("convex/server").RegisteredQuery<"public", {
    branchId: import("convex/values").GenericId<"branches">;
    date: string;
}, Promise<{
    date: string;
    branchId: import("convex/values").GenericId<"branches">;
    logs: {
        _id: import("convex/values").GenericId<"resourceUsageLogs">;
        _creationTime: number;
        notes?: string | undefined;
        waterCycles?: number | undefined;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        attendantId: import("convex/values").GenericId<"attendants">;
        date: string;
        detergentUnits: number;
        tokensUsed: number;
        loggedAt: number;
    }[];
    totals: {
        detergentUnits: number;
        tokensUsed: number;
        waterCycles: number;
    };
    logCount: number;
}>>;
/**
 * Log daily resource usage
 */
export declare const logUsage: import("convex/server").RegisteredMutation<"public", {
    notes?: string | undefined;
    date?: string | undefined;
    waterCycles?: number | undefined;
    branchId: import("convex/values").GenericId<"branches">;
    detergentUnits: number;
    tokensUsed: number;
}, Promise<Id<"resourceUsageLogs">>>;
/**
 * Get resource usage summary for date range
 */
export declare const getUsageSummary: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    startDate?: string | undefined;
    endDate?: string | undefined;
}, Promise<{
    totals: {
        detergentUnits: number;
        tokensUsed: number;
        waterCycles: number;
    };
    averagePerDay: {
        detergentUnits: number;
        tokensUsed: number;
        waterCycles: number;
    };
    usageByDay: Record<string, {
        detergentUnits: number;
        tokensUsed: number;
        waterCycles: number;
        logCount: number;
    }>;
    totalLogs: number;
    uniqueDays: number;
    dateRange: {
        start: string | undefined;
        end: string | undefined;
    };
}>>;
//# sourceMappingURL=resources.d.ts.map