export declare const exportTable: import("convex/server").RegisteredQuery<"public", {
    table: string;
}, Promise<any>>;
export declare const importRow: import("convex/server").RegisteredMutation<"public", {
    table: string;
    data: any;
}, Promise<void>>;
//# sourceMappingURL=migration.d.ts.map