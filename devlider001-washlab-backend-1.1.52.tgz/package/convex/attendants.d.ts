/**
 * Attendant Functions
 *
 * Handles attendant authentication, attendance clock-in/out, and profile queries.
 */
/**
 * Get attendants by branch (admin/attendant view)
 */
export declare const getByBranch: import("convex/server").RegisteredQuery<"public", {
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<{
    _id: import("convex/values").GenericId<"attendants">;
    _creationTime: number;
    clerkUserId?: string | undefined;
    lastLoginAt?: number | undefined;
    passcodeHash?: string | undefined;
    passcodeSalt?: string | undefined;
    authenticationMethods?: ("biometric_face" | "biometric_hand" | "pin" | "password")[] | undefined;
    enrollmentTokenHash?: string | undefined;
    enrollmentTokenExpiresAt?: number | undefined;
    enrolledAt?: number | undefined;
    enrolledBy?: import("convex/values").GenericId<"admins"> | undefined;
    biometricTemplateHash?: string | undefined;
    biometricDataEncrypted?: string | undefined;
    biometricCaptureMetadata?: {
        deviceInfo?: string | undefined;
        captureType: "face" | "hand";
        anglesCaptured: string[];
        captureQuality: number;
        livenessPassed: boolean;
        captureTimestamp: number;
    } | undefined;
    lastVerificationAt?: number | undefined;
    lastVerificationSuccess?: boolean | undefined;
    verificationTimeoutAt?: number | undefined;
    phoneNumber: string;
    email: string;
    name: string;
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    isActive: boolean;
    enrollmentStatus: "active" | "suspended" | "invited" | "enrolling" | "biometric_complete" | "locked";
    consecutiveFailures: number;
    createdBy: import("convex/values").GenericId<"admins">;
}[]>>;
/**
 * Get current attendant profile (from authenticated Clerk session)
 */
export declare const getCurrentUser: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    branch: {
        _id: import("convex/values").GenericId<"branches">;
        name: string;
        address: string;
    } | null;
    _id: import("convex/values").GenericId<"attendants">;
    _creationTime: number;
    clerkUserId?: string | undefined;
    lastLoginAt?: number | undefined;
    passcodeHash?: string | undefined;
    passcodeSalt?: string | undefined;
    authenticationMethods?: ("biometric_face" | "biometric_hand" | "pin" | "password")[] | undefined;
    enrollmentTokenHash?: string | undefined;
    enrollmentTokenExpiresAt?: number | undefined;
    enrolledAt?: number | undefined;
    enrolledBy?: import("convex/values").GenericId<"admins"> | undefined;
    biometricTemplateHash?: string | undefined;
    biometricDataEncrypted?: string | undefined;
    biometricCaptureMetadata?: {
        deviceInfo?: string | undefined;
        captureType: "face" | "hand";
        anglesCaptured: string[];
        captureQuality: number;
        livenessPassed: boolean;
        captureTimestamp: number;
    } | undefined;
    lastVerificationAt?: number | undefined;
    lastVerificationSuccess?: boolean | undefined;
    verificationTimeoutAt?: number | undefined;
    phoneNumber: string;
    email: string;
    name: string;
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    isActive: boolean;
    enrollmentStatus: "active" | "suspended" | "invited" | "enrolling" | "biometric_complete" | "locked";
    consecutiveFailures: number;
    createdBy: import("convex/values").GenericId<"admins">;
}>>;
/**
 * Get current active attendance session for authenticated attendant
 * Returns attendance details with branch and attendant info
 */
export declare const getActiveAttendanceSession: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    attendance: {
        _id: import("convex/values").GenericId<"attendanceLogs">;
        attendantId: import("convex/values").GenericId<"attendants">;
        branchId: import("convex/values").GenericId<"branches">;
        clockInAt: number;
        deviceId: string | undefined;
        deviceInfo: string | undefined;
    };
    branch: {
        _id: import("convex/values").GenericId<"branches">;
        name: string;
        address: string;
    } | null;
    attendant: {
        _id: import("convex/values").GenericId<"attendants">;
        name: string;
        email: string;
    };
} | null>>;
/**
 * Get all active attendances for a branch
 * Useful for station dashboard to show who's currently clocked in
 */
export declare const getActiveAttendancesByBranch: import("convex/server").RegisteredQuery<"public", {
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<({
    _id: import("convex/values").GenericId<"attendanceLogs">;
    clockInAt: number;
    deviceId: string | undefined;
    deviceInfo: string | undefined;
    attendant: null;
} | {
    _id: import("convex/values").GenericId<"attendanceLogs">;
    clockInAt: number;
    deviceId: string | undefined;
    deviceInfo: string | undefined;
    attendant: {
        _id: import("convex/values").GenericId<"attendants">;
        name: string;
        email: string;
    };
})[]>>;
/**
 * Get attendance history - Paginated
 * Supports usePaginatedQuery for infinite scroll
 */
export declare const getAttendanceHistory: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    numItems?: number | undefined;
    cursor?: string | undefined;
}, Promise<{
    page: {
        _id: import("convex/values").GenericId<"attendanceLogs">;
        _creationTime: number;
        deviceInfo?: string | undefined;
        clockOutAt?: number | undefined;
        deviceId?: string | undefined;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        isActive: boolean;
        attendantId: import("convex/values").GenericId<"attendants">;
        clockInAt: number;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Clock in attendant (start attendance session)
 */
export declare const clockIn: import("convex/server").RegisteredMutation<"public", {
    deviceInfo?: string | undefined;
    verificationId?: import("convex/values").GenericId<"biometricVerifications"> | undefined;
    deviceId?: string | undefined;
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<import("convex/values").GenericId<"attendanceLogs">>>;
/**
 * Clock out attendant (end attendance session)
 */
export declare const clockOut: import("convex/server").RegisteredMutation<"public", {
    verificationId?: import("convex/values").GenericId<"biometricVerifications"> | undefined;
    attendanceLogId?: import("convex/values").GenericId<"attendanceLogs"> | undefined;
}, Promise<{
    attendanceLogId: import("convex/values").GenericId<"attendanceLogs">;
    sessionsRevoked: number;
    durationMinutes: number;
}>>;
/**
 * Get attendance details by ID
 */
export declare const getAttendanceById: import("convex/server").RegisteredQuery<"public", {
    attendanceId: import("convex/values").GenericId<"attendanceLogs">;
}, Promise<{
    _id: import("convex/values").GenericId<"attendanceLogs">;
    attendantId: import("convex/values").GenericId<"attendants">;
    branchId: import("convex/values").GenericId<"branches">;
    clockInAt: number;
    clockOutAt: number | undefined;
    deviceId: string | undefined;
    deviceInfo: string | undefined;
    isActive: boolean;
    durationMinutes: number;
    attendant: {
        _id: import("convex/values").GenericId<"attendants">;
        name: string;
        email: string;
    } | null;
    branch: {
        _id: import("convex/values").GenericId<"branches">;
        name: string;
        address: string;
    } | null;
}>>;
/**
 * Get attendance statistics for a branch
 */
export declare const getBranchAttendanceStats: import("convex/server").RegisteredQuery<"public", {
    date?: string | undefined;
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<{
    date: string;
    branchId: import("convex/values").GenericId<"branches">;
    clockIns: number;
    clockOuts: number;
    activeSessions: number;
    uniqueAttendants: number;
    totalHoursWorked: number;
    averageHoursPerAttendant: number;
}>>;
/**
 * Get attendance summary for date range
 */
export declare const getAttendanceSummary: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    startDate?: number | undefined;
    endDate?: number | undefined;
}, Promise<{
    totalSessions: number;
    completedSessions: number;
    activeSessions: number;
    uniqueAttendants: number;
    totalHoursWorked: number;
    averageHoursPerSession: number;
    attendanceByDay: Record<string, {
        clockIns: number;
        clockOuts: number;
        hours: number;
    }>;
    dateRange: {
        start: number;
        end: number;
    };
}>>;
/**
 * Verify enrollment token (public query - no auth required)
 */
export declare const verifyEnrollmentToken: import("convex/server").RegisteredQuery<"public", {
    token: string;
}, Promise<{
    valid: boolean;
    error: string;
    attendant?: undefined;
    expiresAt?: undefined;
} | {
    valid: boolean;
    attendant: {
        id: import("convex/values").GenericId<"attendants">;
        name: string;
        email: string;
        branchId: import("convex/values").GenericId<"branches">;
        branchName: string;
    };
    expiresAt: number;
    error?: undefined;
}>>;
/**
 * Start biometric enrollment
 */
export declare const startBiometricEnrollment: import("convex/server").RegisteredMutation<"public", {
    method: "face" | "hand";
    enrollmentToken: string;
}, Promise<{
    sessionId: import("convex/values").GenericId<"biometricVerificationSessions">;
    challenge: string;
    expiresAt: number;
}>>;
/**
 * Complete biometric enrollment
 */
export declare const completeBiometricEnrollment: import("convex/server").RegisteredMutation<"public", {
    challenge: string;
    enrollmentToken: string;
    biometricData: {
        deviceInfo?: string | undefined;
        captureType: "face" | "hand";
        captureQuality: number;
        angles: string[];
        features: string;
        measurements: string;
        livenessData: string;
    };
}, Promise<{
    success: boolean;
    attendantId: import("convex/values").GenericId<"attendants">;
    enrolledAt: number;
    requiresPIN: boolean;
}>>;
/**
 * Complete PIN setup after biometric enrollment
 * This is the second step of enrollment
 */
export declare const completePINSetup: import("convex/server").RegisteredMutation<"public", {
    pin: string;
    enrollmentToken: string;
}, Promise<{
    success: boolean;
    attendantId: import("convex/values").GenericId<"attendants">;
}>>;
/**
 * Verify PIN for attendant actions and create verification record
 */
export declare const verifyAttendantPIN: import("convex/server").RegisteredMutation<"public", {
    orderId?: import("convex/values").GenericId<"orders"> | undefined;
    actionType?: string | undefined;
    pin: string;
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<{
    success: boolean;
    attendantId: import("convex/values").GenericId<"attendants">;
    verificationId: import("convex/values").GenericId<"biometricVerifications">;
}>>;
/**
 * Find attendant by email (for login)
 */
export declare const findByEmail: import("convex/server").RegisteredQuery<"public", {
    email: string;
}, Promise<{
    id: import("convex/values").GenericId<"attendants">;
    email: string;
    name: string;
    branchId: import("convex/values").GenericId<"branches">;
    authenticationMethods: ("biometric_face" | "biometric_hand" | "pin" | "password")[];
    hasBiometric: boolean;
    hasPin: boolean;
    hasPassword: boolean;
} | null>>;
/**
 * Start verification (for login or action)
 * Changed to mutation to allow storing challenges
 */
export declare const startVerification: import("convex/server").RegisteredMutation<"public", {
    actionContext?: {
        orderId?: import("convex/values").GenericId<"orders"> | undefined;
        amount?: number | undefined;
        actionType?: string | undefined;
    } | undefined;
    attendantId: import("convex/values").GenericId<"attendants">;
    verificationType: "action" | "login" | "session_renewal";
}, Promise<{
    challenge: string;
    attendantId: import("convex/values").GenericId<"attendants">;
    verificationType: "action" | "login" | "session_renewal";
    requiresLiveness: boolean;
}>>;
/**
 * Verify biometric (complete verification)
 */
export declare const verifyBiometric: import("convex/server").RegisteredMutation<"public", {
    actionContext?: {
        orderId?: import("convex/values").GenericId<"orders"> | undefined;
        amount?: number | undefined;
        actionType?: string | undefined;
    } | undefined;
    useFallback?: boolean | undefined;
    fallbackType?: "otp" | "admin_verification" | undefined;
    fallbackCode?: string | undefined;
    attendantId: import("convex/values").GenericId<"attendants">;
    challenge: string;
    verificationType: "action" | "login" | "session_renewal";
    biometricData: {
        deviceInfo?: string | undefined;
        captureType: "face" | "hand";
        captureQuality: number;
        angles: string[];
        features: string;
        measurements: string;
        livenessData: string;
    };
}, Promise<{
    success: boolean;
    verificationId: import("convex/values").GenericId<"biometricVerifications">;
    expiresAt: number;
    fallbackUsed: "otp" | "admin_verification";
    confidence?: undefined;
} | {
    success: boolean;
    verificationId: import("convex/values").GenericId<"biometricVerifications">;
    confidence: number;
    expiresAt: number;
    fallbackUsed?: undefined;
}>>;
/**
 * Check verification status
 */
export declare const checkVerificationStatus: import("convex/server").RegisteredQuery<"public", {
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<{
    isVerified: boolean;
    expiresAt: number | undefined;
    lastVerificationAt: number | undefined;
    consecutiveFailures: number;
    enrollmentStatus: "active" | "suspended" | "invited" | "enrolling" | "biometric_complete" | "locked";
}>>;
/**
 * Create session after successful biometric verification
 */
export declare const createSession: import("convex/server").RegisteredMutation<"public", {
    deviceInfo?: string | undefined;
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<{
    success: boolean;
    sessionToken: string;
    refreshToken: string;
    expiresAt: number;
    refreshExpiresAt: number;
    sessionId: import("convex/values").GenericId<"attendantSessions">;
}>>;
/**
 * Refresh session access token
 */
export declare const refreshSession: import("convex/server").RegisteredMutation<"public", {
    refreshToken: string;
}, Promise<{
    success: boolean;
    sessionToken: string;
    expiresAt: number;
}>>;
/**
 * Logout - invalidate session
 */
export declare const logout: import("convex/server").RegisteredMutation<"public", {
    sessionToken?: string | undefined;
}, Promise<{
    success: boolean;
    sessionsRevoked?: undefined;
} | {
    success: boolean;
    sessionsRevoked: number;
}>>;
/**
 * Authenticate attendant with PIN or Password
 */
export declare const authenticateWithPinOrPassword: import("convex/server").RegisteredMutation<"public", {
    deviceInfo?: string | undefined;
    branchId: import("convex/values").GenericId<"branches">;
    attendantId: import("convex/values").GenericId<"attendants">;
    pinOrPassword: string;
    isPin: boolean;
}, Promise<{
    success: boolean;
    attendantId: import("convex/values").GenericId<"attendants">;
    name: string;
    email: string;
    branchId: import("convex/values").GenericId<"branches">;
}>>;
/**
 * Get current session (validate and return session info)
 */
export declare const getCurrentSession: import("convex/server").RegisteredQuery<"public", {
    sessionToken: string;
}, Promise<{
    success: boolean;
    attendant: {
        _id: import("convex/values").GenericId<"attendants">;
        name: string;
        email: string;
        branchId: import("convex/values").GenericId<"branches">;
    };
    branch: {
        _id: import("convex/values").GenericId<"branches">;
        name: string;
        address: string;
    } | null;
    session: {
        expiresAt: number;
        lastActivityAt: number;
        createdAt: number;
    };
}>>;
//# sourceMappingURL=attendants.d.ts.map