/**
 * WashLab Database Schema
 *
 * This schema defines all database tables for the WashLab laundry management system.
 * All authentication is handled by Clerk - clerkUserId fields link Clerk users to our data.
 */
declare const _default: import("convex/server").SchemaDefinition<{
    users: import("convex/server").TableDefinition<import("convex/values").VObject<{
        email?: string | undefined;
        clerkUserId?: string | undefined;
        status?: "active" | "blocked" | "suspended" | "restricted" | undefined;
        statusNote?: string | undefined;
        statusChangedBy?: import("convex/values").GenericId<"admins"> | undefined;
        statusChangedAt?: number | undefined;
        lastLoginAt?: number | undefined;
        preferredBranchId?: import("convex/values").GenericId<"branches"> | undefined;
        phoneNumber: string;
        name: string;
        isRegistered: boolean;
        isVerified: boolean;
        createdAt: number;
        isDeleted: boolean;
    }, {
        phoneNumber: import("convex/values").VString<string, "required">;
        email: import("convex/values").VString<string | undefined, "optional">;
        name: import("convex/values").VString<string, "required">;
        clerkUserId: import("convex/values").VString<string | undefined, "optional">;
        isRegistered: import("convex/values").VBoolean<boolean, "required">;
        isVerified: import("convex/values").VBoolean<boolean, "required">;
        status: import("convex/values").VUnion<"active" | "blocked" | "suspended" | "restricted" | undefined, [import("convex/values").VLiteral<"active", "required">, import("convex/values").VLiteral<"blocked", "required">, import("convex/values").VLiteral<"suspended", "required">, import("convex/values").VLiteral<"restricted", "required">], "optional", never>;
        statusNote: import("convex/values").VString<string | undefined, "optional">;
        statusChangedBy: import("convex/values").VId<import("convex/values").GenericId<"admins"> | undefined, "optional">;
        statusChangedAt: import("convex/values").VFloat64<number | undefined, "optional">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        lastLoginAt: import("convex/values").VFloat64<number | undefined, "optional">;
        preferredBranchId: import("convex/values").VId<import("convex/values").GenericId<"branches"> | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "phoneNumber" | "email" | "name" | "clerkUserId" | "isRegistered" | "isVerified" | "status" | "statusNote" | "statusChangedBy" | "statusChangedAt" | "createdAt" | "lastLoginAt" | "preferredBranchId" | "isDeleted">, {
        by_phone: ["phoneNumber", "_creationTime"];
        by_email: ["email", "_creationTime"];
        by_clerk_user: ["clerkUserId", "_creationTime"];
        by_status: ["status", "_creationTime"];
    }, {}, {}>;
    attendants: import("convex/server").TableDefinition<import("convex/values").VObject<{
        clerkUserId?: string | undefined;
        lastLoginAt?: number | undefined;
        passcodeHash?: string | undefined;
        passcodeSalt?: string | undefined;
        authenticationMethods?: ("biometric_face" | "biometric_hand" | "pin" | "password")[] | undefined;
        enrollmentTokenHash?: string | undefined;
        enrollmentTokenExpiresAt?: number | undefined;
        enrolledAt?: number | undefined;
        enrolledBy?: import("convex/values").GenericId<"admins"> | undefined;
        biometricTemplateHash?: string | undefined;
        biometricDataEncrypted?: string | undefined;
        biometricCaptureMetadata?: {
            deviceInfo?: string | undefined;
            captureType: "face" | "hand";
            anglesCaptured: string[];
            captureQuality: number;
            livenessPassed: boolean;
            captureTimestamp: number;
        } | undefined;
        lastVerificationAt?: number | undefined;
        lastVerificationSuccess?: boolean | undefined;
        verificationTimeoutAt?: number | undefined;
        phoneNumber: string;
        email: string;
        name: string;
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        isActive: boolean;
        enrollmentStatus: "active" | "suspended" | "invited" | "enrolling" | "biometric_complete" | "locked";
        consecutiveFailures: number;
        createdBy: import("convex/values").GenericId<"admins">;
    }, {
        name: import("convex/values").VString<string, "required">;
        email: import("convex/values").VString<string, "required">;
        phoneNumber: import("convex/values").VString<string, "required">;
        clerkUserId: import("convex/values").VString<string | undefined, "optional">;
        passcodeHash: import("convex/values").VString<string | undefined, "optional">;
        passcodeSalt: import("convex/values").VString<string | undefined, "optional">;
        authenticationMethods: import("convex/values").VArray<("biometric_face" | "biometric_hand" | "pin" | "password")[] | undefined, import("convex/values").VUnion<"biometric_face" | "biometric_hand" | "pin" | "password", [import("convex/values").VLiteral<"biometric_face", "required">, import("convex/values").VLiteral<"biometric_hand", "required">, import("convex/values").VLiteral<"pin", "required">, import("convex/values").VLiteral<"password", "required">], "required", never>, "optional">;
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        isActive: import("convex/values").VBoolean<boolean, "required">;
        enrollmentStatus: import("convex/values").VUnion<"active" | "suspended" | "invited" | "enrolling" | "biometric_complete" | "locked", [import("convex/values").VLiteral<"invited", "required">, import("convex/values").VLiteral<"enrolling", "required">, import("convex/values").VLiteral<"biometric_complete", "required">, import("convex/values").VLiteral<"active", "required">, import("convex/values").VLiteral<"suspended", "required">, import("convex/values").VLiteral<"locked", "required">], "required", never>;
        enrollmentTokenHash: import("convex/values").VString<string | undefined, "optional">;
        enrollmentTokenExpiresAt: import("convex/values").VFloat64<number | undefined, "optional">;
        enrolledAt: import("convex/values").VFloat64<number | undefined, "optional">;
        enrolledBy: import("convex/values").VId<import("convex/values").GenericId<"admins"> | undefined, "optional">;
        biometricTemplateHash: import("convex/values").VString<string | undefined, "optional">;
        biometricDataEncrypted: import("convex/values").VString<string | undefined, "optional">;
        biometricCaptureMetadata: import("convex/values").VObject<{
            deviceInfo?: string | undefined;
            captureType: "face" | "hand";
            anglesCaptured: string[];
            captureQuality: number;
            livenessPassed: boolean;
            captureTimestamp: number;
        } | undefined, {
            captureType: import("convex/values").VUnion<"face" | "hand", [import("convex/values").VLiteral<"face", "required">, import("convex/values").VLiteral<"hand", "required">], "required", never>;
            anglesCaptured: import("convex/values").VArray<string[], import("convex/values").VString<string, "required">, "required">;
            captureQuality: import("convex/values").VFloat64<number, "required">;
            livenessPassed: import("convex/values").VBoolean<boolean, "required">;
            deviceInfo: import("convex/values").VString<string | undefined, "optional">;
            captureTimestamp: import("convex/values").VFloat64<number, "required">;
        }, "optional", "captureType" | "anglesCaptured" | "captureQuality" | "livenessPassed" | "deviceInfo" | "captureTimestamp">;
        lastVerificationAt: import("convex/values").VFloat64<number | undefined, "optional">;
        lastVerificationSuccess: import("convex/values").VBoolean<boolean | undefined, "optional">;
        consecutiveFailures: import("convex/values").VFloat64<number, "required">;
        verificationTimeoutAt: import("convex/values").VFloat64<number | undefined, "optional">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        createdBy: import("convex/values").VId<import("convex/values").GenericId<"admins">, "required">;
        lastLoginAt: import("convex/values").VFloat64<number | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "phoneNumber" | "email" | "name" | "clerkUserId" | "createdAt" | "lastLoginAt" | "isDeleted" | "passcodeHash" | "passcodeSalt" | "authenticationMethods" | "branchId" | "isActive" | "enrollmentStatus" | "enrollmentTokenHash" | "enrollmentTokenExpiresAt" | "enrolledAt" | "enrolledBy" | "biometricTemplateHash" | "biometricDataEncrypted" | "biometricCaptureMetadata" | "lastVerificationAt" | "lastVerificationSuccess" | "consecutiveFailures" | "verificationTimeoutAt" | "createdBy" | "biometricCaptureMetadata.captureType" | "biometricCaptureMetadata.anglesCaptured" | "biometricCaptureMetadata.captureQuality" | "biometricCaptureMetadata.livenessPassed" | "biometricCaptureMetadata.deviceInfo" | "biometricCaptureMetadata.captureTimestamp">, {
        by_branch: ["branchId", "_creationTime"];
        by_email: ["email", "_creationTime"];
        by_phone: ["phoneNumber", "_creationTime"];
        by_clerk_user: ["clerkUserId", "_creationTime"];
        by_enrollment_status: ["enrollmentStatus", "_creationTime"];
        by_enrollment_token: ["enrollmentTokenHash", "_creationTime"];
    }, {}, {}>;
    admins: import("convex/server").TableDefinition<import("convex/values").VObject<{
        lastLoginAt?: number | undefined;
        email: string;
        name: string;
        clerkUserId: string;
        createdAt: number;
        isDeleted: boolean;
        role: "super_admin" | "admin";
    }, {
        name: import("convex/values").VString<string, "required">;
        email: import("convex/values").VString<string, "required">;
        clerkUserId: import("convex/values").VString<string, "required">;
        role: import("convex/values").VUnion<"super_admin" | "admin", [import("convex/values").VLiteral<"super_admin", "required">, import("convex/values").VLiteral<"admin", "required">], "required", never>;
        createdAt: import("convex/values").VFloat64<number, "required">;
        lastLoginAt: import("convex/values").VFloat64<number | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "email" | "name" | "clerkUserId" | "createdAt" | "lastLoginAt" | "isDeleted" | "role">, {
        by_email: ["email", "_creationTime"];
        by_clerk_user: ["clerkUserId", "_creationTime"];
    }, {}, {}>;
    branches: import("convex/server").TableDefinition<import("convex/values").VObject<{
        email?: string | undefined;
        terminalId?: string | undefined;
        stationPinHash?: string | undefined;
        requireStationLogin?: boolean | undefined;
        phoneNumber: string;
        name: string;
        createdAt: number;
        isDeleted: boolean;
        isActive: boolean;
        createdBy: import("convex/values").GenericId<"admins">;
        code: string;
        address: string;
        city: string;
        country: string;
        pricingPerKg: number;
        deliveryFee: number;
    }, {
        name: import("convex/values").VString<string, "required">;
        code: import("convex/values").VString<string, "required">;
        terminalId: import("convex/values").VString<string | undefined, "optional">;
        address: import("convex/values").VString<string, "required">;
        city: import("convex/values").VString<string, "required">;
        country: import("convex/values").VString<string, "required">;
        phoneNumber: import("convex/values").VString<string, "required">;
        email: import("convex/values").VString<string | undefined, "optional">;
        pricingPerKg: import("convex/values").VFloat64<number, "required">;
        deliveryFee: import("convex/values").VFloat64<number, "required">;
        stationPinHash: import("convex/values").VString<string | undefined, "optional">;
        requireStationLogin: import("convex/values").VBoolean<boolean | undefined, "optional">;
        isActive: import("convex/values").VBoolean<boolean, "required">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        createdBy: import("convex/values").VId<import("convex/values").GenericId<"admins">, "required">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "phoneNumber" | "email" | "name" | "createdAt" | "isDeleted" | "isActive" | "createdBy" | "code" | "terminalId" | "address" | "city" | "country" | "pricingPerKg" | "deliveryFee" | "stationPinHash" | "requireStationLogin">, {
        by_city: ["city", "_creationTime"];
        by_active: ["isActive", "_creationTime"];
        by_code: ["code", "_creationTime"];
        by_terminal_id: ["terminalId", "_creationTime"];
    }, {}, {}>;
    orders: import("convex/server").TableDefinition<import("convex/values").VObject<{
        createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
        customerEmail?: string | undefined;
        estimatedWeight?: number | undefined;
        actualWeight?: number | undefined;
        itemCount?: number | undefined;
        estimatedLoads?: number | undefined;
        whitesSeparate?: boolean | undefined;
        bagCardNumber?: string | undefined;
        notes?: string | undefined;
        deliveryAddress?: string | undefined;
        deliveryPhoneNumber?: string | undefined;
        deliveryHall?: string | undefined;
        deliveryRoom?: string | undefined;
        paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
        paymentId?: import("convex/values").GenericId<"payments"> | undefined;
        assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
        fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
        status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        deliveryFee: number;
        customerId: import("convex/values").GenericId<"users">;
        customerPhoneNumber: string;
        orderNumber: string;
        orderType: "walk_in" | "online";
        serviceType: "wash_only" | "wash_and_dry" | "dry_only";
        isDelivery: boolean;
        basePrice: number;
        totalPrice: number;
        finalPrice: number;
        paymentStatus: "pending" | "paid" | "failed" | "refunded";
        updatedAt: number;
        statusHistory: {
            notes?: string | undefined;
            changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
            changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
            status: string;
            changedAt: number;
        }[];
    }, {
        customerId: import("convex/values").VId<import("convex/values").GenericId<"users">, "required">;
        customerPhoneNumber: import("convex/values").VString<string, "required">;
        customerEmail: import("convex/values").VString<string | undefined, "optional">;
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        orderNumber: import("convex/values").VString<string, "required">;
        orderType: import("convex/values").VUnion<"walk_in" | "online", [import("convex/values").VLiteral<"walk_in", "required">, import("convex/values").VLiteral<"online", "required">], "required", never>;
        serviceType: import("convex/values").VUnion<"wash_only" | "wash_and_dry" | "dry_only", [import("convex/values").VLiteral<"wash_only", "required">, import("convex/values").VLiteral<"wash_and_dry", "required">, import("convex/values").VLiteral<"dry_only", "required">], "required", never>;
        estimatedWeight: import("convex/values").VFloat64<number | undefined, "optional">;
        actualWeight: import("convex/values").VFloat64<number | undefined, "optional">;
        itemCount: import("convex/values").VFloat64<number | undefined, "optional">;
        estimatedLoads: import("convex/values").VFloat64<number | undefined, "optional">;
        whitesSeparate: import("convex/values").VBoolean<boolean | undefined, "optional">;
        bagCardNumber: import("convex/values").VString<string | undefined, "optional">;
        notes: import("convex/values").VString<string | undefined, "optional">;
        isDelivery: import("convex/values").VBoolean<boolean, "required">;
        deliveryAddress: import("convex/values").VString<string | undefined, "optional">;
        deliveryPhoneNumber: import("convex/values").VString<string | undefined, "optional">;
        deliveryHall: import("convex/values").VString<string | undefined, "optional">;
        deliveryRoom: import("convex/values").VString<string | undefined, "optional">;
        basePrice: import("convex/values").VFloat64<number, "required">;
        deliveryFee: import("convex/values").VFloat64<number, "required">;
        totalPrice: import("convex/values").VFloat64<number, "required">;
        finalPrice: import("convex/values").VFloat64<number, "required">;
        status: import("convex/values").VUnion<"pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered", [import("convex/values").VLiteral<"pending_dropoff", "required">, import("convex/values").VLiteral<"checked_in", "required">, import("convex/values").VLiteral<"sorting", "required">, import("convex/values").VLiteral<"washing", "required">, import("convex/values").VLiteral<"drying", "required">, import("convex/values").VLiteral<"folding", "required">, import("convex/values").VLiteral<"ready", "required">, import("convex/values").VLiteral<"completed", "required">, import("convex/values").VLiteral<"cancelled", "required">, import("convex/values").VLiteral<"pending", "required">, import("convex/values").VLiteral<"in_progress", "required">, import("convex/values").VLiteral<"ready_for_pickup", "required">, import("convex/values").VLiteral<"delivered", "required">], "required", never>;
        paymentStatus: import("convex/values").VUnion<"pending" | "paid" | "failed" | "refunded", [import("convex/values").VLiteral<"pending", "required">, import("convex/values").VLiteral<"paid", "required">, import("convex/values").VLiteral<"failed", "required">, import("convex/values").VLiteral<"refunded", "required">], "required", never>;
        paymentMethod: import("convex/values").VUnion<"mobile_money" | "card" | "cash" | undefined, [import("convex/values").VLiteral<"mobile_money", "required">, import("convex/values").VLiteral<"card", "required">, import("convex/values").VLiteral<"cash", "required">], "optional", never>;
        paymentId: import("convex/values").VId<import("convex/values").GenericId<"payments"> | undefined, "optional">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        updatedAt: import("convex/values").VFloat64<number, "required">;
        createdBy: import("convex/values").VId<import("convex/values").GenericId<"attendants"> | undefined, "optional">;
        assignedTo: import("convex/values").VId<import("convex/values").GenericId<"attendants"> | undefined, "optional">;
        fulfilledBy: import("convex/values").VId<import("convex/values").GenericId<"attendants"> | undefined, "optional">;
        statusHistory: import("convex/values").VArray<{
            notes?: string | undefined;
            changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
            changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
            status: string;
            changedAt: number;
        }[], import("convex/values").VObject<{
            notes?: string | undefined;
            changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
            changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
            status: string;
            changedAt: number;
        }, {
            status: import("convex/values").VString<string, "required">;
            changedAt: import("convex/values").VFloat64<number, "required">;
            changedBy: import("convex/values").VId<import("convex/values").GenericId<"attendants"> | undefined, "optional">;
            changedByAdmin: import("convex/values").VId<import("convex/values").GenericId<"admins"> | undefined, "optional">;
            notes: import("convex/values").VString<string | undefined, "optional">;
        }, "required", "status" | "notes" | "changedAt" | "changedBy" | "changedByAdmin">, "required">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "status" | "createdAt" | "isDeleted" | "branchId" | "createdBy" | "deliveryFee" | "customerId" | "customerPhoneNumber" | "customerEmail" | "orderNumber" | "orderType" | "serviceType" | "estimatedWeight" | "actualWeight" | "itemCount" | "estimatedLoads" | "whitesSeparate" | "bagCardNumber" | "notes" | "isDelivery" | "deliveryAddress" | "deliveryPhoneNumber" | "deliveryHall" | "deliveryRoom" | "basePrice" | "totalPrice" | "finalPrice" | "paymentStatus" | "paymentMethod" | "paymentId" | "updatedAt" | "assignedTo" | "fulfilledBy" | "statusHistory">, {
        by_customer: ["customerId", "_creationTime"];
        by_branch: ["branchId", "_creationTime"];
        by_status: ["status", "_creationTime"];
        by_phone: ["customerPhoneNumber", "_creationTime"];
        by_email: ["customerEmail", "_creationTime"];
        by_order_number: ["orderNumber", "_creationTime"];
        by_created: ["createdAt", "_creationTime"];
        by_fulfilled_by: ["fulfilledBy", "_creationTime"];
    }, {}, {}>;
    payments: import("convex/server").TableDefinition<import("convex/values").VObject<{
        gatewayTransactionId?: string | undefined;
        gatewayResponse?: string | undefined;
        completedAt?: number | undefined;
        processedBy?: import("convex/values").GenericId<"attendants"> | undefined;
        verificationId?: import("convex/values").GenericId<"biometricVerifications"> | undefined;
        status: "completed" | "pending" | "failed" | "refunded" | "processing";
        createdAt: number;
        isDeleted: boolean;
        customerId: import("convex/values").GenericId<"users">;
        paymentMethod: "mobile_money" | "card" | "cash";
        orderId: import("convex/values").GenericId<"orders">;
        amount: number;
        currency: string;
    }, {
        orderId: import("convex/values").VId<import("convex/values").GenericId<"orders">, "required">;
        customerId: import("convex/values").VId<import("convex/values").GenericId<"users">, "required">;
        amount: import("convex/values").VFloat64<number, "required">;
        currency: import("convex/values").VString<string, "required">;
        paymentMethod: import("convex/values").VUnion<"mobile_money" | "card" | "cash", [import("convex/values").VLiteral<"mobile_money", "required">, import("convex/values").VLiteral<"card", "required">, import("convex/values").VLiteral<"cash", "required">], "required", never>;
        status: import("convex/values").VUnion<"completed" | "pending" | "failed" | "refunded" | "processing", [import("convex/values").VLiteral<"pending", "required">, import("convex/values").VLiteral<"processing", "required">, import("convex/values").VLiteral<"completed", "required">, import("convex/values").VLiteral<"failed", "required">, import("convex/values").VLiteral<"refunded", "required">], "required", never>;
        gatewayTransactionId: import("convex/values").VString<string | undefined, "optional">;
        gatewayResponse: import("convex/values").VString<string | undefined, "optional">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        completedAt: import("convex/values").VFloat64<number | undefined, "optional">;
        processedBy: import("convex/values").VId<import("convex/values").GenericId<"attendants"> | undefined, "optional">;
        verificationId: import("convex/values").VId<import("convex/values").GenericId<"biometricVerifications"> | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "status" | "createdAt" | "isDeleted" | "customerId" | "paymentMethod" | "orderId" | "amount" | "currency" | "gatewayTransactionId" | "gatewayResponse" | "completedAt" | "processedBy" | "verificationId">, {
        by_order: ["orderId", "_creationTime"];
        by_customer: ["customerId", "_creationTime"];
        by_status: ["status", "_creationTime"];
        by_created: ["createdAt", "_creationTime"];
    }, {}, {}>;
    loyaltyPoints: import("convex/server").TableDefinition<import("convex/values").VObject<{
        lastEarnedAt?: number | undefined;
        lastRedeemedAt?: number | undefined;
        isDeleted: boolean;
        customerId: import("convex/values").GenericId<"users">;
        points: number;
        totalEarned: number;
        totalRedeemed: number;
    }, {
        customerId: import("convex/values").VId<import("convex/values").GenericId<"users">, "required">;
        points: import("convex/values").VFloat64<number, "required">;
        totalEarned: import("convex/values").VFloat64<number, "required">;
        totalRedeemed: import("convex/values").VFloat64<number, "required">;
        lastEarnedAt: import("convex/values").VFloat64<number | undefined, "optional">;
        lastRedeemedAt: import("convex/values").VFloat64<number | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "isDeleted" | "customerId" | "points" | "totalEarned" | "totalRedeemed" | "lastEarnedAt" | "lastRedeemedAt">, {
        by_customer: ["customerId", "_creationTime"];
    }, {}, {}>;
    loyaltyTransactions: import("convex/server").TableDefinition<import("convex/values").VObject<{
        createdBy?: import("convex/values").GenericId<"admins"> | undefined;
        orderId?: import("convex/values").GenericId<"orders"> | undefined;
        description?: string | undefined;
        type: "earned" | "redeemed" | "expired" | "adjusted";
        createdAt: number;
        isDeleted: boolean;
        customerId: import("convex/values").GenericId<"users">;
        points: number;
        balanceAfter: number;
    }, {
        customerId: import("convex/values").VId<import("convex/values").GenericId<"users">, "required">;
        orderId: import("convex/values").VId<import("convex/values").GenericId<"orders"> | undefined, "optional">;
        type: import("convex/values").VUnion<"earned" | "redeemed" | "expired" | "adjusted", [import("convex/values").VLiteral<"earned", "required">, import("convex/values").VLiteral<"redeemed", "required">, import("convex/values").VLiteral<"expired", "required">, import("convex/values").VLiteral<"adjusted", "required">], "required", never>;
        points: import("convex/values").VFloat64<number, "required">;
        balanceAfter: import("convex/values").VFloat64<number, "required">;
        description: import("convex/values").VString<string | undefined, "optional">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        createdBy: import("convex/values").VId<import("convex/values").GenericId<"admins"> | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "type" | "createdAt" | "isDeleted" | "createdBy" | "customerId" | "orderId" | "points" | "balanceAfter" | "description">, {
        by_customer: ["customerId", "_creationTime"];
        by_order: ["orderId", "_creationTime"];
        by_created: ["createdAt", "_creationTime"];
        by_type: ["type", "_creationTime"];
    }, {}, {}>;
    attendanceLogs: import("convex/server").TableDefinition<import("convex/values").VObject<{
        deviceInfo?: string | undefined;
        clockOutAt?: number | undefined;
        deviceId?: string | undefined;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        isActive: boolean;
        attendantId: import("convex/values").GenericId<"attendants">;
        clockInAt: number;
    }, {
        attendantId: import("convex/values").VId<import("convex/values").GenericId<"attendants">, "required">;
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        clockInAt: import("convex/values").VFloat64<number, "required">;
        clockOutAt: import("convex/values").VFloat64<number | undefined, "optional">;
        deviceId: import("convex/values").VString<string | undefined, "optional">;
        deviceInfo: import("convex/values").VString<string | undefined, "optional">;
        isActive: import("convex/values").VBoolean<boolean, "required">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "isDeleted" | "branchId" | "isActive" | "deviceInfo" | "attendantId" | "clockInAt" | "clockOutAt" | "deviceId">, {
        by_attendant: ["attendantId", "_creationTime"];
        by_branch: ["branchId", "_creationTime"];
        by_clock_in: ["clockInAt", "_creationTime"];
        by_active: ["isActive", "_creationTime"];
    }, {}, {}>;
    resourceUsageLogs: import("convex/server").TableDefinition<import("convex/values").VObject<{
        notes?: string | undefined;
        waterCycles?: number | undefined;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        attendantId: import("convex/values").GenericId<"attendants">;
        date: string;
        detergentUnits: number;
        tokensUsed: number;
        loggedAt: number;
    }, {
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        attendantId: import("convex/values").VId<import("convex/values").GenericId<"attendants">, "required">;
        date: import("convex/values").VString<string, "required">;
        detergentUnits: import("convex/values").VFloat64<number, "required">;
        tokensUsed: import("convex/values").VFloat64<number, "required">;
        waterCycles: import("convex/values").VFloat64<number | undefined, "optional">;
        loggedAt: import("convex/values").VFloat64<number, "required">;
        notes: import("convex/values").VString<string | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "isDeleted" | "branchId" | "notes" | "attendantId" | "date" | "detergentUnits" | "tokensUsed" | "waterCycles" | "loggedAt">, {
        by_branch: ["branchId", "_creationTime"];
        by_date: ["date", "_creationTime"];
        by_attendant: ["attendantId", "_creationTime"];
        by_branch_date: ["branchId", "date", "_creationTime"];
    }, {}, {}>;
    auditLogs: import("convex/server").TableDefinition<import("convex/values").VObject<{
        branchId?: import("convex/values").GenericId<"branches"> | undefined;
        deviceId?: string | undefined;
        entityId?: string | undefined;
        attendanceId?: import("convex/values").GenericId<"attendanceLogs"> | undefined;
        ipAddress?: string | undefined;
        details?: string | undefined;
        oldValue?: string | undefined;
        newValue?: string | undefined;
        actorId: string;
        actorType: "admin" | "customer" | "attendant";
        actorRole: string;
        action: string;
        entityType: string;
        timestamp: number;
    }, {
        actorId: import("convex/values").VString<string, "required">;
        actorType: import("convex/values").VUnion<"admin" | "customer" | "attendant", [import("convex/values").VLiteral<"customer", "required">, import("convex/values").VLiteral<"attendant", "required">, import("convex/values").VLiteral<"admin", "required">], "required", never>;
        actorRole: import("convex/values").VString<string, "required">;
        action: import("convex/values").VString<string, "required">;
        entityType: import("convex/values").VString<string, "required">;
        entityId: import("convex/values").VString<string | undefined, "optional">;
        attendanceId: import("convex/values").VId<import("convex/values").GenericId<"attendanceLogs"> | undefined, "optional">;
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches"> | undefined, "optional">;
        deviceId: import("convex/values").VString<string | undefined, "optional">;
        ipAddress: import("convex/values").VString<string | undefined, "optional">;
        details: import("convex/values").VString<string | undefined, "optional">;
        oldValue: import("convex/values").VString<string | undefined, "optional">;
        newValue: import("convex/values").VString<string | undefined, "optional">;
        timestamp: import("convex/values").VFloat64<number, "required">;
    }, "required", "branchId" | "deviceId" | "actorId" | "actorType" | "actorRole" | "action" | "entityType" | "entityId" | "attendanceId" | "ipAddress" | "details" | "oldValue" | "newValue" | "timestamp">, {
        by_actor: ["actorId", "actorType", "_creationTime"];
        by_action: ["action", "_creationTime"];
        by_entity: ["entityType", "entityId", "_creationTime"];
        by_timestamp: ["timestamp", "_creationTime"];
        by_branch: ["branchId", "_creationTime"];
        by_attendance: ["attendanceId", "_creationTime"];
    }, {}, {}>;
    vouchers: import("convex/server").TableDefinition<import("convex/values").VObject<{
        name?: string | undefined;
        description?: string | undefined;
        maxUsesPerCustomer?: number | undefined;
        validFrom?: number | undefined;
        validUntil?: number | undefined;
        minOrderValue?: number | undefined;
        applicableBranches?: import("convex/values").GenericId<"branches">[] | undefined;
        applicableServiceTypes?: ("wash_only" | "wash_and_dry" | "dry_only")[] | undefined;
        createdAt: number;
        isDeleted: boolean;
        isActive: boolean;
        createdBy: import("convex/values").GenericId<"admins">;
        code: string;
        discountType: "percentage" | "fixed" | "free_wash";
        discountValue: number;
        usageLimit: number;
        usedCount: number;
    }, {
        code: import("convex/values").VString<string, "required">;
        name: import("convex/values").VString<string | undefined, "optional">;
        discountType: import("convex/values").VUnion<"percentage" | "fixed" | "free_wash", [import("convex/values").VLiteral<"percentage", "required">, import("convex/values").VLiteral<"fixed", "required">, import("convex/values").VLiteral<"free_wash", "required">], "required", never>;
        discountValue: import("convex/values").VFloat64<number, "required">;
        usageLimit: import("convex/values").VFloat64<number, "required">;
        usedCount: import("convex/values").VFloat64<number, "required">;
        maxUsesPerCustomer: import("convex/values").VFloat64<number | undefined, "optional">;
        isActive: import("convex/values").VBoolean<boolean, "required">;
        validFrom: import("convex/values").VFloat64<number | undefined, "optional">;
        validUntil: import("convex/values").VFloat64<number | undefined, "optional">;
        minOrderValue: import("convex/values").VFloat64<number | undefined, "optional">;
        applicableBranches: import("convex/values").VArray<import("convex/values").GenericId<"branches">[] | undefined, import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">, "optional">;
        applicableServiceTypes: import("convex/values").VArray<("wash_only" | "wash_and_dry" | "dry_only")[] | undefined, import("convex/values").VUnion<"wash_only" | "wash_and_dry" | "dry_only", [import("convex/values").VLiteral<"wash_only", "required">, import("convex/values").VLiteral<"wash_and_dry", "required">, import("convex/values").VLiteral<"dry_only", "required">], "required", never>, "optional">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        createdBy: import("convex/values").VId<import("convex/values").GenericId<"admins">, "required">;
        description: import("convex/values").VString<string | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "name" | "createdAt" | "isDeleted" | "isActive" | "createdBy" | "code" | "description" | "discountType" | "discountValue" | "usageLimit" | "usedCount" | "maxUsesPerCustomer" | "validFrom" | "validUntil" | "minOrderValue" | "applicableBranches" | "applicableServiceTypes">, {
        by_code: ["code", "_creationTime"];
        by_active: ["isActive", "_creationTime"];
        by_created: ["createdAt", "_creationTime"];
    }, {}, {}>;
    voucherUsages: import("convex/server").TableDefinition<import("convex/values").VObject<{
        usedBy?: import("convex/values").GenericId<"attendants"> | undefined;
        isDeleted: boolean;
        customerId: import("convex/values").GenericId<"users">;
        orderId: import("convex/values").GenericId<"orders">;
        voucherId: import("convex/values").GenericId<"vouchers">;
        discountAmount: number;
        orderTotalBefore: number;
        orderTotalAfter: number;
        usedAt: number;
    }, {
        voucherId: import("convex/values").VId<import("convex/values").GenericId<"vouchers">, "required">;
        orderId: import("convex/values").VId<import("convex/values").GenericId<"orders">, "required">;
        customerId: import("convex/values").VId<import("convex/values").GenericId<"users">, "required">;
        discountAmount: import("convex/values").VFloat64<number, "required">;
        orderTotalBefore: import("convex/values").VFloat64<number, "required">;
        orderTotalAfter: import("convex/values").VFloat64<number, "required">;
        usedAt: import("convex/values").VFloat64<number, "required">;
        usedBy: import("convex/values").VId<import("convex/values").GenericId<"attendants"> | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "isDeleted" | "customerId" | "orderId" | "voucherId" | "discountAmount" | "orderTotalBefore" | "orderTotalAfter" | "usedAt" | "usedBy">, {
        by_voucher: ["voucherId", "_creationTime"];
        by_order: ["orderId", "_creationTime"];
        by_customer: ["customerId", "_creationTime"];
        by_used_at: ["usedAt", "_creationTime"];
    }, {}, {}>;
    notifications: import("convex/server").TableDefinition<import("convex/values").VObject<{
        branchId?: import("convex/values").GenericId<"branches"> | undefined;
        entityType?: string | undefined;
        entityId?: string | undefined;
        actionUrl?: string | undefined;
        actionLabel?: string | undefined;
        readAt?: number | undefined;
        senderId?: string | undefined;
        senderType?: "admin" | "attendant" | "system" | undefined;
        expiresAt?: number | undefined;
        scheduledFor?: number | undefined;
        sentAt?: number | undefined;
        type: "info" | "success" | "warning" | "error" | "order" | "payment" | "system";
        createdAt: number;
        isDeleted: boolean;
        recipientId: string;
        recipientType: "admin" | "customer" | "attendant" | "station" | "all";
        title: string;
        message: string;
        priority: "low" | "normal" | "high" | "urgent";
        isRead: boolean;
    }, {
        recipientId: import("convex/values").VString<string, "required">;
        recipientType: import("convex/values").VUnion<"admin" | "customer" | "attendant" | "station" | "all", [import("convex/values").VLiteral<"customer", "required">, import("convex/values").VLiteral<"attendant", "required">, import("convex/values").VLiteral<"admin", "required">, import("convex/values").VLiteral<"station", "required">, import("convex/values").VLiteral<"all", "required">], "required", never>;
        title: import("convex/values").VString<string, "required">;
        message: import("convex/values").VString<string, "required">;
        type: import("convex/values").VUnion<"info" | "success" | "warning" | "error" | "order" | "payment" | "system", [import("convex/values").VLiteral<"info", "required">, import("convex/values").VLiteral<"success", "required">, import("convex/values").VLiteral<"warning", "required">, import("convex/values").VLiteral<"error", "required">, import("convex/values").VLiteral<"order", "required">, import("convex/values").VLiteral<"payment", "required">, import("convex/values").VLiteral<"system", "required">], "required", never>;
        actionUrl: import("convex/values").VString<string | undefined, "optional">;
        actionLabel: import("convex/values").VString<string | undefined, "optional">;
        entityType: import("convex/values").VString<string | undefined, "optional">;
        entityId: import("convex/values").VString<string | undefined, "optional">;
        priority: import("convex/values").VUnion<"low" | "normal" | "high" | "urgent", [import("convex/values").VLiteral<"low", "required">, import("convex/values").VLiteral<"normal", "required">, import("convex/values").VLiteral<"high", "required">, import("convex/values").VLiteral<"urgent", "required">], "required", never>;
        isRead: import("convex/values").VBoolean<boolean, "required">;
        readAt: import("convex/values").VFloat64<number | undefined, "optional">;
        senderId: import("convex/values").VString<string | undefined, "optional">;
        senderType: import("convex/values").VUnion<"admin" | "attendant" | "system" | undefined, [import("convex/values").VLiteral<"admin", "required">, import("convex/values").VLiteral<"attendant", "required">, import("convex/values").VLiteral<"system", "required">], "optional", never>;
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches"> | undefined, "optional">;
        expiresAt: import("convex/values").VFloat64<number | undefined, "optional">;
        scheduledFor: import("convex/values").VFloat64<number | undefined, "optional">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        sentAt: import("convex/values").VFloat64<number | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "type" | "createdAt" | "isDeleted" | "branchId" | "entityType" | "entityId" | "recipientId" | "recipientType" | "title" | "message" | "actionUrl" | "actionLabel" | "priority" | "isRead" | "readAt" | "senderId" | "senderType" | "expiresAt" | "scheduledFor" | "sentAt">, {
        by_recipient: ["recipientId", "recipientType", "_creationTime"];
        by_recipient_read: ["recipientId", "recipientType", "isRead", "_creationTime"];
        by_type: ["type", "_creationTime"];
        by_priority: ["priority", "_creationTime"];
        by_created: ["createdAt", "_creationTime"];
        by_branch: ["branchId", "_creationTime"];
        by_entity: ["entityType", "entityId", "_creationTime"];
    }, {}, {}>;
    notificationReadStatus: import("convex/server").TableDefinition<import("convex/values").VObject<{
        readAt: number;
        notificationId: import("convex/values").GenericId<"notifications">;
        userId: string;
        userType: "admin" | "customer" | "attendant" | "station";
    }, {
        notificationId: import("convex/values").VId<import("convex/values").GenericId<"notifications">, "required">;
        userId: import("convex/values").VString<string, "required">;
        userType: import("convex/values").VUnion<"admin" | "customer" | "attendant" | "station", [import("convex/values").VLiteral<"customer", "required">, import("convex/values").VLiteral<"attendant", "required">, import("convex/values").VLiteral<"admin", "required">, import("convex/values").VLiteral<"station", "required">], "required", never>;
        readAt: import("convex/values").VFloat64<number, "required">;
    }, "required", "readAt" | "notificationId" | "userId" | "userType">, {
        by_notification: ["notificationId", "_creationTime"];
        by_user: ["userId", "userType", "_creationTime"];
        by_notification_user: ["notificationId", "userId", "userType", "_creationTime"];
    }, {}, {}>;
    biometricProfiles: import("convex/server").TableDefinition<import("convex/values").VObject<{
        lastVerifiedAt?: number | undefined;
        isDeleted: boolean;
        enrolledAt: number;
        attendantId: import("convex/values").GenericId<"attendants">;
        method: "face" | "hand";
        encryptedData: string;
        iv: string;
        authTag: string;
        encryptionKeyId: string;
        algorithm: string;
        confidenceThreshold: number;
        verificationCount: number;
        version: number;
    }, {
        attendantId: import("convex/values").VId<import("convex/values").GenericId<"attendants">, "required">;
        method: import("convex/values").VUnion<"face" | "hand", [import("convex/values").VLiteral<"face", "required">, import("convex/values").VLiteral<"hand", "required">], "required", never>;
        encryptedData: import("convex/values").VString<string, "required">;
        iv: import("convex/values").VString<string, "required">;
        authTag: import("convex/values").VString<string, "required">;
        encryptionKeyId: import("convex/values").VString<string, "required">;
        algorithm: import("convex/values").VString<string, "required">;
        confidenceThreshold: import("convex/values").VFloat64<number, "required">;
        enrolledAt: import("convex/values").VFloat64<number, "required">;
        lastVerifiedAt: import("convex/values").VFloat64<number | undefined, "optional">;
        verificationCount: import("convex/values").VFloat64<number, "required">;
        version: import("convex/values").VFloat64<number, "required">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "isDeleted" | "enrolledAt" | "attendantId" | "method" | "encryptedData" | "iv" | "authTag" | "encryptionKeyId" | "algorithm" | "confidenceThreshold" | "lastVerifiedAt" | "verificationCount" | "version">, {
        by_attendant: ["attendantId", "_creationTime"];
        by_method: ["method", "_creationTime"];
    }, {}, {}>;
    biometricVerificationSessions: import("convex/server").TableDefinition<import("convex/values").VObject<{
        deviceInfo?: string | undefined;
        confidenceScore?: number | undefined;
        fallbackUsed?: "otp" | "admin_verification" | undefined;
        otpHash?: string | undefined;
        otpExpiresAt?: number | undefined;
        adminVerifiedBy?: import("convex/values").GenericId<"admins"> | undefined;
        verifiedAt?: number | undefined;
        status: "pending" | "failed" | "expired" | "verified";
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        attendantId: import("convex/values").GenericId<"attendants">;
        expiresAt: number;
        sessionType: "enrollment" | "login" | "re_verification";
        challenge: string;
        challengeHash: string;
    }, {
        attendantId: import("convex/values").VId<import("convex/values").GenericId<"attendants">, "required">;
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        sessionType: import("convex/values").VUnion<"enrollment" | "login" | "re_verification", [import("convex/values").VLiteral<"enrollment", "required">, import("convex/values").VLiteral<"login", "required">, import("convex/values").VLiteral<"re_verification", "required">], "required", never>;
        challenge: import("convex/values").VString<string, "required">;
        challengeHash: import("convex/values").VString<string, "required">;
        status: import("convex/values").VUnion<"pending" | "failed" | "expired" | "verified", [import("convex/values").VLiteral<"pending", "required">, import("convex/values").VLiteral<"verified", "required">, import("convex/values").VLiteral<"failed", "required">, import("convex/values").VLiteral<"expired", "required">], "required", never>;
        confidenceScore: import("convex/values").VFloat64<number | undefined, "optional">;
        fallbackUsed: import("convex/values").VUnion<"otp" | "admin_verification" | undefined, [import("convex/values").VLiteral<"otp", "required">, import("convex/values").VLiteral<"admin_verification", "required">], "optional", never>;
        otpHash: import("convex/values").VString<string | undefined, "optional">;
        otpExpiresAt: import("convex/values").VFloat64<number | undefined, "optional">;
        adminVerifiedBy: import("convex/values").VId<import("convex/values").GenericId<"admins"> | undefined, "optional">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        expiresAt: import("convex/values").VFloat64<number, "required">;
        verifiedAt: import("convex/values").VFloat64<number | undefined, "optional">;
        deviceInfo: import("convex/values").VString<string | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "status" | "createdAt" | "isDeleted" | "branchId" | "deviceInfo" | "attendantId" | "expiresAt" | "sessionType" | "challenge" | "challengeHash" | "confidenceScore" | "fallbackUsed" | "otpHash" | "otpExpiresAt" | "adminVerifiedBy" | "verifiedAt">, {
        by_attendant: ["attendantId", "_creationTime"];
        by_branch: ["branchId", "_creationTime"];
        by_status: ["status", "_creationTime"];
        by_challenge_hash: ["challengeHash", "_creationTime"];
    }, {}, {}>;
    stationSessions: import("convex/server").TableDefinition<import("convex/values").VObject<{
        deviceInfo?: string | undefined;
        ipAddress?: string | undefined;
        loggedInBy?: import("convex/values").GenericId<"attendants"> | undefined;
        stationPinUsed?: boolean | undefined;
        loggedOutAt?: number | undefined;
        loggedOutBy?: import("convex/values").GenericId<"attendants"> | undefined;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        isActive: boolean;
        deviceId: string;
        expiresAt: number;
        sessionTokenHash: string;
        loggedInAt: number;
    }, {
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        deviceId: import("convex/values").VString<string, "required">;
        sessionTokenHash: import("convex/values").VString<string, "required">;
        deviceInfo: import("convex/values").VString<string | undefined, "optional">;
        ipAddress: import("convex/values").VString<string | undefined, "optional">;
        loggedInBy: import("convex/values").VId<import("convex/values").GenericId<"attendants"> | undefined, "optional">;
        loggedInAt: import("convex/values").VFloat64<number, "required">;
        stationPinUsed: import("convex/values").VBoolean<boolean | undefined, "optional">;
        expiresAt: import("convex/values").VFloat64<number, "required">;
        isActive: import("convex/values").VBoolean<boolean, "required">;
        loggedOutAt: import("convex/values").VFloat64<number | undefined, "optional">;
        loggedOutBy: import("convex/values").VId<import("convex/values").GenericId<"attendants"> | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "isDeleted" | "branchId" | "isActive" | "deviceInfo" | "deviceId" | "ipAddress" | "expiresAt" | "sessionTokenHash" | "loggedInBy" | "loggedInAt" | "stationPinUsed" | "loggedOutAt" | "loggedOutBy">, {
        by_branch: ["branchId", "_creationTime"];
        by_device: ["deviceId", "_creationTime"];
        by_session_token: ["sessionTokenHash", "_creationTime"];
        by_active: ["isActive", "_creationTime"];
        by_branch_device: ["branchId", "deviceId", "_creationTime"];
    }, {}, {}>;
    attendantSessions: import("convex/server").TableDefinition<import("convex/values").VObject<{
        deviceInfo?: string | undefined;
        ipAddress?: string | undefined;
        userAgent?: string | undefined;
        revokedAt?: number | undefined;
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        isActive: boolean;
        attendantId: import("convex/values").GenericId<"attendants">;
        expiresAt: number;
        sessionTokenHash: string;
        refreshTokenHash: string;
        refreshExpiresAt: number;
        lastActivityAt: number;
    }, {
        attendantId: import("convex/values").VId<import("convex/values").GenericId<"attendants">, "required">;
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        sessionTokenHash: import("convex/values").VString<string, "required">;
        refreshTokenHash: import("convex/values").VString<string, "required">;
        deviceInfo: import("convex/values").VString<string | undefined, "optional">;
        ipAddress: import("convex/values").VString<string | undefined, "optional">;
        userAgent: import("convex/values").VString<string | undefined, "optional">;
        expiresAt: import("convex/values").VFloat64<number, "required">;
        refreshExpiresAt: import("convex/values").VFloat64<number, "required">;
        isActive: import("convex/values").VBoolean<boolean, "required">;
        lastActivityAt: import("convex/values").VFloat64<number, "required">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        revokedAt: import("convex/values").VFloat64<number | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "createdAt" | "isDeleted" | "branchId" | "isActive" | "deviceInfo" | "attendantId" | "ipAddress" | "expiresAt" | "sessionTokenHash" | "refreshTokenHash" | "userAgent" | "refreshExpiresAt" | "lastActivityAt" | "revokedAt">, {
        by_attendant: ["attendantId", "_creationTime"];
        by_branch: ["branchId", "_creationTime"];
        by_session_token: ["sessionTokenHash", "_creationTime"];
        by_active: ["isActive", "_creationTime"];
    }, {}, {}>;
    enrollmentTokens: import("convex/server").TableDefinition<import("convex/values").VObject<{
        usedAt?: number | undefined;
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        createdBy: import("convex/values").GenericId<"admins">;
        attendantId: import("convex/values").GenericId<"attendants">;
        expiresAt: number;
        tokenHash: string;
        plainToken: string;
        isUsed: boolean;
    }, {
        tokenHash: import("convex/values").VString<string, "required">;
        plainToken: import("convex/values").VString<string, "required">;
        attendantId: import("convex/values").VId<import("convex/values").GenericId<"attendants">, "required">;
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        createdBy: import("convex/values").VId<import("convex/values").GenericId<"admins">, "required">;
        expiresAt: import("convex/values").VFloat64<number, "required">;
        usedAt: import("convex/values").VFloat64<number | undefined, "optional">;
        isUsed: import("convex/values").VBoolean<boolean, "required">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "createdAt" | "isDeleted" | "branchId" | "createdBy" | "attendantId" | "usedAt" | "expiresAt" | "tokenHash" | "plainToken" | "isUsed">, {
        by_token_hash: ["tokenHash", "_creationTime"];
        by_attendant: ["attendantId", "_creationTime"];
        by_expires_at: ["expiresAt", "_creationTime"];
    }, {}, {}>;
    biometricChallenges: import("convex/server").TableDefinition<import("convex/values").VObject<{
        createdAt: number;
        isDeleted: boolean;
        attendantId: import("convex/values").GenericId<"attendants">;
        expiresAt: number;
        challenge: string;
        challengeHash: string;
        isUsed: boolean;
    }, {
        challengeHash: import("convex/values").VString<string, "required">;
        challenge: import("convex/values").VString<string, "required">;
        attendantId: import("convex/values").VId<import("convex/values").GenericId<"attendants">, "required">;
        expiresAt: import("convex/values").VFloat64<number, "required">;
        isUsed: import("convex/values").VBoolean<boolean, "required">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "createdAt" | "isDeleted" | "attendantId" | "expiresAt" | "challenge" | "challengeHash" | "isUsed">, {
        by_challenge_hash: ["challengeHash", "_creationTime"];
        by_attendant: ["attendantId", "_creationTime"];
        by_expires_at: ["expiresAt", "_creationTime"];
    }, {}, {}>;
    biometricEnrollments: import("convex/server").TableDefinition<import("convex/values").VObject<{
        enrolledAt?: number | undefined;
        deviceInfo?: string | undefined;
        status: "completed" | "pending" | "in_progress" | "failed" | "expired";
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        enrollmentTokenHash: string;
        createdBy: import("convex/values").GenericId<"admins">;
        attendantId: import("convex/values").GenericId<"attendants">;
        tokenCreatedAt: number;
        tokenExpiresAt: number;
        captureAttempts: {
            captureQuality?: number | undefined;
            errorMessage?: string | undefined;
            timestamp: number;
            success: boolean;
            attemptNumber: number;
        }[];
    }, {
        attendantId: import("convex/values").VId<import("convex/values").GenericId<"attendants">, "required">;
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        enrollmentTokenHash: import("convex/values").VString<string, "required">;
        status: import("convex/values").VUnion<"completed" | "pending" | "in_progress" | "failed" | "expired", [import("convex/values").VLiteral<"pending", "required">, import("convex/values").VLiteral<"in_progress", "required">, import("convex/values").VLiteral<"completed", "required">, import("convex/values").VLiteral<"expired", "required">, import("convex/values").VLiteral<"failed", "required">], "required", never>;
        tokenCreatedAt: import("convex/values").VFloat64<number, "required">;
        tokenExpiresAt: import("convex/values").VFloat64<number, "required">;
        enrolledAt: import("convex/values").VFloat64<number | undefined, "optional">;
        captureAttempts: import("convex/values").VArray<{
            captureQuality?: number | undefined;
            errorMessage?: string | undefined;
            timestamp: number;
            success: boolean;
            attemptNumber: number;
        }[], import("convex/values").VObject<{
            captureQuality?: number | undefined;
            errorMessage?: string | undefined;
            timestamp: number;
            success: boolean;
            attemptNumber: number;
        }, {
            attemptNumber: import("convex/values").VFloat64<number, "required">;
            timestamp: import("convex/values").VFloat64<number, "required">;
            success: import("convex/values").VBoolean<boolean, "required">;
            errorMessage: import("convex/values").VString<string | undefined, "optional">;
            captureQuality: import("convex/values").VFloat64<number | undefined, "optional">;
        }, "required", "captureQuality" | "timestamp" | "success" | "attemptNumber" | "errorMessage">, "required">;
        createdBy: import("convex/values").VId<import("convex/values").GenericId<"admins">, "required">;
        deviceInfo: import("convex/values").VString<string | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "status" | "isDeleted" | "branchId" | "enrollmentTokenHash" | "enrolledAt" | "deviceInfo" | "createdBy" | "attendantId" | "tokenCreatedAt" | "tokenExpiresAt" | "captureAttempts">, {
        by_attendant: ["attendantId", "_creationTime"];
        by_token_hash: ["enrollmentTokenHash", "_creationTime"];
        by_status: ["status", "_creationTime"];
        by_branch: ["branchId", "_creationTime"];
    }, {}, {}>;
    biometricVerifications: import("convex/server").TableDefinition<import("convex/values").VObject<{
        deviceInfo?: string | undefined;
        ipAddress?: string | undefined;
        confidenceScore?: number | undefined;
        fallbackUsed?: "pin" | "otp" | "admin_verification" | "device_pin" | undefined;
        actionContext?: {
            orderId?: import("convex/values").GenericId<"orders"> | undefined;
            amount?: number | undefined;
            actionType?: string | undefined;
        } | undefined;
        matchThreshold?: number | undefined;
        captureMetadata?: {
            deviceInfo?: string | undefined;
            captureType: "face" | "hand";
            livenessPassed: boolean;
            anglesVerified: string[];
        } | undefined;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        attendantId: import("convex/values").GenericId<"attendants">;
        success: boolean;
        expiresAt: number;
        verifiedAt: number;
        verificationType: "action" | "login" | "session_renewal";
    }, {
        attendantId: import("convex/values").VId<import("convex/values").GenericId<"attendants">, "required">;
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        verificationType: import("convex/values").VUnion<"action" | "login" | "session_renewal", [import("convex/values").VLiteral<"login", "required">, import("convex/values").VLiteral<"action", "required">, import("convex/values").VLiteral<"session_renewal", "required">], "required", never>;
        actionContext: import("convex/values").VObject<{
            orderId?: import("convex/values").GenericId<"orders"> | undefined;
            amount?: number | undefined;
            actionType?: string | undefined;
        } | undefined, {
            actionType: import("convex/values").VString<string | undefined, "optional">;
            orderId: import("convex/values").VId<import("convex/values").GenericId<"orders"> | undefined, "optional">;
            amount: import("convex/values").VFloat64<number | undefined, "optional">;
        }, "optional", "orderId" | "amount" | "actionType">;
        success: import("convex/values").VBoolean<boolean, "required">;
        confidenceScore: import("convex/values").VFloat64<number | undefined, "optional">;
        matchThreshold: import("convex/values").VFloat64<number | undefined, "optional">;
        fallbackUsed: import("convex/values").VUnion<"pin" | "otp" | "admin_verification" | "device_pin" | undefined, [import("convex/values").VLiteral<"otp", "required">, import("convex/values").VLiteral<"admin_verification", "required">, import("convex/values").VLiteral<"device_pin", "required">, import("convex/values").VLiteral<"pin", "required">], "optional", never>;
        captureMetadata: import("convex/values").VObject<{
            deviceInfo?: string | undefined;
            captureType: "face" | "hand";
            livenessPassed: boolean;
            anglesVerified: string[];
        } | undefined, {
            captureType: import("convex/values").VUnion<"face" | "hand", [import("convex/values").VLiteral<"face", "required">, import("convex/values").VLiteral<"hand", "required">], "required", never>;
            anglesVerified: import("convex/values").VArray<string[], import("convex/values").VString<string, "required">, "required">;
            livenessPassed: import("convex/values").VBoolean<boolean, "required">;
            deviceInfo: import("convex/values").VString<string | undefined, "optional">;
        }, "optional", "captureType" | "livenessPassed" | "deviceInfo" | "anglesVerified">;
        verifiedAt: import("convex/values").VFloat64<number, "required">;
        expiresAt: import("convex/values").VFloat64<number, "required">;
        deviceInfo: import("convex/values").VString<string | undefined, "optional">;
        ipAddress: import("convex/values").VString<string | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "isDeleted" | "branchId" | "deviceInfo" | "attendantId" | "ipAddress" | "success" | "expiresAt" | "confidenceScore" | "fallbackUsed" | "verifiedAt" | "verificationType" | "actionContext" | "matchThreshold" | "captureMetadata" | "actionContext.orderId" | "actionContext.amount" | "actionContext.actionType" | "captureMetadata.captureType" | "captureMetadata.livenessPassed" | "captureMetadata.deviceInfo" | "captureMetadata.anglesVerified">, {
        by_attendant: ["attendantId", "_creationTime"];
        by_branch: ["branchId", "_creationTime"];
        by_verification_type: ["verificationType", "_creationTime"];
        by_verified_at: ["verifiedAt", "_creationTime"];
        by_success: ["success", "_creationTime"];
    }, {}, {}>;
    actionLogs: import("convex/server").TableDefinition<import("convex/values").VObject<{
        amount?: number | undefined;
        completedAt?: number | undefined;
        verificationId?: import("convex/values").GenericId<"biometricVerifications"> | undefined;
        entityType?: string | undefined;
        entityId?: import("convex/values").GenericId<"orders"> | undefined;
        errorMessage?: string | undefined;
        actionData?: string | undefined;
        verificationMethod?: "biometric_face" | "biometric_hand" | "pin" | "password" | undefined;
        createdAt: number;
        branchId: import("convex/values").GenericId<"branches">;
        attendantId: import("convex/values").GenericId<"attendants">;
        attendanceId: import("convex/values").GenericId<"attendanceLogs">;
        actionType: string;
        actionStatus: "completed" | "cancelled" | "pending" | "failed";
    }, {
        attendanceId: import("convex/values").VId<import("convex/values").GenericId<"attendanceLogs">, "required">;
        attendantId: import("convex/values").VId<import("convex/values").GenericId<"attendants">, "required">;
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        actionType: import("convex/values").VString<string, "required">;
        actionStatus: import("convex/values").VUnion<"completed" | "cancelled" | "pending" | "failed", [import("convex/values").VLiteral<"pending", "required">, import("convex/values").VLiteral<"completed", "required">, import("convex/values").VLiteral<"failed", "required">, import("convex/values").VLiteral<"cancelled", "required">], "required", never>;
        entityType: import("convex/values").VString<string | undefined, "optional">;
        entityId: import("convex/values").VId<import("convex/values").GenericId<"orders"> | undefined, "optional">;
        actionData: import("convex/values").VString<string | undefined, "optional">;
        errorMessage: import("convex/values").VString<string | undefined, "optional">;
        amount: import("convex/values").VFloat64<number | undefined, "optional">;
        verificationMethod: import("convex/values").VUnion<"biometric_face" | "biometric_hand" | "pin" | "password" | undefined, [import("convex/values").VLiteral<"biometric_face", "required">, import("convex/values").VLiteral<"biometric_hand", "required">, import("convex/values").VLiteral<"pin", "required">, import("convex/values").VLiteral<"password", "required">], "optional", never>;
        verificationId: import("convex/values").VId<import("convex/values").GenericId<"biometricVerifications"> | undefined, "optional">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        completedAt: import("convex/values").VFloat64<number | undefined, "optional">;
    }, "required", "createdAt" | "branchId" | "amount" | "completedAt" | "verificationId" | "attendantId" | "entityType" | "entityId" | "attendanceId" | "errorMessage" | "actionType" | "actionStatus" | "actionData" | "verificationMethod">, {
        by_attendance: ["attendanceId", "_creationTime"];
        by_attendant: ["attendantId", "_creationTime"];
        by_branch: ["branchId", "_creationTime"];
        by_action_type: ["actionType", "_creationTime"];
        by_status: ["actionStatus", "_creationTime"];
        by_created_at: ["createdAt", "_creationTime"];
        by_attendance_created: ["attendanceId", "createdAt", "_creationTime"];
    }, {}, {}>;
    systemSettings: import("convex/server").TableDefinition<import("convex/values").VObject<{
        isDeleted: boolean;
        updatedAt: number;
        businessName: string;
        contactPhone: string;
        contactEmail: string;
        notifyNewOrders: boolean;
        notifyCompletedOrders: boolean;
        requireBiometricPayment: boolean;
        autoLogoutMinutes: number;
        updatedBy: import("convex/values").GenericId<"admins">;
    }, {
        businessName: import("convex/values").VString<string, "required">;
        contactPhone: import("convex/values").VString<string, "required">;
        contactEmail: import("convex/values").VString<string, "required">;
        notifyNewOrders: import("convex/values").VBoolean<boolean, "required">;
        notifyCompletedOrders: import("convex/values").VBoolean<boolean, "required">;
        requireBiometricPayment: import("convex/values").VBoolean<boolean, "required">;
        autoLogoutMinutes: import("convex/values").VFloat64<number, "required">;
        updatedAt: import("convex/values").VFloat64<number, "required">;
        updatedBy: import("convex/values").VId<import("convex/values").GenericId<"admins">, "required">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "isDeleted" | "updatedAt" | "businessName" | "contactPhone" | "contactEmail" | "notifyNewOrders" | "notifyCompletedOrders" | "requireBiometricPayment" | "autoLogoutMinutes" | "updatedBy">, {}, {}, {}>;
    services: import("convex/server").TableDefinition<import("convex/values").VObject<{
        description?: string | undefined;
        updatedBy?: import("convex/values").GenericId<"admins"> | undefined;
        imageStorageId?: import("convex/values").GenericId<"_storage"> | undefined;
        imageUrl?: string | undefined;
        name: string;
        createdAt: number;
        isDeleted: boolean;
        isActive: boolean;
        createdBy: import("convex/values").GenericId<"admins">;
        code: string;
        basePrice: number;
        updatedAt: number;
        pricingType: "per_kg" | "per_load";
    }, {
        name: import("convex/values").VString<string, "required">;
        code: import("convex/values").VString<string, "required">;
        description: import("convex/values").VString<string | undefined, "optional">;
        imageStorageId: import("convex/values").VId<import("convex/values").GenericId<"_storage"> | undefined, "optional">;
        imageUrl: import("convex/values").VString<string | undefined, "optional">;
        basePrice: import("convex/values").VFloat64<number, "required">;
        pricingType: import("convex/values").VUnion<"per_kg" | "per_load", [import("convex/values").VLiteral<"per_kg", "required">, import("convex/values").VLiteral<"per_load", "required">], "required", never>;
        isActive: import("convex/values").VBoolean<boolean, "required">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        createdBy: import("convex/values").VId<import("convex/values").GenericId<"admins">, "required">;
        updatedAt: import("convex/values").VFloat64<number, "required">;
        updatedBy: import("convex/values").VId<import("convex/values").GenericId<"admins"> | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "name" | "createdAt" | "isDeleted" | "isActive" | "createdBy" | "code" | "basePrice" | "updatedAt" | "description" | "updatedBy" | "imageStorageId" | "imageUrl" | "pricingType">, {
        by_code: ["code", "_creationTime"];
        by_active: ["isActive", "_creationTime"];
    }, {}, {}>;
    inventoryItems: import("convex/server").TableDefinition<import("convex/values").VObject<{
        createdBy?: import("convex/values").GenericId<"admins"> | undefined;
        description?: string | undefined;
        updatedBy?: import("convex/values").GenericId<"admins"> | undefined;
        orderedAt?: number | undefined;
        expectedArrivalDate?: number | undefined;
        arrivalDate?: number | undefined;
        orderQuantity?: number | undefined;
        lastRestockedAt?: number | undefined;
        name: string;
        status: "low" | "critical" | "ok" | "ordered";
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        updatedAt: number;
        category: "cleaning_supplies" | "add_ons" | "facility" | "retail" | "operational";
        unit: string;
        currentStock: number;
        maxStock: number;
        minStock: number;
        reorderPoint: number;
    }, {
        name: import("convex/values").VString<string, "required">;
        category: import("convex/values").VUnion<"cleaning_supplies" | "add_ons" | "facility" | "retail" | "operational", [import("convex/values").VLiteral<"cleaning_supplies", "required">, import("convex/values").VLiteral<"add_ons", "required">, import("convex/values").VLiteral<"facility", "required">, import("convex/values").VLiteral<"retail", "required">, import("convex/values").VLiteral<"operational", "required">], "required", never>;
        unit: import("convex/values").VString<string, "required">;
        description: import("convex/values").VString<string | undefined, "optional">;
        currentStock: import("convex/values").VFloat64<number, "required">;
        maxStock: import("convex/values").VFloat64<number, "required">;
        minStock: import("convex/values").VFloat64<number, "required">;
        reorderPoint: import("convex/values").VFloat64<number, "required">;
        status: import("convex/values").VUnion<"low" | "critical" | "ok" | "ordered", [import("convex/values").VLiteral<"critical", "required">, import("convex/values").VLiteral<"low", "required">, import("convex/values").VLiteral<"ok", "required">, import("convex/values").VLiteral<"ordered", "required">], "required", never>;
        orderedAt: import("convex/values").VFloat64<number | undefined, "optional">;
        expectedArrivalDate: import("convex/values").VFloat64<number | undefined, "optional">;
        arrivalDate: import("convex/values").VFloat64<number | undefined, "optional">;
        orderQuantity: import("convex/values").VFloat64<number | undefined, "optional">;
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        createdBy: import("convex/values").VId<import("convex/values").GenericId<"admins"> | undefined, "optional">;
        updatedAt: import("convex/values").VFloat64<number, "required">;
        updatedBy: import("convex/values").VId<import("convex/values").GenericId<"admins"> | undefined, "optional">;
        lastRestockedAt: import("convex/values").VFloat64<number | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "name" | "status" | "createdAt" | "isDeleted" | "branchId" | "createdBy" | "updatedAt" | "description" | "updatedBy" | "category" | "unit" | "currentStock" | "maxStock" | "minStock" | "reorderPoint" | "orderedAt" | "expectedArrivalDate" | "arrivalDate" | "orderQuantity" | "lastRestockedAt">, {
        by_branch: ["branchId", "_creationTime"];
        by_branch_status: ["branchId", "status", "_creationTime"];
        by_branch_category: ["branchId", "category", "_creationTime"];
    }, {}, {}>;
    branchServices: import("convex/server").TableDefinition<import("convex/values").VObject<{
        description?: string | undefined;
        updatedBy?: import("convex/values").GenericId<"admins"> | undefined;
        imageUrl?: string | undefined;
        name: string;
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        isActive: boolean;
        createdBy: import("convex/values").GenericId<"admins">;
        code: string;
        updatedAt: number;
        price: number;
    }, {
        branchId: import("convex/values").VId<import("convex/values").GenericId<"branches">, "required">;
        name: import("convex/values").VString<string, "required">;
        code: import("convex/values").VString<string, "required">;
        description: import("convex/values").VString<string | undefined, "optional">;
        imageUrl: import("convex/values").VString<string | undefined, "optional">;
        price: import("convex/values").VFloat64<number, "required">;
        isActive: import("convex/values").VBoolean<boolean, "required">;
        createdAt: import("convex/values").VFloat64<number, "required">;
        createdBy: import("convex/values").VId<import("convex/values").GenericId<"admins">, "required">;
        updatedAt: import("convex/values").VFloat64<number, "required">;
        updatedBy: import("convex/values").VId<import("convex/values").GenericId<"admins"> | undefined, "optional">;
        isDeleted: import("convex/values").VBoolean<boolean, "required">;
    }, "required", "name" | "createdAt" | "isDeleted" | "branchId" | "isActive" | "createdBy" | "code" | "updatedAt" | "description" | "updatedBy" | "imageUrl" | "price">, {
        by_branch: ["branchId", "_creationTime"];
        by_branch_code: ["branchId", "code", "_creationTime"];
        by_active: ["isActive", "_creationTime"];
    }, {}, {}>;
}, true>;
export default _default;
//# sourceMappingURL=schema.d.ts.map