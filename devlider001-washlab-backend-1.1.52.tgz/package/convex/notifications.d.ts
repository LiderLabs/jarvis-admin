import { Id } from "./_generated/dataModel";
/**
 * Get notifications for current user
 * Returns empty array if user not found
 */
export declare const getMyNotifications: import("convex/server").RegisteredQuery<"public", {
    type?: "info" | "success" | "warning" | "error" | "order" | "payment" | "system" | undefined;
    isRead?: boolean | undefined;
    limit?: number | undefined;
}, Promise<{
    _id: Id<"notifications">;
    _creationTime: number;
    recipientId: string;
    recipientType: string;
    title: string;
    message: string;
    type: string;
    priority: string;
    isRead: boolean;
    createdAt: number;
    isDeleted: boolean;
    readAt?: number;
    actionUrl?: string;
    actionLabel?: string;
    entityType?: string;
    entityId?: string;
    senderId?: string;
    senderType?: string;
    branchId?: Id<"branches">;
    expiresAt?: number;
    scheduledFor?: number;
    sentAt?: number;
}[]>>;
/**
 * Get unread notification count for current user
 * Returns 0 if user not found
 */
export declare const getUnreadCount: import("convex/server").RegisteredQuery<"public", {}, Promise<number>>;
/**
 * Mark notification as read
 */
export declare const markAsRead: import("convex/server").RegisteredMutation<"public", {
    notificationId: import("convex/values").GenericId<"notifications">;
}, Promise<{
    success: boolean;
}>>;
/**
 * Mark all notifications as read for current user
 */
export declare const markAllAsRead: import("convex/server").RegisteredMutation<"public", {}, Promise<{
    success: boolean;
    count: number;
}>>;
/**
 * Delete notification (soft delete)
 */
export declare const deleteNotification: import("convex/server").RegisteredMutation<"public", {
    notificationId: import("convex/values").GenericId<"notifications">;
}, Promise<{
    success: boolean;
}>>;
/**
 * Get all notifications (admin only) - Paginated
 */
export declare const getAllNotifications: import("convex/server").RegisteredQuery<"public", {
    type?: "info" | "success" | "warning" | "error" | "order" | "payment" | "system" | undefined;
    recipientType?: "admin" | "customer" | "attendant" | "station" | "all" | undefined;
    isRead?: boolean | undefined;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        isRead: boolean;
        readAt: number | undefined;
        _id: import("convex/values").GenericId<"notifications">;
        _creationTime: number;
        branchId?: import("convex/values").GenericId<"branches"> | undefined;
        entityType?: string | undefined;
        entityId?: string | undefined;
        actionUrl?: string | undefined;
        actionLabel?: string | undefined;
        senderId?: string | undefined;
        senderType?: "admin" | "attendant" | "system" | undefined;
        expiresAt?: number | undefined;
        scheduledFor?: number | undefined;
        sentAt?: number | undefined;
        type: "info" | "success" | "warning" | "error" | "order" | "payment" | "system";
        createdAt: number;
        isDeleted: boolean;
        recipientId: string;
        recipientType: "admin" | "customer" | "attendant" | "station" | "all";
        title: string;
        message: string;
        priority: "low" | "normal" | "high" | "urgent";
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Create notification (admin only)
 */
export declare const createNotification: import("convex/server").RegisteredMutation<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    entityType?: string | undefined;
    entityId?: string | undefined;
    recipientId?: string | undefined;
    actionUrl?: string | undefined;
    actionLabel?: string | undefined;
    priority?: "low" | "normal" | "high" | "urgent" | undefined;
    expiresAt?: number | undefined;
    scheduledFor?: number | undefined;
    type: "info" | "success" | "warning" | "error" | "order" | "payment" | "system";
    recipientType: "admin" | "customer" | "attendant" | "station" | "all";
    title: string;
    message: string;
}, Promise<{
    notificationId: import("convex/values").GenericId<"notifications">;
    success: boolean;
}>>;
/**
 * Internal mutation to create notification (can be called from other mutations)
 */
export declare const internalCreateNotification: import("convex/server").RegisteredMutation<"internal", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    entityType?: string | undefined;
    entityId?: string | undefined;
    recipientId?: string | undefined;
    actionUrl?: string | undefined;
    actionLabel?: string | undefined;
    priority?: "low" | "normal" | "high" | "urgent" | undefined;
    senderId?: string | undefined;
    senderType?: "admin" | "attendant" | "system" | undefined;
    expiresAt?: number | undefined;
    scheduledFor?: number | undefined;
    type: "info" | "success" | "warning" | "error" | "order" | "payment" | "system";
    recipientType: "admin" | "customer" | "attendant" | "station" | "all";
    title: string;
    message: string;
}, Promise<{
    notificationId: import("convex/values").GenericId<"notifications">;
    success: boolean;
}>>;
/**
 * Delete notification (admin only - hard delete)
 */
export declare const adminDeleteNotification: import("convex/server").RegisteredMutation<"public", {
    notificationId: import("convex/values").GenericId<"notifications">;
}, Promise<{
    success: boolean;
}>>;
/**
 * Create notification (internal - for system use)
 */
export declare const createSystemNotification: import("convex/server").RegisteredMutation<"internal", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    entityType?: string | undefined;
    entityId?: string | undefined;
    actionUrl?: string | undefined;
    actionLabel?: string | undefined;
    priority?: "low" | "normal" | "high" | "urgent" | undefined;
    expiresAt?: number | undefined;
    type: "info" | "success" | "warning" | "error" | "order" | "payment" | "system";
    recipientId: string;
    recipientType: "admin" | "customer" | "attendant" | "station" | "all";
    title: string;
    message: string;
}, Promise<import("convex/values").GenericId<"notifications">>>;
//# sourceMappingURL=notifications.d.ts.map