/**
 * Services Functions
 *
 * Handles service information queries for public access (customers, attendants).
 * Admin functions are in admin.ts
 */
/**
 * Get all active services
 * Public query - can be used by customers, attendants, and guests
 */
export declare const getActive: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    _id: import("convex/values").GenericId<"services">;
    name: string;
    code: string;
    description: string | undefined;
    imageUrl: string | undefined;
    basePrice: number;
    pricingType: "per_kg" | "per_load";
    isActive: boolean;
}[]>>;
/**
 * Seed default services
 * Public mutation - can be called without authentication to initialize services
 * Idempotent - won't create duplicates if services already exist
 */
export declare const seedDefaultServices: import("convex/server").RegisteredMutation<"public", {}, Promise<{
    success: boolean;
    created: string[];
    skipped: string[];
    message: string;
}>>;
//# sourceMappingURL=services.d.ts.map