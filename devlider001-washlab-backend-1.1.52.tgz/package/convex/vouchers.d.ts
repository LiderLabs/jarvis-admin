/**
 * Voucher Functions
 *
 * Handles discount vouchers and promo codes creation, validation, and application.
 */
/**
 * Get all vouchers (admin only)
 */
export declare const getAll: import("convex/server").RegisteredQuery<"public", {
    numItems?: number | undefined;
    cursor?: string | undefined;
    includeInactive?: boolean | undefined;
}, Promise<{
    page: {
        _id: import("convex/values").GenericId<"vouchers">;
        _creationTime: number;
        name?: string | undefined;
        description?: string | undefined;
        maxUsesPerCustomer?: number | undefined;
        validFrom?: number | undefined;
        validUntil?: number | undefined;
        minOrderValue?: number | undefined;
        applicableBranches?: import("convex/values").GenericId<"branches">[] | undefined;
        applicableServiceTypes?: ("wash_only" | "wash_and_dry" | "dry_only")[] | undefined;
        createdAt: number;
        isDeleted: boolean;
        isActive: boolean;
        createdBy: import("convex/values").GenericId<"admins">;
        code: string;
        discountType: "percentage" | "fixed" | "free_wash";
        discountValue: number;
        usageLimit: number;
        usedCount: number;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Get active vouchers (public - for customers/attendants)
 */
export declare const getActive: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
}, Promise<{
    _id: import("convex/values").GenericId<"vouchers">;
    _creationTime: number;
    name?: string | undefined;
    description?: string | undefined;
    maxUsesPerCustomer?: number | undefined;
    validFrom?: number | undefined;
    validUntil?: number | undefined;
    minOrderValue?: number | undefined;
    applicableBranches?: import("convex/values").GenericId<"branches">[] | undefined;
    applicableServiceTypes?: ("wash_only" | "wash_and_dry" | "dry_only")[] | undefined;
    createdAt: number;
    isDeleted: boolean;
    isActive: boolean;
    createdBy: import("convex/values").GenericId<"admins">;
    code: string;
    discountType: "percentage" | "fixed" | "free_wash";
    discountValue: number;
    usageLimit: number;
    usedCount: number;
}[]>>;
/**
 * Get voucher by code
 */
export declare const getByCode: import("convex/server").RegisteredQuery<"public", {
    code: string;
}, Promise<{
    _id: import("convex/values").GenericId<"vouchers">;
    _creationTime: number;
    name?: string | undefined;
    description?: string | undefined;
    maxUsesPerCustomer?: number | undefined;
    validFrom?: number | undefined;
    validUntil?: number | undefined;
    minOrderValue?: number | undefined;
    applicableBranches?: import("convex/values").GenericId<"branches">[] | undefined;
    applicableServiceTypes?: ("wash_only" | "wash_and_dry" | "dry_only")[] | undefined;
    createdAt: number;
    isDeleted: boolean;
    isActive: boolean;
    createdBy: import("convex/values").GenericId<"admins">;
    code: string;
    discountType: "percentage" | "fixed" | "free_wash";
    discountValue: number;
    usageLimit: number;
    usedCount: number;
} | null>>;
/**
 * Validate voucher for order
 */
export declare const validate: import("convex/server").RegisteredQuery<"public", {
    serviceType?: "wash_only" | "wash_and_dry" | "dry_only" | undefined;
    branchId: import("convex/values").GenericId<"branches">;
    code: string;
    orderTotal: number;
}, Promise<{
    valid: boolean;
    error: string;
    voucher?: undefined;
    discountAmount?: undefined;
    finalPrice?: undefined;
} | {
    valid: boolean;
    voucher: {
        _id: import("convex/values").GenericId<"vouchers">;
        code: string;
        name: string | undefined;
        discountType: "percentage" | "fixed" | "free_wash";
        discountValue: number;
    };
    discountAmount: number;
    finalPrice: number;
    error?: undefined;
}>>;
/**
 * Create voucher (admin only)
 */
export declare const create: import("convex/server").RegisteredMutation<"public", {
    name?: string | undefined;
    description?: string | undefined;
    maxUsesPerCustomer?: number | undefined;
    validFrom?: number | undefined;
    validUntil?: number | undefined;
    minOrderValue?: number | undefined;
    applicableBranches?: import("convex/values").GenericId<"branches">[] | undefined;
    applicableServiceTypes?: ("wash_only" | "wash_and_dry" | "dry_only")[] | undefined;
    code: string;
    discountType: "percentage" | "fixed" | "free_wash";
    discountValue: number;
    usageLimit: number;
}, Promise<import("convex/values").GenericId<"vouchers">>>;
/**
 * Update voucher (admin only)
 */
export declare const update: import("convex/server").RegisteredMutation<"public", {
    name?: string | undefined;
    isActive?: boolean | undefined;
    description?: string | undefined;
    discountType?: "percentage" | "fixed" | "free_wash" | undefined;
    discountValue?: number | undefined;
    usageLimit?: number | undefined;
    maxUsesPerCustomer?: number | undefined;
    validFrom?: number | undefined;
    validUntil?: number | undefined;
    minOrderValue?: number | undefined;
    applicableBranches?: import("convex/values").GenericId<"branches">[] | undefined;
    applicableServiceTypes?: ("wash_only" | "wash_and_dry" | "dry_only")[] | undefined;
    voucherId: import("convex/values").GenericId<"vouchers">;
}, Promise<import("convex/values").GenericId<"vouchers">>>;
/**
 * Apply voucher to order
 */
export declare const applyToOrder: import("convex/server").RegisteredMutation<"public", {
    orderId: import("convex/values").GenericId<"orders">;
    voucherCode: string;
}, Promise<{
    voucherId: import("convex/values").GenericId<"vouchers">;
    discountAmount: number;
    finalPrice: number;
}>>;
/**
 * Get voucher usage history (admin only)
 */
export declare const getUsageHistory: import("convex/server").RegisteredQuery<"public", {
    voucherId?: import("convex/values").GenericId<"vouchers"> | undefined;
    numItems?: number | undefined;
    cursor?: string | undefined;
}, Promise<{
    page: {
        _id: import("convex/values").GenericId<"voucherUsages">;
        _creationTime: number;
        usedBy?: import("convex/values").GenericId<"attendants"> | undefined;
        isDeleted: boolean;
        customerId: import("convex/values").GenericId<"users">;
        orderId: import("convex/values").GenericId<"orders">;
        voucherId: import("convex/values").GenericId<"vouchers">;
        discountAmount: number;
        orderTotalBefore: number;
        orderTotalAfter: number;
        usedAt: number;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
//# sourceMappingURL=vouchers.d.ts.map