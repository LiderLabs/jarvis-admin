/**
 * Audit Functions
 *
 * Handles querying audit logs for compliance and accountability.
 * Only admins can access audit logs.
 */
/**
 * Get audit logs by entity
 */
export declare const getByEntity: import("convex/server").RegisteredQuery<"public", {
    entityId?: string | undefined;
    limit?: number | undefined;
    entityType: string;
}, Promise<{
    _id: import("convex/values").GenericId<"auditLogs">;
    _creationTime: number;
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    deviceId?: string | undefined;
    entityId?: string | undefined;
    attendanceId?: import("convex/values").GenericId<"attendanceLogs"> | undefined;
    ipAddress?: string | undefined;
    details?: string | undefined;
    oldValue?: string | undefined;
    newValue?: string | undefined;
    actorId: string;
    actorType: "admin" | "customer" | "attendant";
    actorRole: string;
    action: string;
    entityType: string;
    timestamp: number;
}[]>>;
/**
 * Get audit logs by actor
 */
export declare const getByActor: import("convex/server").RegisteredQuery<"public", {
    actorType?: "admin" | "customer" | "attendant" | undefined;
    limit?: number | undefined;
    actorId: string;
}, Promise<{
    _id: import("convex/values").GenericId<"auditLogs">;
    _creationTime: number;
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    deviceId?: string | undefined;
    entityId?: string | undefined;
    attendanceId?: import("convex/values").GenericId<"attendanceLogs"> | undefined;
    ipAddress?: string | undefined;
    details?: string | undefined;
    oldValue?: string | undefined;
    newValue?: string | undefined;
    actorId: string;
    actorType: "admin" | "customer" | "attendant";
    actorRole: string;
    action: string;
    entityType: string;
    timestamp: number;
}[]>>;
/**
 * Get audit logs by branch
 */
export declare const getByBranch: import("convex/server").RegisteredQuery<"public", {
    limit?: number | undefined;
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<{
    _id: import("convex/values").GenericId<"auditLogs">;
    _creationTime: number;
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    deviceId?: string | undefined;
    entityId?: string | undefined;
    attendanceId?: import("convex/values").GenericId<"attendanceLogs"> | undefined;
    ipAddress?: string | undefined;
    details?: string | undefined;
    oldValue?: string | undefined;
    newValue?: string | undefined;
    actorId: string;
    actorType: "admin" | "customer" | "attendant";
    actorRole: string;
    action: string;
    entityType: string;
    timestamp: number;
}[]>>;
/**
 * Get audit logs by action
 */
export declare const getByAction: import("convex/server").RegisteredQuery<"public", {
    limit?: number | undefined;
    action: string;
}, Promise<{
    _id: import("convex/values").GenericId<"auditLogs">;
    _creationTime: number;
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    deviceId?: string | undefined;
    entityId?: string | undefined;
    attendanceId?: import("convex/values").GenericId<"attendanceLogs"> | undefined;
    ipAddress?: string | undefined;
    details?: string | undefined;
    oldValue?: string | undefined;
    newValue?: string | undefined;
    actorId: string;
    actorType: "admin" | "customer" | "attendant";
    actorRole: string;
    action: string;
    entityType: string;
    timestamp: number;
}[]>>;
/**
 * Get audit logs by time range
 */
export declare const getByTimeRange: import("convex/server").RegisteredQuery<"public", {
    limit?: number | undefined;
    startTimestamp: number;
    endTimestamp: number;
}, Promise<{
    _id: import("convex/values").GenericId<"auditLogs">;
    _creationTime: number;
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    deviceId?: string | undefined;
    entityId?: string | undefined;
    attendanceId?: import("convex/values").GenericId<"attendanceLogs"> | undefined;
    ipAddress?: string | undefined;
    details?: string | undefined;
    oldValue?: string | undefined;
    newValue?: string | undefined;
    actorId: string;
    actorType: "admin" | "customer" | "attendant";
    actorRole: string;
    action: string;
    entityType: string;
    timestamp: number;
}[]>>;
/**
 * Get all audit logs with filters - Paginated
 * Supports usePaginatedQuery for infinite scroll
 */
export declare const getAll: import("convex/server").RegisteredQuery<"public", {
    actorType?: "admin" | "customer" | "attendant" | undefined;
    action?: string | undefined;
    entityType?: string | undefined;
    startTimestamp?: number | undefined;
    endTimestamp?: number | undefined;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        _id: import("convex/values").GenericId<"auditLogs">;
        _creationTime: number;
        branchId?: import("convex/values").GenericId<"branches"> | undefined;
        deviceId?: string | undefined;
        entityId?: string | undefined;
        attendanceId?: import("convex/values").GenericId<"attendanceLogs"> | undefined;
        ipAddress?: string | undefined;
        details?: string | undefined;
        oldValue?: string | undefined;
        newValue?: string | undefined;
        actorId: string;
        actorType: "admin" | "customer" | "attendant";
        actorRole: string;
        action: string;
        entityType: string;
        timestamp: number;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
//# sourceMappingURL=audit.d.ts.map