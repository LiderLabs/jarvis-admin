/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as actions from "../actions.js";
import type * as admin from "../admin.js";
import type * as analytics from "../analytics.js";
import type * as attendants from "../attendants.js";
import type * as audit from "../audit.js";
import type * as branches from "../branches.js";
import type * as clerk from "../clerk.js";
import type * as customers from "../customers.js";
import type * as http from "../http.js";
import type * as inventory from "../inventory.js";
import type * as lib_attendance from "../lib/attendance.js";
import type * as lib_audit from "../lib/audit.js";
import type * as lib_auth from "../lib/auth.js";
import type * as lib_biometricComparison from "../lib/biometricComparison.js";
import type * as lib_biometricEncryption from "../lib/biometricEncryption.js";
import type * as lib_hubtel from "../lib/hubtel.js";
import type * as lib_passwordHashing from "../lib/passwordHashing.js";
import type * as lib_tokenHashing from "../lib/tokenHashing.js";
import type * as lib_utils from "../lib/utils.js";
import type * as loyalty from "../loyalty.js";
import type * as migration from "../migration.js";
import type * as notifications from "../notifications.js";
import type * as orders from "../orders.js";
import type * as payments from "../payments.js";
import type * as resources from "../resources.js";
import type * as services from "../services.js";
import type * as stations from "../stations.js";
import type * as vouchers from "../vouchers.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  actions: typeof actions;
  admin: typeof admin;
  analytics: typeof analytics;
  attendants: typeof attendants;
  audit: typeof audit;
  branches: typeof branches;
  clerk: typeof clerk;
  customers: typeof customers;
  http: typeof http;
  inventory: typeof inventory;
  "lib/attendance": typeof lib_attendance;
  "lib/audit": typeof lib_audit;
  "lib/auth": typeof lib_auth;
  "lib/biometricComparison": typeof lib_biometricComparison;
  "lib/biometricEncryption": typeof lib_biometricEncryption;
  "lib/hubtel": typeof lib_hubtel;
  "lib/passwordHashing": typeof lib_passwordHashing;
  "lib/tokenHashing": typeof lib_tokenHashing;
  "lib/utils": typeof lib_utils;
  loyalty: typeof loyalty;
  migration: typeof migration;
  notifications: typeof notifications;
  orders: typeof orders;
  payments: typeof payments;
  resources: typeof resources;
  services: typeof services;
  stations: typeof stations;
  vouchers: typeof vouchers;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
