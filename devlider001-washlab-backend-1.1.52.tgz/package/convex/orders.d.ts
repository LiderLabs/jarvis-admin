import { Id } from "./_generated/dataModel";
/**
 * Admin Functions
 *
 * Handles admin operations: branch management, attendant management,
 * system-wide order viewing, analytics, and customer management.
 */
/**
 * Get current admin profile (from authenticated Clerk session)
 */
export declare const getCurrentUser: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    _id: import("convex/values").GenericId<"admins">;
    _creationTime: number;
    lastLoginAt?: number | undefined;
    email: string;
    name: string;
    clerkUserId: string;
    createdAt: number;
    isDeleted: boolean;
    role: "super_admin" | "admin";
}>>;
/**
 * Get all branches - Paginated
 * Supports usePaginatedQuery for infinite scroll
 */
export declare const getBranches: import("convex/server").RegisteredQuery<"public", {
    includeInactive?: boolean | undefined;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        _id: import("convex/values").GenericId<"branches">;
        _creationTime: number;
        email?: string | undefined;
        terminalId?: string | undefined;
        stationPinHash?: string | undefined;
        requireStationLogin?: boolean | undefined;
        phoneNumber: string;
        name: string;
        createdAt: number;
        isDeleted: boolean;
        isActive: boolean;
        createdBy: import("convex/values").GenericId<"admins">;
        code: string;
        address: string;
        city: string;
        country: string;
        pricingPerKg: number;
        deliveryFee: number;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Get branch by code
 */
export declare const getBranchByCode: import("convex/server").RegisteredQuery<"public", {
    code: string;
}, Promise<{
    _id: import("convex/values").GenericId<"branches">;
    _creationTime: number;
    email?: string | undefined;
    terminalId?: string | undefined;
    stationPinHash?: string | undefined;
    requireStationLogin?: boolean | undefined;
    phoneNumber: string;
    name: string;
    createdAt: number;
    isDeleted: boolean;
    isActive: boolean;
    createdBy: import("convex/values").GenericId<"admins">;
    code: string;
    address: string;
    city: string;
    country: string;
    pricingPerKg: number;
    deliveryFee: number;
} | null>>;
/**
 * Get single branch by ID
 */
export declare const getBranch: import("convex/server").RegisteredQuery<"public", {
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<{
    _id: import("convex/values").GenericId<"branches">;
    _creationTime: number;
    email?: string | undefined;
    terminalId?: string | undefined;
    stationPinHash?: string | undefined;
    requireStationLogin?: boolean | undefined;
    phoneNumber: string;
    name: string;
    createdAt: number;
    isDeleted: boolean;
    isActive: boolean;
    createdBy: import("convex/values").GenericId<"admins">;
    code: string;
    address: string;
    city: string;
    country: string;
    pricingPerKg: number;
    deliveryFee: number;
} | null>>;
/**
 * Get pending online orders (awaiting drop-off at POS)
 */
export declare const getPending: import("convex/server").RegisteredQuery<"public", {
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<{
    _id: import("convex/values").GenericId<"orders">;
    _creationTime: number;
    createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
    customerEmail?: string | undefined;
    estimatedWeight?: number | undefined;
    actualWeight?: number | undefined;
    itemCount?: number | undefined;
    estimatedLoads?: number | undefined;
    whitesSeparate?: boolean | undefined;
    bagCardNumber?: string | undefined;
    notes?: string | undefined;
    deliveryAddress?: string | undefined;
    deliveryPhoneNumber?: string | undefined;
    deliveryHall?: string | undefined;
    deliveryRoom?: string | undefined;
    paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
    paymentId?: import("convex/values").GenericId<"payments"> | undefined;
    assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
    fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
    status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    deliveryFee: number;
    customerId: import("convex/values").GenericId<"users">;
    customerPhoneNumber: string;
    orderNumber: string;
    orderType: "walk_in" | "online";
    serviceType: "wash_only" | "wash_and_dry" | "dry_only";
    isDelivery: boolean;
    basePrice: number;
    totalPrice: number;
    finalPrice: number;
    paymentStatus: "pending" | "paid" | "failed" | "refunded";
    updatedAt: number;
    statusHistory: {
        notes?: string | undefined;
        changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
        changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
        status: string;
        changedAt: number;
    }[];
}[]>>;
export declare const updateWeight: import("convex/server").RegisteredMutation<"public", {
    bagCardNumber?: string | undefined;
    actualWeight: number;
    itemCount: number;
    orderId: import("convex/values").GenericId<"orders">;
}, Promise<void>>;
/**
 * Get all attendants - Paginated
 * Supports usePaginatedQuery for infinite scroll
 */
export declare const getAttendants: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    numItems?: number | undefined;
    cursor?: string | undefined;
    includeInactive?: boolean | undefined;
}, Promise<{
    page: {
        _id: import("convex/values").GenericId<"attendants">;
        _creationTime: number;
        clerkUserId?: string | undefined;
        lastLoginAt?: number | undefined;
        passcodeHash?: string | undefined;
        passcodeSalt?: string | undefined;
        authenticationMethods?: ("biometric_face" | "biometric_hand" | "pin" | "password")[] | undefined;
        enrollmentTokenHash?: string | undefined;
        enrollmentTokenExpiresAt?: number | undefined;
        enrolledAt?: number | undefined;
        enrolledBy?: import("convex/values").GenericId<"admins"> | undefined;
        biometricTemplateHash?: string | undefined;
        biometricDataEncrypted?: string | undefined;
        biometricCaptureMetadata?: {
            deviceInfo?: string | undefined;
            captureType: "face" | "hand";
            anglesCaptured: string[];
            captureQuality: number;
            livenessPassed: boolean;
            captureTimestamp: number;
        } | undefined;
        lastVerificationAt?: number | undefined;
        lastVerificationSuccess?: boolean | undefined;
        verificationTimeoutAt?: number | undefined;
        phoneNumber: string;
        email: string;
        name: string;
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        isActive: boolean;
        enrollmentStatus: "active" | "suspended" | "invited" | "enrolling" | "biometric_complete" | "locked";
        consecutiveFailures: number;
        createdBy: import("convex/values").GenericId<"admins">;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Get all orders (with filters) - Paginated
 * Supports usePaginatedQuery for infinite scroll
 */
export declare const getOrders: import("convex/server").RegisteredQuery<"public", {
    status?: "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered" | undefined;
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    orderType?: "walk_in" | "online" | undefined;
    startDate?: number | undefined;
    endDate?: number | undefined;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        _id: import("convex/values").GenericId<"orders">;
        _creationTime: number;
        createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
        customerEmail?: string | undefined;
        estimatedWeight?: number | undefined;
        actualWeight?: number | undefined;
        itemCount?: number | undefined;
        estimatedLoads?: number | undefined;
        whitesSeparate?: boolean | undefined;
        bagCardNumber?: string | undefined;
        notes?: string | undefined;
        deliveryAddress?: string | undefined;
        deliveryPhoneNumber?: string | undefined;
        deliveryHall?: string | undefined;
        deliveryRoom?: string | undefined;
        paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
        paymentId?: import("convex/values").GenericId<"payments"> | undefined;
        assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
        fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
        status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        deliveryFee: number;
        customerId: import("convex/values").GenericId<"users">;
        customerPhoneNumber: string;
        orderNumber: string;
        orderType: "walk_in" | "online";
        serviceType: "wash_only" | "wash_and_dry" | "dry_only";
        isDelivery: boolean;
        basePrice: number;
        totalPrice: number;
        finalPrice: number;
        paymentStatus: "pending" | "paid" | "failed" | "refunded";
        updatedAt: number;
        statusHistory: {
            notes?: string | undefined;
            changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
            changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
            status: string;
            changedAt: number;
        }[];
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Get analytics dashboard data
 */
export declare const getAnalytics: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    startDate?: number | undefined;
    endDate?: number | undefined;
}, Promise<{
    totalOrders: number;
    totalRevenue: number;
    averageOrderValue: number;
    ordersByStatus: Record<string, number>;
    ordersByDay: Record<string, number>;
    topCustomers: {
        customerId: Id<"users">;
        name: string;
        phoneNumber: string;
        orderCount: number;
    }[];
    dateRange: {
        start: number | undefined;
        end: number | undefined;
    };
}>>;
/**
 * Get all customers (with filters) - Paginated
 * Supports usePaginatedQuery for infinite scroll
 */
export declare const getCustomers: import("convex/server").RegisteredQuery<"public", {
    isRegistered?: boolean | undefined;
    status?: "active" | "blocked" | "suspended" | "restricted" | undefined;
    search?: string | undefined;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        orderCount: number;
        completedOrderCount: number;
        totalSpent: number;
        lastOrderDate: number;
        lastOrderNumber: string;
        _id: import("convex/values").GenericId<"users">;
        _creationTime: number;
        email?: string | undefined;
        clerkUserId?: string | undefined;
        status?: "active" | "blocked" | "suspended" | "restricted" | undefined;
        statusNote?: string | undefined;
        statusChangedBy?: import("convex/values").GenericId<"admins"> | undefined;
        statusChangedAt?: number | undefined;
        lastLoginAt?: number | undefined;
        preferredBranchId?: import("convex/values").GenericId<"branches"> | undefined;
        phoneNumber: string;
        name: string;
        isRegistered: boolean;
        isVerified: boolean;
        createdAt: number;
        isDeleted: boolean;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Get customer statistics/aggregations
 */
export declare const getCustomerStats: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    totalCustomers: number;
    registeredCustomers: number;
    walkInCustomers: number;
    activeCustomers: number;
    blockedCustomers: number;
    suspendedCustomers: number;
    restrictedCustomers: number;
    verifiedCustomers: number;
    customersWithActiveOrders: number;
    totalRevenue: number;
}>>;
/**
 * Change customer status (with required note)
 */
export declare const changeCustomerStatus: import("convex/server").RegisteredMutation<"public", {
    status: "active" | "blocked" | "suspended" | "restricted";
    customerId: import("convex/values").GenericId<"users">;
    note: string;
}, Promise<import("convex/values").GenericId<"users">>>;
/**
 * Delete a customer (soft delete)
 */
export declare const deleteCustomer: import("convex/server").RegisteredMutation<"public", {
    customerId: import("convex/values").GenericId<"users">;
}, Promise<import("convex/values").GenericId<"users">>>;
/**
 * Create new branch
 */
export declare const createBranch: import("convex/server").RegisteredMutation<"public", {
    email?: string | undefined;
    phoneNumber: string;
    name: string;
    code: string;
    terminalId: string;
    address: string;
    city: string;
    country: string;
    pricingPerKg: number;
    deliveryFee: number;
}, Promise<import("convex/values").GenericId<"branches">>>;
/**
 * Update branch details
 */
export declare const updateBranch: import("convex/server").RegisteredMutation<"public", {
    phoneNumber?: string | undefined;
    email?: string | undefined;
    name?: string | undefined;
    isActive?: boolean | undefined;
    code?: string | undefined;
    address?: string | undefined;
    city?: string | undefined;
    country?: string | undefined;
    pricingPerKg?: number | undefined;
    deliveryFee?: number | undefined;
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<import("convex/values").GenericId<"branches">>>;
/**
 * Toggle branch active status (enable/disable)
 */
export declare const toggleBranchStatus: import("convex/server").RegisteredMutation<"public", {
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<{
    branchId: import("convex/values").GenericId<"branches">;
    isActive: boolean;
}>>;
/**
 * Delete branch (soft delete)
 */
export declare const deleteBranch: import("convex/server").RegisteredMutation<"public", {
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<import("convex/values").GenericId<"branches">>>;
/**
 * Create attendant account
 * Note: Clerk user must be created separately, then link clerkUserId
 */
export declare const createAttendant: import("convex/server").RegisteredMutation<"public", {
    passcode?: string | undefined;
    phoneNumber: string;
    email: string;
    name: string;
    clerkUserId: string;
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<import("convex/values").GenericId<"attendants">>>;
/**
 * Update attendant details
 */
export declare const updateAttendant: import("convex/server").RegisteredMutation<"public", {
    phoneNumber?: string | undefined;
    email?: string | undefined;
    name?: string | undefined;
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    isActive?: boolean | undefined;
    passcode?: string | undefined;
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<import("convex/values").GenericId<"attendants">>>;
/**
 * Assign attendant to branch
 */
export declare const assignAttendantToBranch: import("convex/server").RegisteredMutation<"public", {
    branchId: import("convex/values").GenericId<"branches">;
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<import("convex/values").GenericId<"attendants">>>;
/**
 * Delete attendant (soft delete)
 */
export declare const deleteAttendant: import("convex/server").RegisteredMutation<"public", {
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<import("convex/values").GenericId<"attendants">>>;
/**
 * Create admin account
 * Only super admins can create other admins
 * Note: Clerk user must be created separately, then link clerkUserId
 */
export declare const createAdmin: import("convex/server").RegisteredMutation<"public", {
    email: string;
    name: string;
    clerkUserId: string;
    role: "super_admin" | "admin";
}, Promise<import("convex/values").GenericId<"admins">>>;
/**
 * Create the first super admin (one-time setup)
 * This function can only be used when no super admins exist in the database
 * After the first super admin is created, use createAdmin instead
 */
export declare const createFirstSuperAdmin: import("convex/server").RegisteredMutation<"public", {
    email: string;
    name: string;
    clerkUserId: string;
}, Promise<import("convex/values").GenericId<"admins">>>;
/**
 * Admin: Update order status (admin can update any order)
 */
export declare const updateOrderStatus: import("convex/server").RegisteredMutation<"public", {
    notes?: string | undefined;
    orderId: import("convex/values").GenericId<"orders">;
    newStatus: "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
}, Promise<import("convex/values").GenericId<"orders">>>;
/**
 * Admin: Delete order (soft delete)
 */
export declare const deleteOrder: import("convex/server").RegisteredMutation<"public", {
    orderId: import("convex/values").GenericId<"orders">;
}, Promise<import("convex/values").GenericId<"orders">>>;
/**
 * Admin: Get order details (includes full order information with customer and branch)
 */
export declare const getOrderDetails: import("convex/server").RegisteredQuery<"public", {
    orderId: import("convex/values").GenericId<"orders">;
}, Promise<{
    customer: {
        _id: import("convex/values").GenericId<"users">;
        name: string;
        phoneNumber: string;
        email: string | undefined;
    } | null;
    branch: {
        _id: import("convex/values").GenericId<"branches">;
        name: string;
        code: string;
        address: string;
        city: string;
    } | null;
    _id: import("convex/values").GenericId<"orders">;
    _creationTime: number;
    createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
    customerEmail?: string | undefined;
    estimatedWeight?: number | undefined;
    actualWeight?: number | undefined;
    itemCount?: number | undefined;
    estimatedLoads?: number | undefined;
    whitesSeparate?: boolean | undefined;
    bagCardNumber?: string | undefined;
    notes?: string | undefined;
    deliveryAddress?: string | undefined;
    deliveryPhoneNumber?: string | undefined;
    deliveryHall?: string | undefined;
    deliveryRoom?: string | undefined;
    paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
    paymentId?: import("convex/values").GenericId<"payments"> | undefined;
    assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
    fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
    status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    deliveryFee: number;
    customerId: import("convex/values").GenericId<"users">;
    customerPhoneNumber: string;
    orderNumber: string;
    orderType: "walk_in" | "online";
    serviceType: "wash_only" | "wash_and_dry" | "dry_only";
    isDelivery: boolean;
    basePrice: number;
    totalPrice: number;
    finalPrice: number;
    paymentStatus: "pending" | "paid" | "failed" | "refunded";
    updatedAt: number;
    statusHistory: {
        notes?: string | undefined;
        changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
        changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
        status: string;
        changedAt: number;
    }[];
} | null>>;
/**
 * Get order by order number (public - for tracking page)
 * Allows customers to track orders without authentication
 */
export declare const getByOrderNumber: import("convex/server").RegisteredQuery<"public", {
    orderNumber: string;
}, Promise<{
    _id: import("convex/values").GenericId<"orders">;
    _creationTime: number;
    createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
    customerEmail?: string | undefined;
    estimatedWeight?: number | undefined;
    actualWeight?: number | undefined;
    itemCount?: number | undefined;
    estimatedLoads?: number | undefined;
    whitesSeparate?: boolean | undefined;
    bagCardNumber?: string | undefined;
    notes?: string | undefined;
    deliveryAddress?: string | undefined;
    deliveryPhoneNumber?: string | undefined;
    deliveryHall?: string | undefined;
    deliveryRoom?: string | undefined;
    paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
    paymentId?: import("convex/values").GenericId<"payments"> | undefined;
    assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
    fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
    status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    deliveryFee: number;
    customerId: import("convex/values").GenericId<"users">;
    customerPhoneNumber: string;
    orderNumber: string;
    orderType: "walk_in" | "online";
    serviceType: "wash_only" | "wash_and_dry" | "dry_only";
    isDelivery: boolean;
    basePrice: number;
    totalPrice: number;
    finalPrice: number;
    paymentStatus: "pending" | "paid" | "failed" | "refunded";
    updatedAt: number;
    statusHistory: {
        notes?: string | undefined;
        changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
        changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
        status: string;
        changedAt: number;
    }[];
} | null>>;
/**
 * Create online order (customer creates from website)
 * Supports both guest checkout and authenticated users
 */
export declare const createOnline: import("convex/server").RegisteredMutation<"public", {
    estimatedLoads?: number | undefined;
    whitesSeparate?: boolean | undefined;
    bagCardNumber?: string | undefined;
    notes?: string | undefined;
    deliveryAddress?: string | undefined;
    deliveryPhoneNumber?: string | undefined;
    deliveryHall?: string | undefined;
    deliveryRoom?: string | undefined;
    branchId: import("convex/values").GenericId<"branches">;
    customerPhoneNumber: string;
    customerEmail: string;
    serviceType: "wash_only" | "wash_and_dry" | "dry_only";
    estimatedWeight: number;
    itemCount: number;
    isDelivery: boolean;
    customerName: string;
}, Promise<{
    orderId: import("convex/values").GenericId<"orders">;
    orderNumber: string;
    isGuest: boolean;
}>>;
//# sourceMappingURL=orders.d.ts.map