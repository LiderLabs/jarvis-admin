/**
 * Station/Branch Login Functions
 *
 * Handles station (branch) login and session management.
 * Station login is separate from attendant authentication.
 */
import { Id } from "./_generated/dataModel";
/**
 * Get all active branches with codes (public - no auth required)
 * Used for displaying available branch codes on login page
 */
export declare const getActiveBranches: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    code: string;
    name: string;
}[]>>;
/**
 * Verify branch code (public - no auth required)
 * Returns branch info without sensitive data
 */
export declare const verifyBranchCode: import("convex/server").RegisteredQuery<"public", {
    code: string;
}, Promise<{
    _id: import("convex/values").GenericId<"branches">;
    name: string;
    code: string;
    address: string;
    city: string;
    country: string;
    phoneNumber: string;
    email: string | undefined;
    requireStationLogin: boolean;
    hasStationPin: boolean;
} | null>>;
/**
 * Login to station (branch) - First step
 */
export declare const loginStation: import("convex/server").RegisteredMutation<"public", {
    deviceInfo?: string | undefined;
    branchId: import("convex/values").GenericId<"branches">;
    deviceId: string;
    stationPin: string;
}, Promise<{
    stationToken: string;
    sessionId: import("convex/values").GenericId<"stationSessions">;
    branchId: import("convex/values").GenericId<"branches">;
    branchName: string;
    expiresAt: number;
    loggedInBy: any;
    loggedInAt: number;
} | {
    stationToken: string;
    sessionId: import("convex/values").GenericId<"stationSessions">;
    branchId: import("convex/values").GenericId<"branches">;
    branchName: string;
    expiresAt: number;
    loggedInBy?: undefined;
    loggedInAt?: undefined;
}>>;
/**
 * Verify station session
 */
export declare const verifyStationSession: import("convex/server").RegisteredQuery<"public", {
    stationToken: string;
}, Promise<{
    valid: boolean;
    reason: string;
    branchActive: boolean;
    branchId?: undefined;
    branchName?: undefined;
    branchCode?: undefined;
    terminalId?: undefined;
    deviceId?: undefined;
    sessionId?: undefined;
} | {
    valid: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    branchName: string;
    branchCode: string;
    branchActive: boolean;
    reason: string;
    terminalId: string | undefined;
    deviceId: string;
    sessionId: string;
} | {
    valid: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    branchName: string;
    branchCode: string;
    branchActive: boolean;
    terminalId: string | undefined;
    deviceId: string;
    sessionId: string;
    reason?: undefined;
}>>;
/**
 * Logout from station
 */
export declare const logoutStation: import("convex/server").RegisteredMutation<"public", {
    stationToken: string;
}, Promise<{
    success: boolean;
}>>;
/**
 * Get active station session info
 */
export declare const getActiveStationSession: import("convex/server").RegisteredQuery<"public", {
    stationToken: string;
}, Promise<{
    sessionId: import("convex/values").GenericId<"stationSessions">;
    branchId: import("convex/values").GenericId<"branches">;
    branchName: string;
    deviceId: string;
    loggedInAt: number;
    expiresAt: number;
} | null>>;
/**
 * Get station orders with pagination and filtering
 */
export declare const getStationOrders: import("convex/server").RegisteredQuery<"public", {
    status?: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered" | undefined;
    orderType?: "walk_in" | "online" | undefined;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
    stationToken: string;
}, Promise<{
    page: {
        customer: {
            _id: import("convex/values").GenericId<"users">;
            name: string;
            phoneNumber: string;
            email: string | undefined;
        } | null;
        assignedAttendant: {
            _id: any;
            name: any;
            email: any;
        } | null;
        statusHistory: ({
            changedBy: {
                type: "attendant";
                name: any;
            };
            notes?: string | undefined;
            changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
            status: string;
            changedAt: number;
        } | {
            changedBy: {
                type: "admin";
                name: any;
            };
            notes?: string | undefined;
            changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
            status: string;
            changedAt: number;
        } | {
            changedBy: undefined;
            notes?: string | undefined;
            changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
            status: string;
            changedAt: number;
        })[];
        _id: import("convex/values").GenericId<"orders">;
        _creationTime: number;
        createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
        customerEmail?: string | undefined;
        estimatedWeight?: number | undefined;
        actualWeight?: number | undefined;
        itemCount?: number | undefined;
        estimatedLoads?: number | undefined;
        whitesSeparate?: boolean | undefined;
        bagCardNumber?: string | undefined;
        notes?: string | undefined;
        deliveryAddress?: string | undefined;
        deliveryPhoneNumber?: string | undefined;
        deliveryHall?: string | undefined;
        deliveryRoom?: string | undefined;
        paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
        paymentId?: import("convex/values").GenericId<"payments"> | undefined;
        assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
        fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
        status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        deliveryFee: number;
        customerId: import("convex/values").GenericId<"users">;
        customerPhoneNumber: string;
        orderNumber: string;
        orderType: "walk_in" | "online";
        serviceType: "wash_only" | "wash_and_dry" | "dry_only";
        isDelivery: boolean;
        basePrice: number;
        totalPrice: number;
        finalPrice: number;
        paymentStatus: "pending" | "paid" | "failed" | "refunded";
        updatedAt: number;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Get order details for station
 */
export declare const getStationOrderDetails: import("convex/server").RegisteredQuery<"public", {
    orderId: import("convex/values").GenericId<"orders">;
    stationToken: string;
}, Promise<{
    customer: {
        _id: import("convex/values").GenericId<"users">;
        name: string;
        phoneNumber: string;
        email: string | undefined;
    } | null;
    branch: {
        _id: import("convex/values").GenericId<"branches">;
        name: string;
        code: string;
        address: string;
    };
    statusHistory: ({
        changedBy: {
            type: "attendant";
            name: any;
        };
        notes?: string | undefined;
        changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
        status: string;
        changedAt: number;
    } | {
        changedBy: {
            type: "admin";
            name: any;
        };
        notes?: string | undefined;
        changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
        status: string;
        changedAt: number;
    } | {
        changedBy: undefined;
        notes?: string | undefined;
        changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
        status: string;
        changedAt: number;
    })[];
    _id: import("convex/values").GenericId<"orders">;
    _creationTime: number;
    createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
    customerEmail?: string | undefined;
    estimatedWeight?: number | undefined;
    actualWeight?: number | undefined;
    itemCount?: number | undefined;
    estimatedLoads?: number | undefined;
    whitesSeparate?: boolean | undefined;
    bagCardNumber?: string | undefined;
    notes?: string | undefined;
    deliveryAddress?: string | undefined;
    deliveryPhoneNumber?: string | undefined;
    deliveryHall?: string | undefined;
    deliveryRoom?: string | undefined;
    paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
    paymentId?: import("convex/values").GenericId<"payments"> | undefined;
    assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
    fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
    status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    deliveryFee: number;
    customerId: import("convex/values").GenericId<"users">;
    customerPhoneNumber: string;
    orderNumber: string;
    orderType: "walk_in" | "online";
    serviceType: "wash_only" | "wash_and_dry" | "dry_only";
    isDelivery: boolean;
    basePrice: number;
    totalPrice: number;
    finalPrice: number;
    paymentStatus: "pending" | "paid" | "failed" | "refunded";
    updatedAt: number;
} | null>>;
/**
 * Update order status (for station)
 */
export declare const updateStationOrderStatus: import("convex/server").RegisteredMutation<"public", {
    notes?: string | undefined;
    attendantId?: import("convex/values").GenericId<"attendants"> | undefined;
    attendanceId?: import("convex/values").GenericId<"attendanceLogs"> | undefined;
    orderId: import("convex/values").GenericId<"orders">;
    newStatus: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
    stationToken: string;
}, Promise<{
    success: boolean;
    orderId: import("convex/values").GenericId<"orders">;
}>>;
/**
 * Check in online order (convert pending_dropoff to checked_in with weight)
 *
 * FIX: Creates a payment record after check-in so that finalizePaymentSafe
 * can find it when the attendant completes payment on the payment page.
 * Walk-in orders get a payment record created in createWalkInOrder, but
 * online orders had no equivalent — this closes that gap.
 */
export declare const checkInOnlineOrder: import("convex/server").RegisteredMutation<"public", {
    itemCount?: number | undefined;
    notes?: string | undefined;
    attendantId?: import("convex/values").GenericId<"attendants"> | undefined;
    attendanceId?: import("convex/values").GenericId<"attendanceLogs"> | undefined;
    actualWeight: number;
    bagCardNumber: string;
    orderId: import("convex/values").GenericId<"orders">;
    stationToken: string;
}, Promise<{
    success: boolean;
    orderId: import("convex/values").GenericId<"orders">;
    ussdSent: boolean;
    ussdMessage: string | undefined;
}>>;
/**
 * Cancel/reject online order (requires identity verification)
 */
export declare const cancelOnlineOrder: import("convex/server").RegisteredMutation<"public", {
    reason?: string | undefined;
    orderId: import("convex/values").GenericId<"orders">;
    verificationId: import("convex/values").GenericId<"biometricVerifications">;
    stationToken: string;
}, Promise<{
    success: boolean;
    orderId: import("convex/values").GenericId<"orders">;
}>>;
/**
 * Get station/branch info (pricing, etc.)
 */
export declare const getStationInfo: import("convex/server").RegisteredQuery<"public", {
    stationToken: string;
}, Promise<{
    branchId: import("convex/values").GenericId<"branches">;
    branchName: string;
    pricingPerKg: number;
    deliveryFee: number;
    terminalId: string | undefined;
    deviceId: string;
    loggedInAt: number;
}>>;
/**
 * Get station analytics/dashboard stats
 */
export declare const getStationStats: import("convex/server").RegisteredQuery<"public", {
    startDate?: number | undefined;
    endDate?: number | undefined;
    stationToken: string;
}, Promise<{
    totalOrders: number;
    totalRevenue: number;
    pendingOrders: number;
    ordersByStatus: {
        pending: number;
        in_progress: number;
        ready_for_pickup: number;
        delivered: number;
        completed: number;
        cancelled: number;
    };
    averageOrderValue: number;
}>>;
/**
 * Get station transaction history (paid orders)
 */
export declare const getStationTransactions: import("convex/server").RegisteredQuery<"public", {
    startDate?: number | undefined;
    endDate?: number | undefined;
    stationToken: string;
}, Promise<{
    orderId: import("convex/values").GenericId<"orders">;
    orderCode: string;
    amount: number;
    paymentMethod: "mobile_money" | "card" | "cash";
    orderType: "walk_in" | "online";
    status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
    staffId: any;
    staffName: any;
    verifiedAt: number;
    customerPhone: string;
    customerName: string;
    createdAt: number;
}[]>>;
/**
 * Search customers for station
 */
export declare const searchStationCustomers: import("convex/server").RegisteredQuery<"public", {
    limit?: number | undefined;
    query: string;
    stationToken: string;
}, Promise<{
    _id: import("convex/values").GenericId<"users">;
    name: string;
    phoneNumber: string;
    email: string | undefined;
    status: "active" | "blocked" | "suspended" | "restricted" | undefined;
    orderCount: number;
    completedOrderCount: number;
    totalSpent: number;
}[]>>;
/**
 * Get active attendance for station
 */
export declare const getActiveStationAttendances: import("convex/server").RegisteredQuery<"public", {
    stationToken: string;
}, Promise<{
    _id: import("convex/values").GenericId<"attendanceLogs">;
    clockInAt: number;
    deviceId: string | undefined;
    attendant: {
        _id: import("convex/values").GenericId<"attendants">;
        name: string;
        email: string;
    } | null;
}[]>>;
/**
 * Get attendants for branch (for clock-in selection)
 */
export declare const getBranchAttendants: import("convex/server").RegisteredQuery<"public", {
    stationToken: string;
}, Promise<{
    _id: import("convex/values").GenericId<"attendants">;
    name: string;
    email: string;
    hasBiometric: boolean;
    hasPin: boolean;
    authenticationMethods: ("biometric_face" | "biometric_hand" | "pin" | "password")[];
}[]>>;
/**
 * Start biometric verification for clock-in
 */
export declare const startClockInVerification: import("convex/server").RegisteredMutation<"public", {
    attendantId: import("convex/values").GenericId<"attendants">;
    stationToken: string;
}, Promise<{
    challenge: string;
    attendantId: import("convex/values").GenericId<"attendants">;
    verificationType: "login";
    requiresLiveness: boolean;
}>>;
/**
 * Complete clock-in with biometric verification
 */
export declare const completeClockIn: import("convex/server").RegisteredMutation<"public", {
    attendantId: import("convex/values").GenericId<"attendants">;
    challenge: string;
    biometricData: {
        deviceInfo?: string | undefined;
        captureType: "face" | "hand";
        captureQuality: number;
        angles: string[];
        features: string;
        measurements: string;
        livenessData: string;
    };
    stationToken: string;
}, Promise<{
    attendanceId: import("convex/values").GenericId<"attendanceLogs">;
    clockInAt: number;
    attendant: {
        _id: import("convex/values").GenericId<"attendants">;
        name: string;
        email: string;
    };
}>>;
/**
 * Start clock-out verification
 */
export declare const startClockOutVerification: import("convex/server").RegisteredMutation<"public", {
    attendanceId: import("convex/values").GenericId<"attendanceLogs">;
    stationToken: string;
}, Promise<{
    challenge: string;
    attendantId: import("convex/values").GenericId<"attendants">;
    verificationType: "action";
    requiresLiveness: boolean;
}>>;
/**
 * Complete clock-out with biometric verification
 */
export declare const completeClockOut: import("convex/server").RegisteredMutation<"public", {
    notes?: string | undefined;
    attendanceId: import("convex/values").GenericId<"attendanceLogs">;
    challenge: string;
    biometricData: {
        deviceInfo?: string | undefined;
        captureType: "face" | "hand";
        captureQuality: number;
        angles: string[];
        features: string;
        measurements: string;
        livenessData: string;
    };
    stationToken: string;
}, Promise<{
    attendanceId: import("convex/values").GenericId<"attendanceLogs">;
    durationMinutes: number;
    clockOutAt: number;
    sessionsRevoked: number;
}>>;
/**
 * Get attendance history for the station's branch
 */
export declare const getStationAttendanceHistory: import("convex/server").RegisteredQuery<"public", {
    startDate?: number | undefined;
    endDate?: number | undefined;
    limit?: number | undefined;
    stationToken: string;
}, Promise<{
    _id: import("convex/values").GenericId<"attendanceLogs">;
    clockInAt: number;
    clockOutAt: number | undefined;
    deviceId: string | undefined;
    isActive: boolean;
    durationMinutes: number | null;
    attendant: {
        _id: import("convex/values").GenericId<"attendants">;
        name: string;
        email: string;
    } | null;
}[]>>;
/**
 * Get activity logs for the station's branch
 */
export declare const getStationActivityLogs: import("convex/server").RegisteredQuery<"public", {
    limit?: number | undefined;
    stationToken: string;
}, Promise<{
    _id: import("convex/values").GenericId<"auditLogs">;
    action: string;
    entityType: string;
    entityId: string | undefined;
    actor: {
        type: "admin" | "customer" | "attendant";
        name: string;
        email: undefined;
    } | {
        type: "attendant";
        name: string;
        email: string;
    } | {
        type: "admin";
        name: string;
        email: string;
    } | {
        type: "customer";
        name: string;
        email: string | undefined;
    } | null;
    actorRole: string;
    attendanceId: import("convex/values").GenericId<"attendanceLogs"> | undefined;
    deviceId: string | undefined;
    details: string | undefined;
    oldValue: string | undefined;
    newValue: string | undefined;
    timestamp: number;
}[]>>;
/**
 * Get notifications for station
 */
export declare const getStationNotifications: import("convex/server").RegisteredQuery<"public", {
    type?: "info" | "success" | "warning" | "error" | "order" | "payment" | "system" | undefined;
    isRead?: boolean | undefined;
    limit?: number | undefined;
    stationToken: string;
}, Promise<{
    _id: Id<"notifications">;
    _creationTime: number;
    recipientId: string;
    recipientType: string;
    title: string;
    message: string;
    type: string;
    priority: string;
    isRead: boolean;
    createdAt: number;
    isDeleted: boolean;
    readAt?: number;
    actionUrl?: string;
    actionLabel?: string;
    entityType?: string;
    entityId?: string;
    senderId?: string;
    senderType?: string;
    branchId?: Id<"branches">;
}[]>>;
/**
 * Get unread notification count for station
 */
export declare const getStationUnreadCount: import("convex/server").RegisteredQuery<"public", {
    stationToken: string;
}, Promise<number>>;
/**
 * Mark station notification as read
 */
export declare const markStationNotificationAsRead: import("convex/server").RegisteredMutation<"public", {
    notificationId: import("convex/values").GenericId<"notifications">;
    stationToken: string;
}, Promise<{
    success: boolean;
}>>;
/**
 * Mark all station notifications as read
 */
export declare const markAllStationNotificationsAsRead: import("convex/server").RegisteredMutation<"public", {
    stationToken: string;
}, Promise<{
    success: boolean;
    count: number;
}>>;
/**
 * Get active bag numbers for a branch
 */
export declare const getActiveBagNumbers: import("convex/server").RegisteredQuery<"public", {
    stationToken: string;
}, Promise<string[]>>;
/**
 * Create walk-in order
 */
export declare const createWalkInOrder: import("convex/server").RegisteredMutation<"public", {
    customerEmail?: string | undefined;
    itemCount?: number | undefined;
    whitesSeparate?: boolean | undefined;
    notes?: string | undefined;
    isDelivery?: boolean | undefined;
    deliveryAddress?: string | undefined;
    deliveryPhoneNumber?: string | undefined;
    deliveryHall?: string | undefined;
    deliveryRoom?: string | undefined;
    attendantId?: import("convex/values").GenericId<"attendants"> | undefined;
    attendanceId?: import("convex/values").GenericId<"attendanceLogs"> | undefined;
    customerId: import("convex/values").GenericId<"users">;
    serviceType: "wash_only" | "wash_and_dry" | "dry_only";
    bagCardNumber: string;
    customerName: string;
    stationToken: string;
    customerPhone: string;
    weight: number;
}, Promise<{
    success: boolean;
    orderId: import("convex/values").GenericId<"orders">;
    orderNumber: string;
    bagCardNumber: string;
}>>;
/**
 * Complete payment for walk-in order (requires identity verification)
 */
export declare const completeWalkInPayment: import("convex/server").RegisteredMutation<"public", {
    amountTendered?: number | undefined;
    paymentMethod: "mobile_money" | "cash";
    orderId: import("convex/values").GenericId<"orders">;
    verificationId: import("convex/values").GenericId<"biometricVerifications">;
    stationToken: string;
}, Promise<{
    success: boolean;
    paymentId: import("convex/values").GenericId<"payments">;
    orderId: import("convex/values").GenericId<"orders">;
    ussdSent: boolean;
}>>;
//# sourceMappingURL=stations.d.ts.map