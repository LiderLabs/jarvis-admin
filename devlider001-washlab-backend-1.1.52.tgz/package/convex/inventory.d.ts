/**
 * Get inventory items for a branch
 */
export declare const getByBranch: import("convex/server").RegisteredQuery<"public", {
    status?: "low" | "critical" | "ok" | "ordered" | undefined;
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    category?: "cleaning_supplies" | "add_ons" | "facility" | "retail" | "operational" | undefined;
}, Promise<{
    status: "low" | "critical" | "ok" | "ordered";
    _id: import("convex/values").GenericId<"inventoryItems">;
    _creationTime: number;
    createdBy?: import("convex/values").GenericId<"admins"> | undefined;
    description?: string | undefined;
    updatedBy?: import("convex/values").GenericId<"admins"> | undefined;
    orderedAt?: number | undefined;
    expectedArrivalDate?: number | undefined;
    arrivalDate?: number | undefined;
    orderQuantity?: number | undefined;
    lastRestockedAt?: number | undefined;
    name: string;
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    updatedAt: number;
    category: "cleaning_supplies" | "add_ons" | "facility" | "retail" | "operational";
    unit: string;
    currentStock: number;
    maxStock: number;
    minStock: number;
    reorderPoint: number;
}[]>>;
/**
 * Get inventory items for station (attendant view)
 */
export declare const getStationInventory: import("convex/server").RegisteredQuery<"public", {
    stationToken: string;
}, Promise<{
    status: "low" | "critical" | "ok" | "ordered";
    _id: import("convex/values").GenericId<"inventoryItems">;
    _creationTime: number;
    createdBy?: import("convex/values").GenericId<"admins"> | undefined;
    description?: string | undefined;
    updatedBy?: import("convex/values").GenericId<"admins"> | undefined;
    orderedAt?: number | undefined;
    expectedArrivalDate?: number | undefined;
    arrivalDate?: number | undefined;
    orderQuantity?: number | undefined;
    lastRestockedAt?: number | undefined;
    name: string;
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    updatedAt: number;
    category: "cleaning_supplies" | "add_ons" | "facility" | "retail" | "operational";
    unit: string;
    currentStock: number;
    maxStock: number;
    minStock: number;
    reorderPoint: number;
}[]>>;
/**
 * Create new inventory item (admin or attendant)
 */
export declare const create: import("convex/server").RegisteredMutation<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    verificationId?: import("convex/values").GenericId<"biometricVerifications"> | undefined;
    description?: string | undefined;
    stationToken?: string | undefined;
    name: string;
    category: "cleaning_supplies" | "add_ons" | "facility" | "retail" | "operational";
    unit: string;
    currentStock: number;
    maxStock: number;
    minStock: number;
    reorderPoint: number;
}, Promise<import("convex/values").GenericId<"inventoryItems">>>;
/**
 * Update inventory stock level
 */
export declare const updateStock: import("convex/server").RegisteredMutation<"public", {
    stationToken?: string | undefined;
    currentStock: number;
    itemId: import("convex/values").GenericId<"inventoryItems">;
}, Promise<{
    success: boolean;
}>>;
/**
 * Place order for inventory item
 */
export declare const placeOrder: import("convex/server").RegisteredMutation<"public", {
    expectedArrivalDate?: number | undefined;
    stationToken?: string | undefined;
    orderQuantity: number;
    itemId: import("convex/values").GenericId<"inventoryItems">;
}, Promise<{
    success: boolean;
}>>;
/**
 * Mark order as received (restock)
 */
export declare const receiveOrder: import("convex/server").RegisteredMutation<"public", {
    stationToken?: string | undefined;
    receivedQuantity?: number | undefined;
    itemId: import("convex/values").GenericId<"inventoryItems">;
}, Promise<{
    success: boolean;
}>>;
/**
 * Update inventory item details (admin only)
 */
export declare const update: import("convex/server").RegisteredMutation<"public", {
    name?: string | undefined;
    description?: string | undefined;
    category?: "cleaning_supplies" | "add_ons" | "facility" | "retail" | "operational" | undefined;
    unit?: string | undefined;
    maxStock?: number | undefined;
    minStock?: number | undefined;
    reorderPoint?: number | undefined;
    itemId: import("convex/values").GenericId<"inventoryItems">;
}, Promise<{
    success: boolean;
}>>;
/**
 * Delete inventory item (soft delete, admin only)
 */
export declare const deleteItem: import("convex/server").RegisteredMutation<"public", {
    itemId: import("convex/values").GenericId<"inventoryItems">;
}, Promise<{
    success: boolean;
}>>;
//# sourceMappingURL=inventory.d.ts.map