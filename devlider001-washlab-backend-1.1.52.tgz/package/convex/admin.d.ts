import { Id } from "./_generated/dataModel";
/**
 * Admin Functions
 *
 * Handles admin operations: branch management, attendant management,
 * system-wide order viewing, analytics, and customer management.
 */
/**
 * Get current admin profile (from authenticated Clerk session)
 * Returns null if user is authenticated but not an admin (for redirect to unauthorized page)
 * Returns null if user is not authenticated (frontend handles redirect to sign-in)
 */
/**
 * Get all attendance logs (admin view)
 * Returns attendance logs with optional filtering by branch and date range
 */
export declare const getAttendanceLogs: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    startDate?: number | undefined;
    endDate?: number | undefined;
    limit?: number | undefined;
}, Promise<{
    _id: import("convex/values").GenericId<"attendanceLogs">;
    clockInAt: number;
    clockOutAt: number | undefined;
    deviceId: string | undefined;
    isActive: boolean;
    durationMinutes: number | null;
    attendant: {
        _id: import("convex/values").GenericId<"attendants">;
        name: string;
        email: string;
    } | null;
    branch: {
        _id: import("convex/values").GenericId<"branches">;
        name: string;
        code: string;
    } | null;
}[]>>;
/**
 * Get station/branch attendance summary
 * Returns active attendances grouped by branch
 */
export declare const getBranchAttendanceSummary: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    branch: {
        _id: import("convex/values").GenericId<"branches">;
        name: string;
        code: string;
        terminalId: string | undefined;
    };
    activeCount: number;
    attendances: {
        attendanceId: import("convex/values").GenericId<"attendanceLogs">;
        clockInAt: number;
        attendant: {
            _id: import("convex/values").GenericId<"attendants">;
            name: string;
            email: string;
        } | null;
    }[];
}[]>>;
export declare const getCurrentUser: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    _id: import("convex/values").GenericId<"admins">;
    _creationTime: number;
    lastLoginAt?: number | undefined;
    email: string;
    name: string;
    clerkUserId: string;
    createdAt: number;
    isDeleted: boolean;
    role: "super_admin" | "admin";
} | null>>;
/**
 * Get all branches - Paginated
 * Supports usePaginatedQuery for infinite scroll
 */
export declare const getBranches: import("convex/server").RegisteredQuery<"public", {
    includeInactive?: boolean | undefined;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        _id: import("convex/values").GenericId<"branches">;
        _creationTime: number;
        email?: string | undefined;
        terminalId?: string | undefined;
        stationPinHash?: string | undefined;
        requireStationLogin?: boolean | undefined;
        phoneNumber: string;
        name: string;
        createdAt: number;
        isDeleted: boolean;
        isActive: boolean;
        createdBy: import("convex/values").GenericId<"admins">;
        code: string;
        address: string;
        city: string;
        country: string;
        pricingPerKg: number;
        deliveryFee: number;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Get all active branches with codes (public - no auth required)
 * Used for displaying available branch codes on login page
 */
export declare const getActiveBranchesList: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    code: string;
    name: string;
}[]>>;
/**
 * Get branch by code
 */
export declare const getBranchByCode: import("convex/server").RegisteredQuery<"public", {
    code: string;
}, Promise<{
    _id: import("convex/values").GenericId<"branches">;
    name: string;
    code: string;
    address: string;
    city: string;
    country: string;
    phoneNumber: string;
    email: string | undefined;
    requireStationLogin: boolean;
    hasStationPin: boolean;
} | null>>;
/**
 * Get single branch by ID
 */
export declare const getBranch: import("convex/server").RegisteredQuery<"public", {
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<{
    _id: import("convex/values").GenericId<"branches">;
    _creationTime: number;
    email?: string | undefined;
    terminalId?: string | undefined;
    stationPinHash?: string | undefined;
    requireStationLogin?: boolean | undefined;
    phoneNumber: string;
    name: string;
    createdAt: number;
    isDeleted: boolean;
    isActive: boolean;
    createdBy: import("convex/values").GenericId<"admins">;
    code: string;
    address: string;
    city: string;
    country: string;
    pricingPerKg: number;
    deliveryFee: number;
} | null>>;
/**
 * Get all attendants - Paginated
 * Supports usePaginatedQuery for infinite scroll
 */
export declare const getAttendants: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    numItems?: number | undefined;
    cursor?: string | undefined;
    includeInactive?: boolean | undefined;
}, Promise<{
    page: {
        _id: import("convex/values").GenericId<"attendants">;
        _creationTime: number;
        clerkUserId?: string | undefined;
        lastLoginAt?: number | undefined;
        passcodeHash?: string | undefined;
        passcodeSalt?: string | undefined;
        authenticationMethods?: ("biometric_face" | "biometric_hand" | "pin" | "password")[] | undefined;
        enrollmentTokenHash?: string | undefined;
        enrollmentTokenExpiresAt?: number | undefined;
        enrolledAt?: number | undefined;
        enrolledBy?: import("convex/values").GenericId<"admins"> | undefined;
        biometricTemplateHash?: string | undefined;
        biometricDataEncrypted?: string | undefined;
        biometricCaptureMetadata?: {
            deviceInfo?: string | undefined;
            captureType: "face" | "hand";
            anglesCaptured: string[];
            captureQuality: number;
            livenessPassed: boolean;
            captureTimestamp: number;
        } | undefined;
        lastVerificationAt?: number | undefined;
        lastVerificationSuccess?: boolean | undefined;
        verificationTimeoutAt?: number | undefined;
        phoneNumber: string;
        email: string;
        name: string;
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        isActive: boolean;
        enrollmentStatus: "active" | "suspended" | "invited" | "enrolling" | "biometric_complete" | "locked";
        consecutiveFailures: number;
        createdBy: import("convex/values").GenericId<"admins">;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Get all orders (with filters) - Paginated
 * Supports usePaginatedQuery for infinite scroll
 */
export declare const getOrders: import("convex/server").RegisteredQuery<"public", {
    status?: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered" | undefined;
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    startDate?: number | undefined;
    endDate?: number | undefined;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        _id: import("convex/values").GenericId<"orders">;
        _creationTime: number;
        createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
        customerEmail?: string | undefined;
        estimatedWeight?: number | undefined;
        actualWeight?: number | undefined;
        itemCount?: number | undefined;
        estimatedLoads?: number | undefined;
        whitesSeparate?: boolean | undefined;
        bagCardNumber?: string | undefined;
        notes?: string | undefined;
        deliveryAddress?: string | undefined;
        deliveryPhoneNumber?: string | undefined;
        deliveryHall?: string | undefined;
        deliveryRoom?: string | undefined;
        paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
        paymentId?: import("convex/values").GenericId<"payments"> | undefined;
        assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
        fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
        status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
        createdAt: number;
        isDeleted: boolean;
        branchId: import("convex/values").GenericId<"branches">;
        deliveryFee: number;
        customerId: import("convex/values").GenericId<"users">;
        customerPhoneNumber: string;
        orderNumber: string;
        orderType: "walk_in" | "online";
        serviceType: "wash_only" | "wash_and_dry" | "dry_only";
        isDelivery: boolean;
        basePrice: number;
        totalPrice: number;
        finalPrice: number;
        paymentStatus: "pending" | "paid" | "failed" | "refunded";
        updatedAt: number;
        statusHistory: {
            notes?: string | undefined;
            changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
            changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
            status: string;
            changedAt: number;
        }[];
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Get analytics dashboard data
 */
export declare const getAnalytics: import("convex/server").RegisteredQuery<"public", {
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    startDate?: number | undefined;
    endDate?: number | undefined;
}, Promise<{
    totalOrders: number;
    totalRevenue: number;
    averageOrderValue: number;
    ordersByStatus: Record<string, number>;
    ordersByDay: Record<string, number>;
    topCustomers: {
        customerId: Id<"users">;
        name: string;
        phoneNumber: string;
        orderCount: number;
    }[];
    dateRange: {
        start: number | undefined;
        end: number | undefined;
    };
}>>;
/**
 * Get all customers (with filters) - Paginated
 * Supports usePaginatedQuery for infinite scroll
 */
export declare const getCustomers: import("convex/server").RegisteredQuery<"public", {
    isRegistered?: boolean | undefined;
    status?: "active" | "blocked" | "suspended" | "restricted" | undefined;
    search?: string | undefined;
    paginationOpts: {
        id?: number;
        endCursor?: string | null;
        maximumRowsRead?: number;
        maximumBytesRead?: number;
        numItems: number;
        cursor: string | null;
    };
}, Promise<{
    page: {
        orderCount: number;
        completedOrderCount: number;
        totalSpent: number;
        lastOrderDate: number;
        lastOrderNumber: string;
        _id: import("convex/values").GenericId<"users">;
        _creationTime: number;
        email?: string | undefined;
        clerkUserId?: string | undefined;
        status?: "active" | "blocked" | "suspended" | "restricted" | undefined;
        statusNote?: string | undefined;
        statusChangedBy?: import("convex/values").GenericId<"admins"> | undefined;
        statusChangedAt?: number | undefined;
        lastLoginAt?: number | undefined;
        preferredBranchId?: import("convex/values").GenericId<"branches"> | undefined;
        phoneNumber: string;
        name: string;
        isRegistered: boolean;
        isVerified: boolean;
        createdAt: number;
        isDeleted: boolean;
    }[];
    isDone: boolean;
    continueCursor: string;
}>>;
/**
 * Get customer statistics/aggregations
 */
export declare const getCustomerStats: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    totalCustomers: number;
    registeredCustomers: number;
    walkInCustomers: number;
    activeCustomers: number;
    blockedCustomers: number;
    suspendedCustomers: number;
    restrictedCustomers: number;
    verifiedCustomers: number;
    customersWithActiveOrders: number;
    totalRevenue: number;
}>>;
/**
 * Change customer status (with required note)
 */
export declare const changeCustomerStatus: import("convex/server").RegisteredMutation<"public", {
    status: "active" | "blocked" | "suspended" | "restricted";
    customerId: import("convex/values").GenericId<"users">;
    note: string;
}, Promise<import("convex/values").GenericId<"users">>>;
/**
 * Delete a customer (soft delete)
 */
export declare const deleteCustomer: import("convex/server").RegisteredMutation<"public", {
    customerId: import("convex/values").GenericId<"users">;
}, Promise<import("convex/values").GenericId<"users">>>;
/**
 /**
 * Create new branch
 */
export declare const createBranch: import("convex/server").RegisteredMutation<"public", {
    email?: string | undefined;
    phoneNumber: string;
    name: string;
    code: string;
    address: string;
    city: string;
    country: string;
    pricingPerKg: number;
    deliveryFee: number;
    stationPin: string;
}, Promise<import("convex/values").GenericId<"branches">>>;
/**
 /**
 * Update branch details
 */
export declare const updateBranch: import("convex/server").RegisteredMutation<"public", {
    phoneNumber?: string | undefined;
    email?: string | undefined;
    name?: string | undefined;
    isActive?: boolean | undefined;
    code?: string | undefined;
    address?: string | undefined;
    city?: string | undefined;
    country?: string | undefined;
    pricingPerKg?: number | undefined;
    deliveryFee?: number | undefined;
    stationPin?: string | undefined;
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<import("convex/values").GenericId<"branches">>>;
/**
 * Toggle branch active status (enable/disable)
 */
export declare const toggleBranchStatus: import("convex/server").RegisteredMutation<"public", {
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<{
    branchId: import("convex/values").GenericId<"branches">;
    isActive: boolean;
}>>;
/**
 * Delete branch (soft delete)
 */
export declare const deleteBranch: import("convex/server").RegisteredMutation<"public", {
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<import("convex/values").GenericId<"branches">>>;
/**
 * Create attendant account
 * Note: Clerk user must be created separately, then link clerkUserId
 */
export declare const createAttendant: import("convex/server").RegisteredMutation<"public", {
    passcode?: string | undefined;
    phoneNumber: string;
    email: string;
    name: string;
    clerkUserId: string;
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<import("convex/values").GenericId<"attendants">>>;
/**
 * Update attendant details
 */
export declare const updateAttendant: import("convex/server").RegisteredMutation<"public", {
    phoneNumber?: string | undefined;
    email?: string | undefined;
    name?: string | undefined;
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
    isActive?: boolean | undefined;
    passcode?: string | undefined;
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<import("convex/values").GenericId<"attendants">>>;
/**
 * Assign attendant to branch
 */
export declare const assignAttendantToBranch: import("convex/server").RegisteredMutation<"public", {
    branchId: import("convex/values").GenericId<"branches">;
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<import("convex/values").GenericId<"attendants">>>;
/**
 * Change attendant enrollment status (suspend, activate, lock, unlock)
 */
export declare const changeAttendantStatus: import("convex/server").RegisteredMutation<"public", {
    reason?: string | undefined;
    status: "active" | "suspended" | "invited" | "enrolling" | "locked";
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<{
    attendantId: import("convex/values").GenericId<"attendants">;
    oldStatus: "active" | "suspended" | "invited" | "enrolling" | "biometric_complete" | "locked";
    newStatus: "active" | "suspended" | "invited" | "enrolling" | "locked";
}>>;
/**
 * Suspend attendant (convenience function)
 */
export declare const suspendAttendant: import("convex/server").RegisteredMutation<"public", {
    reason?: string | undefined;
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<{
    attendantId: import("convex/values").GenericId<"attendants">;
    oldStatus: "active" | "invited" | "enrolling" | "biometric_complete" | "locked";
    newStatus: string;
}>>;
/**
 * Activate attendant (convenience function - unsuspend/unlock)
 */
export declare const activateAttendant: import("convex/server").RegisteredMutation<"public", {
    reason?: string | undefined;
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<{
    attendantId: import("convex/values").GenericId<"attendants">;
    oldStatus: "suspended" | "invited" | "enrolling" | "biometric_complete" | "locked";
    newStatus: string;
}>>;
/**
 * Lock attendant (convenience function)
 */
export declare const lockAttendant: import("convex/server").RegisteredMutation<"public", {
    reason?: string | undefined;
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<{
    attendantId: import("convex/values").GenericId<"attendants">;
    oldStatus: "active" | "suspended" | "invited" | "enrolling" | "biometric_complete";
    newStatus: string;
}>>;
/**
 * Reset attendant verification failures
 */
export declare const resetAttendantFailures: import("convex/server").RegisteredMutation<"public", {
    reason?: string | undefined;
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<{
    attendantId: import("convex/values").GenericId<"attendants">;
}>>;
/**
 * Revoke all active sessions for an attendant
 */
export declare const revokeAttendantSessions: import("convex/server").RegisteredMutation<"public", {
    reason?: string | undefined;
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<{
    attendantId: import("convex/values").GenericId<"attendants">;
    sessionsRevoked: number;
}>>;
/**
 * Delete attendant (soft delete)
 */
export declare const deleteAttendant: import("convex/server").RegisteredMutation<"public", {
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<import("convex/values").GenericId<"attendants">>>;
/**
 * Create admin account
 * Only super admins can create other admins
 * Note: Clerk user must be created separately, then link clerkUserId
 */
export declare const createAdmin: import("convex/server").RegisteredMutation<"public", {
    email: string;
    name: string;
    clerkUserId: string;
    role: "super_admin" | "admin";
}, Promise<import("convex/values").GenericId<"admins">>>;
/**
 * Create the first super admin (one-time setup)
 * This function can only be used when no super admins exist in the database
 * After the first super admin is created, use createAdmin instead
 */
export declare const createFirstSuperAdmin: import("convex/server").RegisteredMutation<"public", {
    email: string;
    name: string;
    clerkUserId: string;
}, Promise<import("convex/values").GenericId<"admins">>>;
/**
 * Admin: Update order status (admin can update any order)
 */
export declare const updateOrderStatus: import("convex/server").RegisteredMutation<"public", {
    notes?: string | undefined;
    orderId: import("convex/values").GenericId<"orders">;
    newStatus: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
}, Promise<import("convex/values").GenericId<"orders">>>;
/**
 * Admin: Delete order (soft delete)
 */
export declare const deleteOrder: import("convex/server").RegisteredMutation<"public", {
    orderId: import("convex/values").GenericId<"orders">;
}, Promise<import("convex/values").GenericId<"orders">>>;
/**
 * Admin: Get order details (includes full order information with customer and branch)
 */
export declare const getOrderDetails: import("convex/server").RegisteredQuery<"public", {
    orderId: import("convex/values").GenericId<"orders">;
}, Promise<{
    customer: {
        _id: import("convex/values").GenericId<"users">;
        name: string;
        phoneNumber: string;
        email: string | undefined;
    } | null;
    branch: {
        _id: import("convex/values").GenericId<"branches">;
        name: string;
        code: string;
        address: string;
        city: string;
    } | null;
    _id: import("convex/values").GenericId<"orders">;
    _creationTime: number;
    createdBy?: import("convex/values").GenericId<"attendants"> | undefined;
    customerEmail?: string | undefined;
    estimatedWeight?: number | undefined;
    actualWeight?: number | undefined;
    itemCount?: number | undefined;
    estimatedLoads?: number | undefined;
    whitesSeparate?: boolean | undefined;
    bagCardNumber?: string | undefined;
    notes?: string | undefined;
    deliveryAddress?: string | undefined;
    deliveryPhoneNumber?: string | undefined;
    deliveryHall?: string | undefined;
    deliveryRoom?: string | undefined;
    paymentMethod?: "mobile_money" | "card" | "cash" | undefined;
    paymentId?: import("convex/values").GenericId<"payments"> | undefined;
    assignedTo?: import("convex/values").GenericId<"attendants"> | undefined;
    fulfilledBy?: import("convex/values").GenericId<"attendants"> | undefined;
    status: "pending_dropoff" | "checked_in" | "sorting" | "washing" | "drying" | "folding" | "ready" | "completed" | "cancelled" | "pending" | "in_progress" | "ready_for_pickup" | "delivered";
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    deliveryFee: number;
    customerId: import("convex/values").GenericId<"users">;
    customerPhoneNumber: string;
    orderNumber: string;
    orderType: "walk_in" | "online";
    serviceType: "wash_only" | "wash_and_dry" | "dry_only";
    isDelivery: boolean;
    basePrice: number;
    totalPrice: number;
    finalPrice: number;
    paymentStatus: "pending" | "paid" | "failed" | "refunded";
    updatedAt: number;
    statusHistory: {
        notes?: string | undefined;
        changedBy?: import("convex/values").GenericId<"attendants"> | undefined;
        changedByAdmin?: import("convex/values").GenericId<"admins"> | undefined;
        status: string;
        changedAt: number;
    }[];
} | null>>;
/**
 * Create attendant enrollment (Admin)
 * Generates enrollment link for attendant to complete biometric setup
 */
export declare const createAttendantEnrollment: import("convex/server").RegisteredMutation<"public", {
    expiresInHours?: number | undefined;
    phoneNumber: string;
    email: string;
    name: string;
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<{
    attendantId: Id<"attendants">;
    enrollmentToken: string;
    enrollmentLink: string;
    expiresAt: number;
}>>;
/**
 * List attendant enrollments (Admin)
 */
export declare const listAttendantEnrollments: import("convex/server").RegisteredQuery<"public", {
    status?: "active" | "suspended" | "invited" | "enrolling" | "locked" | undefined;
    branchId?: import("convex/values").GenericId<"branches"> | undefined;
}, Promise<{
    id: import("convex/values").GenericId<"attendants">;
    name: string;
    email: string;
    phoneNumber: string;
    branchId: import("convex/values").GenericId<"branches">;
    enrollmentStatus: "active" | "suspended" | "invited" | "enrolling" | "biometric_complete" | "locked";
    enrolledAt: number | undefined;
    enrollmentTokenExpiresAt: number | undefined;
    lastVerificationAt: number | undefined;
    consecutiveFailures: number;
    createdAt: number;
}[]>>;
/**
 * Resend enrollment link (Admin)
 */
export declare const resendEnrollmentLink: import("convex/server").RegisteredMutation<"public", {
    expiresInHours?: number | undefined;
    attendantId: import("convex/values").GenericId<"attendants">;
}, Promise<{
    enrollmentToken: string;
    enrollmentLink: string;
    expiresAt: number;
}>>;
/**
 * Get system settings
 */
export declare const getSystemSettings: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    businessName: string;
    contactPhone: string;
    contactEmail: string;
    notifyNewOrders: boolean;
    notifyCompletedOrders: boolean;
    requireBiometricPayment: boolean;
    autoLogoutMinutes: number;
}>>;
/**
 * Update system settings
 */
export declare const updateSystemSettings: import("convex/server").RegisteredMutation<"public", {
    businessName: string;
    contactPhone: string;
    contactEmail: string;
    notifyNewOrders: boolean;
    notifyCompletedOrders: boolean;
    requireBiometricPayment: boolean;
    autoLogoutMinutes: number;
}, Promise<{
    success: boolean;
}>>;
/**
 * Get all services
 */
export declare const getServices: import("convex/server").RegisteredQuery<"public", {}, Promise<{
    _id: import("convex/values").GenericId<"services">;
    _creationTime: number;
    description?: string | undefined;
    updatedBy?: import("convex/values").GenericId<"admins"> | undefined;
    imageStorageId?: import("convex/values").GenericId<"_storage"> | undefined;
    imageUrl?: string | undefined;
    name: string;
    createdAt: number;
    isDeleted: boolean;
    isActive: boolean;
    createdBy: import("convex/values").GenericId<"admins">;
    code: string;
    basePrice: number;
    updatedAt: number;
    pricingType: "per_kg" | "per_load";
}[]>>;
/**
 * Create a new service
 */
export declare const createService: import("convex/server").RegisteredMutation<"public", {
    description?: string | undefined;
    imageStorageId?: import("convex/values").GenericId<"_storage"> | undefined;
    imageUrl?: string | undefined;
    name: string;
    code: string;
    basePrice: number;
    pricingType: "per_kg" | "per_load";
}, Promise<{
    success: boolean;
    serviceId: import("convex/values").GenericId<"services">;
}>>;
/**
 * Update a service
 */
export declare const updateService: import("convex/server").RegisteredMutation<"public", {
    name?: string | undefined;
    isActive?: boolean | undefined;
    basePrice?: number | undefined;
    description?: string | undefined;
    imageStorageId?: import("convex/values").GenericId<"_storage"> | undefined;
    imageUrl?: string | undefined;
    pricingType?: "per_kg" | "per_load" | undefined;
    serviceId: import("convex/values").GenericId<"services">;
}, Promise<{
    success: boolean;
}>>;
/**
 * Delete a service (soft delete)
 */
export declare const deleteService: import("convex/server").RegisteredMutation<"public", {
    serviceId: import("convex/values").GenericId<"services">;
}, Promise<{
    success: boolean;
}>>;
/**
 * Generate upload URL for service images
 */
export declare const generateServiceImageUploadUrl: import("convex/server").RegisteredMutation<"public", {}, Promise<string>>;
/**
 * Get service image URL from storage ID
 */
export declare const getServiceImageUrl: import("convex/server").RegisteredQuery<"public", {
    storageId: import("convex/values").GenericId<"_storage">;
}, Promise<string | null>>;
/**
 * Get all services for a branch
 */
export declare const getBranchServices: import("convex/server").RegisteredQuery<"public", {
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<{
    _id: import("convex/values").GenericId<"branchServices">;
    _creationTime: number;
    description?: string | undefined;
    updatedBy?: import("convex/values").GenericId<"admins"> | undefined;
    imageUrl?: string | undefined;
    name: string;
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    isActive: boolean;
    createdBy: import("convex/values").GenericId<"admins">;
    code: string;
    updatedAt: number;
    price: number;
}[]>>;
/**
 * Create a branch service
 */
export declare const createBranchService: import("convex/server").RegisteredMutation<"public", {
    description?: string | undefined;
    imageUrl?: string | undefined;
    name: string;
    branchId: import("convex/values").GenericId<"branches">;
    code: string;
    price: number;
}, Promise<import("convex/values").GenericId<"branchServices">>>;
/**
 * Update a branch service
 */
export declare const updateBranchService: import("convex/server").RegisteredMutation<"public", {
    name?: string | undefined;
    isActive?: boolean | undefined;
    description?: string | undefined;
    imageUrl?: string | undefined;
    price?: number | undefined;
    serviceId: import("convex/values").GenericId<"branchServices">;
}, Promise<import("convex/values").GenericId<"branchServices">>>;
/**
 * Delete a branch service (soft delete)
 */
export declare const deleteBranchService: import("convex/server").RegisteredMutation<"public", {
    serviceId: import("convex/values").GenericId<"branchServices">;
}, Promise<import("convex/values").GenericId<"branchServices">>>;
export declare const getBranchServicesPublic: import("convex/server").RegisteredQuery<"public", {
    branchId: import("convex/values").GenericId<"branches">;
}, Promise<{
    _id: import("convex/values").GenericId<"branchServices">;
    _creationTime: number;
    description?: string | undefined;
    updatedBy?: import("convex/values").GenericId<"admins"> | undefined;
    imageUrl?: string | undefined;
    name: string;
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    isActive: boolean;
    createdBy: import("convex/values").GenericId<"admins">;
    code: string;
    updatedAt: number;
    price: number;
}[]>>;
//# sourceMappingURL=admin.d.ts.map