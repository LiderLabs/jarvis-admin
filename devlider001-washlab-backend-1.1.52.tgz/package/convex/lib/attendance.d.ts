/**
 * Attendance Utility Functions
 *
 * Provides helper functions for attendance-related operations,
 * including verification and validation for attendance-linked actions.
 */
import { QueryCtx, MutationCtx } from "../_generated/server";
import { Id } from "../_generated/dataModel";
/**
 * Get active attendance record for an attendant
 * @throws Error if no active attendance found
 */
export declare function getActiveAttendance(ctx: QueryCtx | MutationCtx, attendantId: Id<"attendants">): Promise<{
    _id: import("convex/values").GenericId<"attendanceLogs">;
    _creationTime: number;
    deviceInfo?: string | undefined;
    clockOutAt?: number | undefined;
    deviceId?: string | undefined;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    isActive: boolean;
    attendantId: import("convex/values").GenericId<"attendants">;
    clockInAt: number;
}>;
/**
 * Verify that an attendant has an active attendance session
 * Returns the attendance record if valid, throws error otherwise
 */
export declare function verifyActiveAttendance(ctx: QueryCtx | MutationCtx, attendantId: Id<"attendants">, branchId?: Id<"branches">): Promise<{
    _id: import("convex/values").GenericId<"attendanceLogs">;
    _creationTime: number;
    deviceInfo?: string | undefined;
    clockOutAt?: number | undefined;
    deviceId?: string | undefined;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    isActive: boolean;
    attendantId: import("convex/values").GenericId<"attendants">;
    clockInAt: number;
}>;
/**
 * Check if attendant has active attendance (does not throw, returns boolean)
 */
export declare function hasActiveAttendance(ctx: QueryCtx | MutationCtx, attendantId: Id<"attendants">): Promise<boolean>;
/**
 * Get all active attendances for a branch
 */
export declare function getActiveAttendancesByBranch(ctx: QueryCtx | MutationCtx, branchId: Id<"branches">): Promise<{
    _id: import("convex/values").GenericId<"attendanceLogs">;
    _creationTime: number;
    deviceInfo?: string | undefined;
    clockOutAt?: number | undefined;
    deviceId?: string | undefined;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    isActive: boolean;
    attendantId: import("convex/values").GenericId<"attendants">;
    clockInAt: number;
}[]>;
/**
 * Get attendance history for an attendant
 */
export declare function getAttendantAttendanceHistory(ctx: QueryCtx | MutationCtx, attendantId: Id<"attendants">, limit?: number): Promise<{
    _id: import("convex/values").GenericId<"attendanceLogs">;
    _creationTime: number;
    deviceInfo?: string | undefined;
    clockOutAt?: number | undefined;
    deviceId?: string | undefined;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    isActive: boolean;
    attendantId: import("convex/values").GenericId<"attendants">;
    clockInAt: number;
}[]>;
/**
 * Calculate duration of an attendance session in minutes
 */
export declare function calculateAttendanceDuration(clockInAt: number, clockOutAt?: number): number;
//# sourceMappingURL=attendance.d.ts.map