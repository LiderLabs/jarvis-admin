/**
 * Biometric Comparison Utilities
 *
 * Provides functions to compare live biometric data with stored templates.
 */
export interface BiometricData {
    landmarks: number[][];
    angles: {
        headLeft?: number;
        headRight?: number;
        headUp?: number;
        headDown?: number;
        handLeft?: number;
        handRight?: number;
        handUp?: number;
        handDown?: number;
    };
    features: number[];
}
/**
 * Compare two biometric templates and return confidence score (0-1)
 */
export declare function compareBiometricData(live: BiometricData, stored: BiometricData): number;
/**
 * Compare biometric templates (wrapper for stored vs live comparison)
 */
export declare function compareBiometricTemplates(storedTemplate: BiometricData, liveData: {
    features: number[];
    measurements: any;
    angles: string[];
}, options: {
    captureQuality: number;
    type: "face" | "hand";
}): Promise<{
    confidence: number;
    match: boolean;
}>;
//# sourceMappingURL=biometricComparison.d.ts.map