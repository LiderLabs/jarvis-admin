import { QueryCtx, MutationCtx } from "../_generated/server";
import { Id } from "../_generated/dataModel";
/**
 * Get the current authenticated Clerk user identity
 * @throws Error if user is not authenticated
 */
export declare function getClerkIdentity(ctx: QueryCtx | MutationCtx): Promise<import("convex/server").UserIdentity>;
/**
 * Find current customer user from Clerk identity
 * Returns null if customer doesn't exist (for profile check scenarios)
 * @throws Error if user is not authenticated
 */
export declare function findCurrentCustomer(ctx: QueryCtx | MutationCtx): Promise<{
    _id: import("convex/values").GenericId<"users">;
    _creationTime: number;
    email?: string | undefined;
    clerkUserId?: string | undefined;
    status?: "active" | "blocked" | "suspended" | "restricted" | undefined;
    statusNote?: string | undefined;
    statusChangedBy?: import("convex/values").GenericId<"admins"> | undefined;
    statusChangedAt?: number | undefined;
    lastLoginAt?: number | undefined;
    preferredBranchId?: import("convex/values").GenericId<"branches"> | undefined;
    phoneNumber: string;
    name: string;
    isRegistered: boolean;
    isVerified: boolean;
    createdAt: number;
    isDeleted: boolean;
} | null>;
/**
 * Get current customer user from Clerk identity
 * @throws Error if user is not authenticated or not found
 */
export declare function getCurrentCustomer(ctx: QueryCtx | MutationCtx): Promise<{
    _id: import("convex/values").GenericId<"users">;
    _creationTime: number;
    email?: string | undefined;
    clerkUserId?: string | undefined;
    status?: "active" | "blocked" | "suspended" | "restricted" | undefined;
    statusNote?: string | undefined;
    statusChangedBy?: import("convex/values").GenericId<"admins"> | undefined;
    statusChangedAt?: number | undefined;
    lastLoginAt?: number | undefined;
    preferredBranchId?: import("convex/values").GenericId<"branches"> | undefined;
    phoneNumber: string;
    name: string;
    isRegistered: boolean;
    isVerified: boolean;
    createdAt: number;
    isDeleted: boolean;
}>;
/**
 * Get current attendant from Clerk identity
 * @throws Error if user is not authenticated or not found
 */
export declare function getCurrentAttendant(ctx: QueryCtx | MutationCtx): Promise<{
    _id: import("convex/values").GenericId<"attendants">;
    _creationTime: number;
    clerkUserId?: string | undefined;
    lastLoginAt?: number | undefined;
    passcodeHash?: string | undefined;
    passcodeSalt?: string | undefined;
    authenticationMethods?: ("biometric_face" | "biometric_hand" | "pin" | "password")[] | undefined;
    enrollmentTokenHash?: string | undefined;
    enrollmentTokenExpiresAt?: number | undefined;
    enrolledAt?: number | undefined;
    enrolledBy?: import("convex/values").GenericId<"admins"> | undefined;
    biometricTemplateHash?: string | undefined;
    biometricDataEncrypted?: string | undefined;
    biometricCaptureMetadata?: {
        deviceInfo?: string | undefined;
        captureType: "face" | "hand";
        anglesCaptured: string[];
        captureQuality: number;
        livenessPassed: boolean;
        captureTimestamp: number;
    } | undefined;
    lastVerificationAt?: number | undefined;
    lastVerificationSuccess?: boolean | undefined;
    verificationTimeoutAt?: number | undefined;
    phoneNumber: string;
    email: string;
    name: string;
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    isActive: boolean;
    enrollmentStatus: "active" | "suspended" | "invited" | "enrolling" | "biometric_complete" | "locked";
    consecutiveFailures: number;
    createdBy: import("convex/values").GenericId<"admins">;
}>;
/**
 * Get current admin from Clerk identity
 * @throws Error if user is not authenticated or not found
 */
export declare function getCurrentAdmin(ctx: QueryCtx | MutationCtx): Promise<{
    _id: import("convex/values").GenericId<"admins">;
    _creationTime: number;
    lastLoginAt?: number | undefined;
    email: string;
    name: string;
    clerkUserId: string;
    createdAt: number;
    isDeleted: boolean;
    role: "super_admin" | "admin";
}>;
/**
 * Get current admin with super admin role check
 * @throws Error if user is not authenticated, not found, or not super admin
 */
export declare function getSuperAdmin(ctx: QueryCtx | MutationCtx): Promise<{
    _id: import("convex/values").GenericId<"admins">;
    _creationTime: number;
    lastLoginAt?: number | undefined;
    email: string;
    name: string;
    clerkUserId: string;
    createdAt: number;
    isDeleted: boolean;
    role: "super_admin" | "admin";
}>;
/**
 * Verify attendant is assigned to the specified branch
 * @throws Error if attendant is not assigned to the branch
 */
export declare function verifyAttendantBranch(ctx: QueryCtx | MutationCtx, attendantId: Id<"attendants">, branchId: Id<"branches">): Promise<{
    _id: import("convex/values").GenericId<"attendants">;
    _creationTime: number;
    clerkUserId?: string | undefined;
    lastLoginAt?: number | undefined;
    passcodeHash?: string | undefined;
    passcodeSalt?: string | undefined;
    authenticationMethods?: ("biometric_face" | "biometric_hand" | "pin" | "password")[] | undefined;
    enrollmentTokenHash?: string | undefined;
    enrollmentTokenExpiresAt?: number | undefined;
    enrolledAt?: number | undefined;
    enrolledBy?: import("convex/values").GenericId<"admins"> | undefined;
    biometricTemplateHash?: string | undefined;
    biometricDataEncrypted?: string | undefined;
    biometricCaptureMetadata?: {
        deviceInfo?: string | undefined;
        captureType: "face" | "hand";
        anglesCaptured: string[];
        captureQuality: number;
        livenessPassed: boolean;
        captureTimestamp: number;
    } | undefined;
    lastVerificationAt?: number | undefined;
    lastVerificationSuccess?: boolean | undefined;
    verificationTimeoutAt?: number | undefined;
    phoneNumber: string;
    email: string;
    name: string;
    createdAt: number;
    isDeleted: boolean;
    branchId: import("convex/values").GenericId<"branches">;
    isActive: boolean;
    enrollmentStatus: "active" | "suspended" | "invited" | "enrolling" | "biometric_complete" | "locked";
    consecutiveFailures: number;
    createdBy: import("convex/values").GenericId<"admins">;
}>;
//# sourceMappingURL=auth.d.ts.map