/**
 * Biometric Data Encryption Utilities
 *
 * Provides encryption and decryption for biometric templates.
 * Uses base64 encoding for now (placeholder for proper encryption).
 *
 * NOTE: In Convex, we use base64 encoding for now.
 * For production, implement proper encryption using environment variables
 * or an external encryption service.
 */
export interface BiometricData {
    landmarks: number[][];
    angles: {
        headLeft?: number;
        headRight?: number;
        headUp?: number;
        headDown?: number;
        handLeft?: number;
        handRight?: number;
        handUp?: number;
        handDown?: number;
    };
    features: number[];
}
/**
 * Encrypt biometric data
 * Returns encrypted data, IV, and auth tag as base64 strings
 *
 * IMPORTANT: In production, use proper encryption library or service
 * This is a placeholder that should be replaced with actual encryption
 */
export declare function encryptBiometricData(data: BiometricData): {
    encryptedData: string;
    iv: string;
    authTag: string;
};
/**
 * Decrypt biometric data
 *
 * IMPORTANT: In production, use proper decryption library or service
 * This is a placeholder that should be replaced with actual decryption
 */
export declare function decryptBiometricData(encryptedData: string, iv: string, authTag: string): BiometricData;
/**
 * Hash biometric template for quick comparison
 * Uses Web Crypto API (available in Convex V8 runtime)
 */
export declare function hashBiometricTemplate(data: BiometricData): Promise<string>;
//# sourceMappingURL=biometricEncryption.d.ts.map