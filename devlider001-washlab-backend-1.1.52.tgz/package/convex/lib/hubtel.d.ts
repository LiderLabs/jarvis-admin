/**
 * Hubtel Payment Integration
 *
 * Functions for sending USSD codes and processing payments via Hubtel
 *
 * Note: This requires Hubtel API credentials to be configured in Convex environment variables
 */
/**
 * Send USSD payment code to customer
 * This will trigger a USSD prompt on the customer's phone
 *
 * Note: Environment variables should be set in Convex dashboard
 * For now, we'll use a placeholder that needs to be configured
 *
 * @param phoneNumber - Customer phone number (can be in various formats)
 * @param amount - Payment amount in GHS
 * @param orderNumber - Order number for reference
 * @param description - Payment description
 * @returns Object with success status and message/error
 */
export declare function sendUSSDCode(phoneNumber: string, amount: number, orderNumber: string, description?: string): Promise<{
    success: boolean;
    message?: string;
    error?: string;
    transactionRef?: string;
}>;
/**
 * Verify payment status from Hubtel callback
 */
export declare function verifyPaymentStatus(transactionRef: string): Promise<{
    paid: boolean;
    amount?: number;
    transactionId?: string;
}>;
//# sourceMappingURL=hubtel.d.ts.map