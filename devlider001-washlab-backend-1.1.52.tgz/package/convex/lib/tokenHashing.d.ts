/**
 * Token Hashing Utilities
 *
 * Provides secure token hashing and verification.
 * Used for enrollment tokens, session tokens, and OTP codes.
 *
 * Uses Web Crypto API (available in Convex V8 runtime)
 */
/**
 * Hash a token using SHA-256 (for enrollment tokens and challenges)
 * Uses Web Crypto API which is available in Convex V8 runtime
 */
export declare function hashToken(token: string): Promise<string>;
/**
 * Verify a token against its hash
 */
export declare function verifyToken(token: string, hash: string): Promise<boolean>;
/**
 * Generate a secure random token
 */
export declare function generateSecureToken(length?: number): string;
/**
 * Generate a challenge string for biometric verification
 */
export declare function generateChallenge(): string;
//# sourceMappingURL=tokenHashing.d.ts.map