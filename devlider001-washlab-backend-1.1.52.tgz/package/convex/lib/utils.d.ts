import { Id } from "../_generated/dataModel";
/**
 * Utility functions for common operations
 */
/**
 * Generate unique order number
 * Format: WL-YYYY-XXXXXX (where XXXXXX is sequential)
 */
export declare function generateOrderNumber(): string;
/**
 * Calculate order price based on weight and branch pricing
 */
export declare function calculateOrderPrice(weight: number, pricingPerKg: number, deliveryFee: number, isDelivery: boolean): {
    basePrice: number;
    deliveryFee: number;
    totalPrice: number;
};
/**
 * Calculate service price based on service type and weight
 * Pricing rules:
 * - Machine capacity: 8kg per load
 * - Plus 1 minus 1 logic: weight ≤ 8kg = 1 load, > 8kg but ≤ 16kg = 2 loads, etc.
 * - wash_only: ₵25/load
 * - wash_and_dry: ₵50/load
 * - dry_only: ₵25/load
 * - whitesSeparate: adds another ₵25 (separate wash for whites)
 */
export declare function calculateServicePrice(serviceType: "wash_only" | "wash_and_dry" | "dry_only", actualWeight: number, whitesSeparate: boolean | undefined, deliveryFee: number, isDelivery: boolean): {
    basePrice: number;
    deliveryFee: number;
    totalPrice: number;
    numberOfLoads: number;
    whitesLoads: number;
};
/**
 * Format date to YYYY-MM-DD string
 */
export declare function formatDate(date: Date): string;
/**
 * Get current timestamp in milliseconds
 */
export declare function getCurrentTimestamp(): number;
export declare function safeGet<T extends Id<any>>(ctx: any, id?: T): Promise<any>;
//# sourceMappingURL=utils.d.ts.map