import { MutationCtx } from "../_generated/server";
import { Id } from "../_generated/dataModel";
/**
 * Audit logging utilities
 *
 * These functions create audit log entries for all important actions
 * to maintain accountability and compliance.
 */
interface AuditLogParams {
    ctx: MutationCtx;
    actorId: string;
    actorType: "customer" | "attendant" | "admin";
    actorRole: string;
    action: string;
    entityType: string;
    entityId?: string;
    attendanceId?: Id<"attendanceLogs">;
    branchId?: Id<"branches">;
    deviceId?: string;
    details?: string;
    oldValue?: string;
    newValue?: string;
}
/**
 * Create an audit log entry
 */
export declare function createAuditLog({ ctx, actorId, actorType, actorRole, action, entityType, entityId, attendanceId, branchId, deviceId, details, oldValue, newValue, }: AuditLogParams): Promise<Id<"auditLogs">>;
/**
 * Create audit log for order status change
 */
export declare function logOrderStatusChange(ctx: MutationCtx, orderId: Id<"orders">, attendantId: Id<"attendants">, oldStatus: string, newStatus: string, branchId: Id<"branches">, notes?: string): Promise<Id<"auditLogs">>;
/**
 * Create audit log for payment
 */
export declare function logPayment(ctx: MutationCtx, paymentId: Id<"payments">, orderId: Id<"orders">, customerId: Id<"users">, action: string, amount: number, paymentMethod: string, branchId?: Id<"branches">, attendantId?: Id<"attendants">, reason?: string): Promise<Id<"auditLogs">>;
export {};
//# sourceMappingURL=audit.d.ts.map