/**
 * Password/PIN Hashing Utilities
 *
 * Provides secure password/PIN hashing using Web Crypto API.
 * Uses PBKDF2 for password hashing (more secure than SHA-256 for passwords).
 */
/**
 * Hash a password or PIN using PBKDF2
 * This is more secure than SHA-256 for passwords as it's designed for this purpose
 */
export declare function hashPassword(password: string, salt?: string): Promise<{
    hash: string;
    salt: string;
}>;
/**
 * Verify a password or PIN against its hash
 */
export declare function verifyPassword(password: string, hash: string, salt: string): Promise<boolean>;
/**
 * Simple PIN hashing (4-6 digits) - uses SHA-256 with salt for simplicity
 * PINs are less secure, so we use a simpler approach but still with salt
 */
export declare function hashPIN(pin: string, salt?: string): Promise<{
    hash: string;
    salt: string;
}>;
/**
 * Verify a PIN against its hash
 */
export declare function verifyPIN(pin: string, hash: string, salt: string): Promise<boolean>;
//# sourceMappingURL=passwordHashing.d.ts.map